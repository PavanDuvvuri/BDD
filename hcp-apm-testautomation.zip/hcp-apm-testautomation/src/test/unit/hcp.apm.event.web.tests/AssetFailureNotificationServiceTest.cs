﻿using Xunit;

namespace Honeywell.Hcp.Apm.Event.Web.Tests
{
    public class SampleTest
    {

        public SampleTest()
        {


        }

        [Fact]
        public void Test_GetAssetFailureNotification_0Attributes()
        {
            Assert.Equal(0, 0);
        }
    }
}
