<#
.SYNOPSIS
This script executes performance test suite locally. It builds application and performance containers and execute the tests against them.  

.DESCRIPTION
This script performs the following tasks
    a. Build and spin up the application and performance test containers and executes the performance suite via docker-compose
    b. Cleans up the containers irrespective of the outcome. The corresponding docker images are not deleted

.EXAMPLE
./src/_tests_/performance/performance-local.ps1
#>

# Check for application and acceptance docker images
New-Item -ItemType Directory -Force -Path results
Invoke-Expression "docker-compose -f docker-compose.yml down --remove-orphans; docker-compose -f docker-compose.yml up --abort-on-container-exit; docker-compose rm -f"