from locust import between, SequentialTaskSet, HttpUser, task
import json, logging

from performancetestapiclient import initialise_locust_event_listener

initialise_locust_event_listener(send_only_aggregate_results=False)
logger = logging.getLogger(__name__)

@task(2)
def list_items(self):
    headers = {'content-type': 'application/json', 'Connection': 'close'}
    with self.client.get("/api/todo", headers=headers, name="List items - /api/todo", catch_response=True) as list_resp:
        if list_resp.status_code  in [200, 201]:
            list_resp.success()
        elif list_resp.status_code == 503:
            logger.info("Invalid host, http status code: {0}".format(list_resp.status_code))
        else:
            list_resp.failure("Unable to list: {0} with http status code: {1}".format(list_resp.text, list_resp.status_code))

@task(1)
def create_item(self):
    headers = {'content-type': 'application/json', 'Connection': 'close'}
    with self.client.post("/api/todo", data=json.dumps(
        {"description": "Set reminder for drinking coffee", "title": "Time to drink coffee"}),
                                     headers=headers,
                                     name="Add items - /api/todo", catch_response=True) as create_resp:
        if create_resp.status_code in [200, 201]:
            create_resp.success()
        elif create_resp.status_code == 503:
            logger.info("Invalid host, http status code: {0}".format(create_resp.status_code))
        else:
            create_resp.failure("Unable to create: {0} with http status code: {1}".format(create_resp.text, create_resp.status_code))

class UserBehaviorTestLargeScale(SequentialTaskSet):
    def on_start(self):
        # Executed per user at the beginning of the test
        pass

    tasks = [create_item, list_items]

    def on_stop(self):
        # Executed per user at the end of test
        pass

class UserBehaviorTestSmallScale(SequentialTaskSet):
    def on_start(self):
        # Executed per user at the beginning of the test
        pass
		
    tasks = [create_item]

    def on_stop(self):
        # Executed per user at the end of test
        pass
class TestSmallScale(HttpUser):
    tasks = [UserBehaviorTestSmallScale]
    wait_time = between(5.0, 9.0)

class TestLargeScale(HttpUser):
    tasks = [UserBehaviorTestLargeScale]
    wait_time = between(5.0, 10.0)