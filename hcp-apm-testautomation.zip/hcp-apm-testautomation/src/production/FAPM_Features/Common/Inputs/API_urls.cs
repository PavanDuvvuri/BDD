﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAPM_Features.Common.Inputs
{   
    class API_urls
    {
        public const string Kpiserver = "https://hcp-apm-metrics-api-tmuromzl-qrfqlazf-dqxhkanx.apps.dev.aro.forgeapp.honeywell.com";
        public const string kpitargetimportQueryUrl = "/api/Targets/Import";
        public const string kpitargetexportQueryUrl = "/api/Targets/Export?asset=";
        public const string kpitargetUrl = "/api/Targets?";
        public const string kpiMetricUrl = "/api/Metrics?";
        public const string ReportConfigUrl = "/api/ReportPeriodConfiguration";

        public const string server = "https://apmui-stage.dev.forge.connected.honeywell.com/dataapi";
        public const string QueryUrl = "/api/query-templates/query?query=";
        public const string bulkImportURL = "https://dashboardui-qa.dev.forge.connected.honeywell.com/#/assets/importexport";
        public const string eventMgmtServer = "https://apmui-stage.dev.forge.connected.honeywell.com/eventapi";
        public const string getAssetFaultCountDataUrl = "api/event/kpi/getAssetFaultCountData";
        public const string getFailureFaultCountDataUrl = "/api/event/kpi/getFailureFaultCountData";
        public const string getEventDataUrl = "/api/event";
        public const string getHeatMapMatrixUrl = "/api/event/kpi/getHeatmapMatrixData";
        public const string getFaultCategoryDataUrl = "/api/Event/GetFaultCategoryData";
        public const string updateNotificationDataUrl = "/api/Event/UpdateNotification";
        public const string getReasonCodeDataUrl = "/api/Event/GetReasonCodeData";
        public const string modelServer = "https://hcp-apm-asset-model-service-iqbyzrzt-pnwwikhh-dqxhkanx.apps.dev.aro.forgeapp.honeywell.com/";
        public const string getAssetsUrl = "api/Asset/assets?";
        public const string getAssetAttributesEventsUrl = "api/assets/AssetAttribute/events?";
        public const string getAssetAttributesTagMappingsAttributesUrl = "api/assets/AssetAttribute/tagMappings/Attributes?";
        public const string getAssetAttributesTagMappingsPropertiesUrl = "api/assets/AssetAttribute/tagMappings/Properties?";
        public const string getAssetAttributePropertiesUrl = "api/assets/AssetAttribute/properties?";
        public const string getAssetAttributePropertiesEventsUrl = "api/assets/AssetAttributeProperties/events?";
        public const string getAssetAttributeUrl = "api/assets/AssetAttribute";
        public const string getAssetModelsUrl = "api/Asset/Models?";
        public const string getAssetTypeAttributesUrl = "api/assets/AssetAttribute/assetTypeAttributes";
        public const string getAssetTypeAttributeTypePropertiesUrl = "api/assets/AssetAttribute/assetTypeAttributeTypeProperties";
        public const string getCalculations = "/api/Asset/Models";
        public static Dictionary<String, String> customer_Id = new Dictionary<string, string>();
        public static Dictionary<String, String> Queryparams = new Dictionary<string, string>();
        public const string custId = "sit2";

        public const string authenticationUrl = "https://login.windows.net/f0269474-ac95-4f5b-95a9-f7a8abe779b3/oauth2/token";
        public const string clientId = "1a02a74e-81bd-4ddc-a744-307415b27567";
        public const string clientSecret = "9LQ0IiIZyD_QMM89FCnK~qlz6_I90Tu_-S";

        public const string iot_url = "https://t01atqacloudapp.testqa-cbp.honeywell.com/api/systems/";
        public const string guid = "0894255b-68f9-45ff-a0a3-f6e6f36a9e14";
        public const string tagvalue_url = "/points/history/last";
        public const string taglist_url = "/points/list/recent";
        public const string pointshistory_url = "/points/history/interval";

        /*Stage*/
       // public const string dsServer = "https://hcp-apm-ui-services-api-jahxcjzm-qrfqlazf-dqxhkanx.apps.dev.aro.forgeapp.honeywell.com";
        /*QA*/
        public const string dsServer = "https://hcp-apm-ui-services-api-jahxcjzm-pnwwikhh-dqxhkanx.apps.dev.aro.forgeapp.honeywell.com";
        public const string dsURL = "/api/v1/datasources/";
        public const string iotHealthTagURL = "/api/v1/datasources/:name/healthtags/iot";
        public const string engineHealthTagURL = "/api/v1/datasources/:name/healthtags/engine";

        public const string tsdb_server = "http://10.23.4.15:80/ForgeApps/ApmTsdbService";
        public const string tagDataURL = "/api/History/ReadTagData";

        public const string token = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6InB1YmxpYzpkZWU4MGRkNC0wODE1LTQ3ZTItOGZmMy0wMGRhOWZkNWY5NzgiLCJ0eXAiOiJKV1QifQ.eyJhdWQiOltdLCJjbGllbnRfaWQiOiJxYS0xIiwiZXhwIjoxNjI3MzE2MjY0LCJleHQiOnsiY3VzdG9tZXIiOiJob25leXdlbGwifSwiaWF0IjoxNjI3MzEyNjY0LCJpc3MiOiJodHRwczovL2ZvcmdlLWlkZW50aXR5LXFhLmRldi5zcGVjLmhvbmV5d2VsbC5jb20vIiwianRpIjoiZmQ3ZmVmYmMtZDAzNS00NjM5LTk5N2QtYmZjZmU4MGJkZjhiIiwibmJmIjoxNjI3MzEyNjY0LCJzY3AiOlsib3BlbmlkIiwiZm9yZ2UuYWNjZXNzIl0sInN1YiI6ImU5ZWMzMmEyLTE3OTgtNjIxZS00YmVmLTc1M2M0ODAzYmNkOCJ9.uwUit8UZ89sbXM2NUeB6RZZV1uELNslayXPrFeolXtUFzSNrQcxcWWc2irpgnMvXXYgel_fE8XK_xMI2gLCezhOdChwxKjxFnVFfDbCvp7DuqluF9s4KnxSxS5SxDOTBPtbb6JncLqyfyJsA5arvX7LlnNNkyFPRKd41hjl2ilAsRIhPVLFkV18idRbIrf-oQnxM-Vh9PkIEhILBu4NIbRQN1r1fcpAjCv3YFMP4DkgOCoXDGx1Z8R6MITqdPjW1gAJKAUqPhyx4DK8OxC9hEg5sUKHVzsoN6vQhtTqO_ImiLETwgwU4WnFwMFfhgLbOYcJFod7HUGyrzReRHU4m7kzzQafFG_nUDRxHXNQMatRxrLhor866BeLFkLjrZg4NdU5PCE3eTz9_Vaop8B4thoqmMwtXWOPHOzYKAH6ymvEX0GF5kW0QtPvwvs7qjc-byD-nu4X1GKWBGqbT9BWVLi0C93AkhLG_y2wrcmltABi0sYv3MHFRGHWiIut2Q-wJaqFKCehNbsvDyyMzazem0PhI8Lxf7BcejNtNYvL7robe4vs9k5G0YkDXO51T5lzRMI5IcJ3d687jvJfIzUT9yLpCy75wQLLf0nnvJzAOwHiOYXqewrbbhGRf0nkWdI_5HA1Mn-SN-9BE7vrWQ57fF7ri8sbRLSBbegCj6Kc8OFE";


    }
    
}
