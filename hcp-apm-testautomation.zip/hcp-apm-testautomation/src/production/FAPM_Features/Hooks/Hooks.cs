using AutomationFramework;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using BoDi;
using FAPM_Driver;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net.Mail;
using System.Text;
using TechTalk.SpecFlow;
using FAPM_Driver.Drivers;
using System.Diagnostics;
using System.IO.Compression;
using System.Reflection;
using Newtonsoft.Json;

namespace FAPM_Features.Hooks
{
    [Binding]
    public class Hooks
    {
        private static ExtentTest _feature;
        private ExtentTest _scenario;
        private static AventStack.ExtentReports.ExtentReports _extent;
        private static string PathReport;
        private static string AttachPathReport;
        private static IObjectContainer _objectContainer;
        private ScenarioContext _scenarioContext;
        private ScenarioStepContext _stepContext;
        private FeatureContext _featureContext;
        private static Dictionary<string, ConsoleColor> _featureTitleDic; // = new Dictionary<string, string>();
        private static Dictionary<string, string> _passedDic;
        private static Dictionary<string, string> _failedDic;
        private static Dictionary<string, string> _testCaseCountDic;
        private static int FailedCount = 0;
        private static int PassedCount = 0;
        private static int TotalTestScenarios = 0;
        private static int TotalTestScenarioCount = 0;
        private static int TotalTestFailedCount = 0;
        private static int TotalTestPassedCount = 0;
        private static bool IsFailed = false;

        public Hooks(FeatureContext featureContext, ScenarioContext scenarioContext)
        {
            _featureContext = featureContext;
            if (_feature == null || featureContext.FeatureInfo.Title != _feature.Model.Name)
            {
                _feature = _extent.CreateTest<Feature>(featureContext.FeatureInfo.Title);
            }

            _scenarioContext = scenarioContext;
            _scenario = _feature.CreateNode<Scenario>(scenarioContext.ScenarioInfo.Title);
        }

        [BeforeTestRun]
        public static void ConfigureReport()

        {
            PathReport = Directory.GetCurrentDirectory().Split("bin")[0] + @"TestResults/"; // + @"\..\..\..\..\TestResults\";// + DateTime.Now.ToString("dd MMM hh mm ss tt", CultureInfo.InvariantCulture) + @"\";
            UI_Driver.reportPath = PathReport;
            var reporter = new ExtentHtmlReporter(PathReport);
            
            reporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            _extent = new AventStack.ExtentReports.ExtentReports();
            _extent.AttachReporter(reporter);
            _featureTitleDic = new Dictionary<string, ConsoleColor>();
            _passedDic = new Dictionary<string, string>();
            _failedDic = new Dictionary<string, string>();
            _testCaseCountDic = new Dictionary<string, string>();
        }

        [BeforeFeature]
        [Obsolete]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            FailedCount = 0;
            PassedCount = 0;
            TotalTestScenarios = 0;

            if (FeatureContext.Current.FeatureInfo.Title == "TC06.Monitoring Screen" || FeatureContext.Current.FeatureInfo.Title == "TC09.Performance Overview" || FeatureContext.Current.FeatureInfo.Title == "TC11.Asset Attributes")
            {
                string fileDownloadPath = Directory.GetCurrentDirectory().Split("FAPM_Features")[0] + "File_Downloads";
                if (Directory.Exists(fileDownloadPath))
                {
                    var filecount = Directory.GetFiles(Directory.GetCurrentDirectory().Split("FAPM_Features")[0] + "File_Downloads\\");
                    for (int i = 0; i < filecount.Length; i++)
                    {
                        File.Delete(filecount[i]);
                    }
                }
            }
            if (!_featureTitleDic.ContainsKey(FeatureContext.Current.FeatureInfo.Title))
            {
                _featureTitleDic.Add(FeatureContext.Current.FeatureInfo.Title, ConsoleColor.Green);
            }
        }

        [BeforeScenario]
        public static void CreateScenario(ScenarioContext scenarioContext)
        {
            TotalTestScenarios = TotalTestScenarios + 1;
        }

        [AfterStep]
        public void InsertReportingSteps(ScenarioContext scenarioContext)
        {
            var stepContext = scenarioContext.StepContext;
            var stepType = stepContext.StepInfo.StepDefinitionType.ToString();

            if (_testCaseCountDic.ContainsKey("TestCase Count" + FeatureContext.Current.FeatureInfo.Title))
            {
                _testCaseCountDic["TestCase Count" + FeatureContext.Current.FeatureInfo.Title] = TotalTestScenarios.ToString();
            }
            else
                _testCaseCountDic.Add("TestCase Count" + FeatureContext.Current.FeatureInfo.Title, TotalTestScenarios.ToString());

            if (scenarioContext.TestError == null)
            {
                if (stepType == "Given")
                { _scenario.CreateNode<Given>(stepContext.StepInfo.Text); }
                else if (stepType == "When")
                { _scenario.CreateNode<When>(stepContext.StepInfo.Text); }
                else if (stepType == "Then")
                { _scenario.CreateNode<Then>(stepContext.StepInfo.Text); }
                else if (stepType == "And")
                { _scenario.CreateNode<And>(stepContext.StepInfo.Text); }

            }
            else if (scenarioContext.TestError != null)
            {
                FailedCount = FailedCount + 1;
                IsFailed = true;

                if (_failedDic.ContainsKey("Failed Count" + FeatureContext.Current.FeatureInfo.Title))
                {
                    _failedDic["Failed Count" + FeatureContext.Current.FeatureInfo.Title] = FailedCount.ToString();
                }
                else
                    _failedDic.Add("Failed Count" + FeatureContext.Current.FeatureInfo.Title, FailedCount.ToString());


                if (stepType == "Given")
                {
                    string filepath = Driver_UI.screenshotpath;
                    //filepath = filepath.Replace(" ", "%20");
                    filepath = "./Screenshots" + filepath.Split("Screenshots")[1];
                    _scenario.CreateNode<Given>(stepContext.StepInfo.Text).Fail(scenarioContext.TestError.Message + "\n\n" + "<img src=" + filepath + " title =" + "ErrorScreenshot" + ">");
                }
                else if (stepType == "When")
                {
                    string filepath = Driver_UI.screenshotpath;
                    //filepath = filepath.Replace(" ", "%20");
                    filepath = "./Screenshots" + filepath.Split("Screenshots")[1];
                    _scenario.CreateNode<When>(stepContext.StepInfo.Text).Fail(scenarioContext.TestError.Message + "\n\n" + "<img src=" + filepath + " title=" + "ErrorScreenshot" + ">");
                }
                else if (stepType == "Then")
                {
                    string filepath = Driver_UI.screenshotpath;
                    //filepath = filepath.Replace(" ", "%20");
                    filepath = "./Screenshots" + filepath.Split("Screenshots")[1];
                    _scenario.CreateNode<Then>(stepContext.StepInfo.Text).Fail(scenarioContext.TestError.Message + "\n\n" + "<img src=" + filepath + " title=" + "ErrorScreenshot" + ">");
                }
                //else if (stepType == "And")
                //{
                //    string filepath = Driver_UI.screenshotpath;
                //    filepath = filepath.Replace(" ", "%20");
                //    _scenario.CreateNode<And>(stepContext.StepInfo.Text).Fail(scenarioContext.TestError.Message + "\n\n" + "<img src=" + filepath + " title=" + "ErrorScreenshot" + ">");
                //}

                if (_featureTitleDic.ContainsKey(FeatureContext.Current.FeatureInfo.Title) &&
                    (_featureTitleDic[FeatureContext.Current.FeatureInfo.Title].Equals(ConsoleColor.Green)))
                {
                    _featureTitleDic[FeatureContext.Current.FeatureInfo.Title] = ConsoleColor.Red;
                }
            }
        }

        [AfterScenario]
        public void AfterScenario(ScenarioContext scenarioContext)
        {
            Console.WriteLine("AfterScenario");
        }

        [AfterFeature]
        public static void AfterFeature(FeatureContext featureContext)
        {
            Console.WriteLine("AfterFeature");
            UI_Driver.Close();
        }

        [AfterTestRun]
        public static void FlushExtent()
        {
            foreach (var web in Process.GetProcessesByName("MicrosoftWebDriver"))
                web.Kill();
            _extent.Flush();
            string dashboardpath = PathReport + @"\dashboard.html";
            if (File.Exists(dashboardpath))
            {
                string dashboarddata = File.ReadAllText(dashboardpath);
                dashboarddata = dashboarddata.Replace("others", "skipped");
                File.WriteAllText(dashboardpath, dashboarddata);
            }
            string zipPath = Directory.GetCurrentDirectory().Split("bin")[0] + @"TestResults.zip"; // + @"\..\..\..\..\TestResults\APM_Test_Report.zip";
            if (File.Exists(zipPath))
            {
                File.Delete(zipPath);
            }
            ZipFile.CreateFromDirectory(PathReport, zipPath);
            AttachPathReport = zipPath;
            EmailGeneration();
            GetReports();
        }

        public static void EmailGeneration()
        {
            try
            {
                MailMessage mail = new MailMessage();
                using (SmtpClient SmtpServer = new SmtpClient())
                {
                    SmtpServer.Host = "smtp.honeywell.com";
                    SmtpServer.EnableSsl = true;
                    mail.From = new MailAddress("raunak.kumarjha@honeywell.com", "SystemTestTeam", Encoding.UTF8);
                    //foreach (var email_to in Environment_Values.email_address_to)
                    mail.To.Add("krishna.pillutla@honeywell.com");
                    //foreach (var email_cc in Environment_Values.email_address_cc)
                    //mail.CC.Add("vineet.agrawal@honeywell.com");
                    mail.CC.Add("mrajendra.naidu@honeywell.com");
                    mail.CC.Add("raunak.kumarjha@honeywell.com");
                    mail.CC.Add("pavankumar.duvvuri@honeywell.com");
                    //mail.CC.Add("savya.ananda@honeywell.com");
                    //mail.CC.Add("rakesh.ar@honeywell.com");
                    //mail.CC.Add("lakshmi.kishore@honeywell.com");
                    //mail.CC.Add("swathi.radhakrishnan@honeywell.com");
                    //mail.CC.Add("cheruvu.zeelani@honeywell.com");
                    mail.Subject = "FORGE APM - Data API and Dashboard UI Test Report_" + DateTime.Now.ToString();
                    mail.IsBodyHtml = true;
                    mail.Body = GetEmailBodyContent();
                    string[] reportFiles = Directory.GetFiles(PathReport, "*.html");
                    foreach (string report in reportFiles)
                    {
                        Attachment attachment = new Attachment(report);
                        mail.Attachments.Add(attachment);
                    }
                    SmtpServer.Port = 25;
                    SmtpServer.UseDefaultCredentials = true;
                    SmtpServer.Credentials = new System.Net.NetworkCredential("", "");
                    SmtpServer.EnableSsl = true;
                    //SmtpServer.TargetName = "SMTPSVC/smtp.honeywell.com";
                    //SmtpServer.Send(mail);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static string GetEmailBodyContent()
        {
            string emailBody = @"
                                <html xmlns:v='urn:schemas-microsoft-com:vml' xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns:m='http://schemas.microsoft.com/office/2004/12/omml' xmlns='http://www.w3.org/TR/REC-html40'>
	                                <head>
		                                <meta http-equiv=Content-Type content='text/html; charset=us-ascii'>
		                                <meta name=Generator content='Microsoft Word 15 (filtered medium)'>
		                                <style>
			                                <!--
			                                /* Font Definitions */
			                                @font-face
				                                {font-family:'Cambria Math';
				                                panose-1:2 4 5 3 5 4 6 3 2 4;}
			                                @font-face
				                                {font-family:DengXian;
				                                panose-1:2 1 6 0 3 1 1 1 1 1;}
			                                @font-face
				                                {font-family:Calibri;
				                                panose-1:2 15 5 2 2 2 4 3 2 4;}
			                                @font-face
				                                {font-family:'\@DengXian';
				                                panose-1:2 1 6 0 3 1 1 1 1 1;}
			                                /* Style Definitions */
			                                p.MsoNormal, li.MsoNormal, div.MsoNormal
				                                {margin:0cm;
				                                margin-bottom:.0001pt;
				                                font-size:11.0pt;
				                                font-family:'Calibri',sans-serif;}
			                                a:link, span.MsoHyperlink
				                                {mso-style-priority:99;
				                                color:#0563C1;
				                                text-decoration:underline;}
			                                a:visited, span.MsoHyperlinkFollowed
				                                {mso-style-priority:99;
				                                color:#954F72;
				                                text-decoration:underline;}
			                                p.msonormal0, li.msonormal0, div.msonormal0
				                                {mso-style-name:msonormal;
				                                mso-margin-top-alt:auto;
				                                margin-right:0cm;
				                                mso-margin-bottom-alt:auto;
				                                margin-left:0cm;
				                                font-size:11.0pt;
				                                font-family:'Calibri',sans-serif;}
			                                span.EmailStyle18
				                                {mso-style-type:personal;
				                                font-family:'Calibri',sans-serif;}
			                                span.EmailStyle20
				                                {mso-style-type:personal-reply;
				                                font-family:'Calibri',sans-serif;}
			                                .MsoChpDefault
				                                {mso-style-type:export-only;
				                                font-size:10.0pt;}
			                                @page WordSection1
				                                {size:612.0pt 792.0pt;
				                                margin:72.0pt 72.0pt 72.0pt 72.0pt;}
			                                div.WordSection1
				                                {page:WordSection1;}
			                                -->
		                                </style>
		                                <!--
		                                [if gte mso 9]>
			                                <xml>
				                                <o:shapedefaults v:ext='edit' spidmax='1026' />
			                                </xml>
		                                <![endif]
		                                -->
		                                <!--
		                                [if gte mso 9]>
			                                <xml>
				                                <o:shapelayout v:ext='edit'>
				                                <o:idmap v:ext='edit' data='1' />
				                                </o:shapelayout>
			                                </xml>
		                                <![endif]
		                                -->
	                                </head>
	                                <body lang=EN-IN link='#0563C1' vlink='#954F72'>
		                                <div class=WordSection1>
			                                <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=250 style='width:550pt;border-collapse:collapse'>
				                                <tr style='height:25.6pt'>
					                                <td valign=top style='width:80*;border:solid white 1.0pt;border-bottom:solid white 3.0pt;background:#C9CACC;padding:3.6pt 7.2pt 3.6pt 7.2pt;height:25.6pt'>
						                                <p class=MsoNormal align=center style='text-align:center'>
							                                <b>
								                                <span lang=DE style='font-size:12.0pt;font-family:""Arial"",sans-serif;color:black'>Feature File Name</span>
                                                            </b>
                                                            <span style = 'font-size:12.0pt;font-family:""Arial"",sans-serif'><o:p></o:p></span>       
                                                        </p>       
                                                    </td>       
                                                     <td valign = top style = 'width:20*;border-top:solid white 1.0pt;border-left:none;border-bottom:solid white 3.0pt;border-right:solid white 1.0pt;background:#C9CACC;padding:3.6pt 7.2pt 3.6pt 7.2pt;height:25.6pt' >          
                                                        <p class=MsoNormal align = center style='text-align:center'>
							                                <b>
								                                <span lang = DE style='font-size:12.0pt;font-family:""Arial"",sans-serif;color:black'>Result</span>
							                                 </b>
							                                 <span style = 'font-size:12.0pt;font-family:""Arial"",sans-serif' ><o:p></o:p></span>
						                                </p>
					                                </td>
                                                    <td valign = top style = 'width:20*;border-top:solid white 1.0pt;border-left:none;border-bottom:solid white 3.0pt;border-right:solid white 1.0pt;background:#C9CACC;padding:3.6pt 7.2pt 3.6pt 7.2pt;height:25.6pt' >          
                                                        <p class=MsoNormal align = center style='text-align:center'>
							                                <b>
								                                <span lang = DE style='font-size:12.0pt;font-family:""Arial"",sans-serif;color:black'>Total Scenarios</span>
							                                 </b>
							                                 <span style = 'font-size:12.0pt;font-family:""Arial"",sans-serif' ><o:p></o:p></span>
						                                </p>
					                                </td>
                                                     <td valign = top style = 'width:20*;border-top:solid white 1.0pt;border-left:none;border-bottom:solid white 3.0pt;border-right:solid white 1.0pt;background:#C9CACC;padding:3.6pt 7.2pt 3.6pt 7.2pt;height:25.6pt' >          
                                                        <p class=MsoNormal align = center style='text-align:center'>
							                                <b>
								                                <span lang = DE style='font-size:12.0pt;font-family:""Arial"",sans-serif;color:black'>Failed Scenarios</span>
							                                 </b>
							                                 <span style = 'font-size:12.0pt;font-family:""Arial"",sans-serif' ><o:p></o:p></span>
						                                </p>
					                                </td>
                                                    <td valign = top style = 'width:20*;border-top:solid white 1.0pt;border-left:none;border-bottom:solid white 3.0pt;border-right:solid white 1.0pt;background:#C9CACC;padding:3.6pt 7.2pt 3.6pt 7.2pt;height:25.6pt' >          
                                                        <p class=MsoNormal align = center style='text-align:center'>
							                                <b>
								                                <span lang = DE style='font-size:12.0pt;font-family:""Arial"",sans-serif;color:black'>Passed Scenarios</span>
							                                 </b>
							                                 <span style = 'font-size:12.0pt;font-family:""Arial"",sans-serif' ><o:p></o:p></span>
						                                </p>
					                                </td>
				                                </tr>"
                                                + GetEmailRowData() +
                                          $@"</table>
		                                </div>
	                                </body>
                                </html>
                                ";
            return emailBody;
        }

        public static string GetEmailRowData()
        {
            string failedCount = "";
            string passedCount = "";
            string testcaseCount = "";
            System.Text.StringBuilder rowBuilder = new StringBuilder();

            foreach (var featureTitle in _featureTitleDic)
            {
                if (_failedDic.Count > 0 && _failedDic.ContainsKey("Failed Count" + featureTitle.Key)) 
                {
                    failedCount = _failedDic["Failed Count" + featureTitle.Key];
                }
                else
                    failedCount = "0";
                if (_testCaseCountDic.Count > 0)
                {
                    testcaseCount = _testCaseCountDic["TestCase Count" + featureTitle.Key];
                }
                else
                    testcaseCount = "0";
                passedCount = (Convert.ToInt32(testcaseCount) - Convert.ToInt32(failedCount)).ToString();
                TotalTestScenarioCount += Convert.ToInt32(testcaseCount);
                TotalTestFailedCount += Convert.ToInt32(failedCount);
                TotalTestPassedCount += Convert.ToInt32(passedCount);

                rowBuilder.AppendLine($@"
                                        <tr style = 'height:25.6pt' >
                                            <td valign=center style = 'width:80*;/*border:solid white 1.0pt;*/border-top:none;background:#EBECEC;height:25.6pt' > 
                                                <p style='text-align:center'> {featureTitle.Key} </p> 
                                            </td>

                                            <td valign=center style = 'width:20*;border-top:none;border-left:none;border-bottom:solid white 1.0pt;border-right:solid white 1.0pt;background:#EBECEC;height:25.6pt' >
                                                <p align=center style = 'text-align:center'>   
                                                    <span style='font-size:10.0pt;font-family:Wingdings;color:{featureTitle.Value}'>n</span>
                              </p>
                             </td>

 <td valign=center style = 'width:80*;/*border:solid white 1.0pt;*/border-top:none;background:#EBECEC;height:25.6pt' > 
                                                <p style='text-align:center'> {testcaseCount} </p> 
                                            </td>
                                            <td valign=center style = 'width:80*;/*border:solid white 1.0pt;*/border-top:none;background:#EBECEC;height:25.6pt' > 
                                                <p style='text-align:center'> {failedCount} </p> 
                                            </td>
                                            <td valign=center style = 'width:80*;/*border:solid white 1.0pt;*/border-top:none;background:#EBECEC;height:25.6pt' > 
                                                <p style='text-align:center'> {passedCount} </p> 
                                            </td>
				                        </tr>
                                       ");
            }

            return rowBuilder.ToString();
        }

        public static string GetReports()
        {
            var raw_data = new Reader().GetHtml("FAPM_Features.Results.json");
            var items = JsonConvert.DeserializeObject<dynamic>(raw_data);
            Console.WriteLine("inside Hooks->JsonReport");
            var value = Environment.GetEnvironmentVariable("uuid");
            Console.WriteLine("UUID" + value);
            items["testrun"] = value;
            items["no_passed"] = TotalTestPassedCount;
            items["no_failed"] = TotalTestFailedCount;

            string json = JsonConvert.SerializeObject(items);
            System.IO.File.WriteAllText(Directory.GetCurrentDirectory().Split("bin")[0] + "Results.json", json);


            return "success";
        }

        public class Reader
        {
            public string GetHtml(string file)
            {
                using (var resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(file))
                {
                    if (resourceStream == null)
                        return null;

                    using (StreamReader reader = new StreamReader(resourceStream))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }



        }
    }

}
