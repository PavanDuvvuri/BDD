﻿using System;
using System.Collections.Generic;
using System.Net;
using FAPM_Driver;
using FAPM_Driver.Helpers;
using FAPM_Driver.Share;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class KpiTargetImportExportSteps
    {
        [Given(@"a target file is available to the user")]
        public void GivenATargetFileIsAvailableToTheUser()
        {
            Console.WriteLine("demo");
        }

        [When(@"A request is placed with (.*) to import the target file (.*)")]
        public void WhenARequestIsPlacedWithToImportTheTargetFile(string custid, string filepath)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            var status = Driver.KPI_Target_Import_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetimportQueryUrl, filepath, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"import should be successful")]
        public void ThenImportShouldBeSuccessful()
        {
            Assert.AreEqual(HttpStatusCode.Created.ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed with (.*) to import a file with headers and empty data (.*)")]
        public void WhenARequestIsPlacedWithToImportAFileWithHeadersAndEmptyData(string custid, string filepath)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            var status = Driver.KPI_Target_Import_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetimportQueryUrl, filepath, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._failure, status);
        }

        [When(@"A request is placed with (.*) to import the empty target file (.*)")]
        public void WhenARequestIsPlacedWithToImportTheEmptyTargetFile(string custid, string filepath)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            var status = Driver.KPI_Target_Import_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetimportQueryUrl, filepath, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._failure, status);
        }


        [Then(@"target service should throw error")]
        public void ThenTargetServiceShouldThrowError()
        {
            Assert.AreEqual((HttpStatusCode.InternalServerError).ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed with (.*) and asset name (.*) to export the target file")]
        public void WhenARequestIsPlacedWithAndAssetNameToExportTheTargetFile(string p0, string p1)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", p0);
            var status = Driver.KPITarget_Export_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetexportQueryUrl, p1, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"export should be successful")]
        public void ThenExportShouldBeSuccessful()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [Given(@"a API is up and running")]
        public void GivenAAPIIsUpAndRunning()
        {
            Console.WriteLine("demo");
        }

        [When(@"A request is placed with (.*), (.*), (.*), (.*) and (.*)")]
        public void WhenARequestIsPlacedWithAnd(string custid, string assetname, string effectivedate, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("Asset", assetname);
            Queryparams.Add("EffectiveDate", effectivedate);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            var response = Driver.KPI_Target_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetUrl, Common.Inputs.API_urls.customer_Id, Queryparams);

            Assert.AreEqual(Driver._success, response);
        }

        [Then(@"the service should return that Kpi data for that asset (.*)")]
        public void ThenTheServiceShouldReturnThatKpiDataForThatAsset(string assetname)
        {
            Assert.AreEqual(Out_Values.KPIApi_json[0]["asset"].ToString(), assetname);
            // Assert.AreEqual(Out_Values.KPIApi_json[0]["kpi"].ToString(), "KPI9");
        }

        [When(@"A request is placed with (.*), without assetname (.*), (.*) and (.*)")]
        public void WhenARequestIsPlacedWithAndWithoutAssetname(string custid, string effectivedate, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("EffectiveDate", effectivedate);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            var response = Driver.KPI_Target_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._success, response);
        }

        [Then(@"the service should return the response")]
        public void ThenTheServiceShouldReturnTheResponse()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
            Assert.AreEqual("100", Out_Values.KPIApi_json[0]["deviationLimit"].ToString());
            // Assert.IsNotEmpty(Out_Values.KPIApi_json);
        }

        [When(@"A request is placed with (.*), KPI names (.*) Dates (.*), (.*) and (.*)")]
        public void WhenARequestIsPlacedWithKPINamesDatesAnd(string custid, string kpiname, string effectivedate, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KPI", kpiname);
            Queryparams.Add("EffectiveDate", effectivedate);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            var response = Driver.KPI_Target_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpitargetUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._success, response);
        }

        [Then(@"the service should return that Kpi data(.*) for that asset")]
        public void ThenTheServiceShouldReturnThatKpiDataForThatAsset_(string kpiname)
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(kpiname, Out_Values.KPIApi_json[0]["kpi"].ToString());
        }

        [When(@"A request is placed with (.*) to post the report configutarion with attributes (.*), (.*), (.*), (.*), (.*)")]
        public void WhenARequestIsPlacedWithToPostTheReportConfigutarionWithAttributes(string custid, string name, string displayName, string anchortime, string duration, string interval)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> param = new Dictionary<string, string>();
            param.Add("Name", name);
            param.Add("DisplayName", displayName);
            param.Add("AnchorTime", anchortime);
            param.Add("Duration", duration);
            param.Add("Interval", interval);
            Driver.ReportConfiguration(Common.Inputs.API_urls.Kpiserver, Common.Inputs.API_urls.ReportConfigUrl, Common.Inputs.API_urls.customer_Id, param);
            ForgeAPMSQL.DeleteReportConfigData(name);
        }
        
        [Then(@"the service should return success")]
        public void ThenTheServiceShouldReturnSuccess()
        {
            Assert.AreEqual(HttpStatusCode.Created.ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed twice with (.*) to post the report configutarion with attributes (.*), (.*), (.*), (.*), (.*)")]
        public void WhenARequestIsPlacedTwiceWithToPostTheReportConfigutarionWithAttributes(string custid, string name, string displayName, string anchortime, string duration, string interval)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> param = new Dictionary<string, string>();
            param.Add("Name", name);
            param.Add("DisplayName", displayName);
            param.Add("AnchorTime", anchortime);
            param.Add("Duration", duration);
            param.Add("Interval", interval);
            Driver.ReportConfiguration(Common.Inputs.API_urls.Kpiserver, Common.Inputs.API_urls.ReportConfigUrl, Common.Inputs.API_urls.customer_Id, param);
            Driver.ReportConfiguration(Common.Inputs.API_urls.Kpiserver, Common.Inputs.API_urls.ReportConfigUrl, Common.Inputs.API_urls.customer_Id, param);
            ForgeAPMSQL.DeleteReportConfigData(name);
        }

        [Then(@"the service should return error message (.*)")]
        public void ThenTheServiceShouldReturnError(string errormessage)
        {
            Assert.AreEqual(HttpStatusCode.BadRequest.ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(errormessage, Out_Values.KPIApi_json["message"].ToString());
        }

    }
}