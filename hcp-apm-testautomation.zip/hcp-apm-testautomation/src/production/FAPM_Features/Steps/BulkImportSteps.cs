﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using TechTalk.SpecFlow;
using FAPM_Driver;
using FAPM_Driver.AutomationModel;
using FAPM_Driver.Drivers;
using AutomationFramework;
using System.Linq;
using FAPM_Driver.Share;
using NUnit.Framework;

namespace FAPM_Features.Steps
{
    [Binding]
    public class BulkImportSteps
    {
        [Given(@"An user is navigated to Forge APM landing page\.")]
        public void GivenAnUserIsNavigatedToForgeAPMLandingPage_()
        {
            Driver_UI.Launch_ForgeAPMPage();
        }

        [Given(@"Login using the valid credentials")]
        public void GivenLoginUsingTheValidCredentials()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.username_header, 30);
            UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name);
            UI_Driver.Click(PODashboard.next_button);
            UI_Driver.Wait(5000);
            ProcessStartInfo psi = new ProcessStartInfo(@"D:\MyProjects\FAPM_Automation\Autoit_Script\Login.exe");
            Process proc = Process.Start(psi);
            proc.WaitForExit();
            UI_Driver.WaitUntilElementExists(PODashboard.user_name, 90);
            UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name);
            UI_Driver.WaitUntilElementExists(PODashboard.password, 90);
            UI_Driver.EnterText(Environment_Values.password, PODashboard.password);
            UI_Driver.Click(PODashboard.sign_in);
            UI_Driver.WaitUntilElementExists(PODashboard.forge_title, 90);
        }


        [Given(@"user navigates to Bulk model configuration dashboard")]
        public void GivenUserNavigatesToBulkModelConfigurationDashboard()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.menu_button, 30);
            UI_Driver.Click(PODashboard.menu_button);
            UI_Driver.WaitUntilElementExists(PODashboard.config_button, 30);
            UI_Driver.Click(PODashboard.config_button);
            UI_Driver.WaitUntilElementExists(PODashboard.bulk_config_dashboard_title, 30);
            UI_Driver.textDisplayed(PODashboard.bulk_config_dashboard_title);
            UI_Driver.Click(PODashboard.menu_button);
        }

        [When(@"user clicks on reset files button on the import files pop up")]
        public void WhenClickOnResetFilesButtonOnTheImportFilesPopUp()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.reset_file_button, 30);
            UI_Driver.Click(PODashboard.reset_file_button);
        }

        [Then(@"Verify that the selectd file should be undo")]
        public void ThenVerifyThatTheSelectdFileShouldBeUndo()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.browse_files, 30);
            UI_Driver.ElementIsDisplayed(PODashboard.browse_files);
            UI_Driver.ElementIsNotDisplayed(PODashboard.reset_file_button);
        }

        [When(@"Upload a file (.*) with action column as (.*) for all assets")]
        public void WhenUploadAFileAndWithActionColumnAsForAllAssets(string fileName, string action)
        {
            UI_Driver.Click(PODashboard.import_button);
            UI_Driver.WaitUntilElementExists(PODashboard.import_files_header_text, 30);
            UI_Driver.textDisplayed(PODashboard.import_files_header_text);
            UI_Driver.textDisplayed(PODashboard.message_text);
            UI_Driver.Click(PODashboard.browse_files);
            var filePath = Out_Values.filePath + fileName;
            Driver_UI.Upload_file(filePath, fileName, action);
            UI_Driver.ElementIsDisplayed(PODashboard.reset_file_button);
        }

        [When(@"A user uploads a file (.*) with action column as (.*) for all assets")]
        public void WhenAUserUploadsAFileAndWithActionColumnAsForAllAssets( string fileName, string action)
        {
            UI_Driver.Click(PODashboard.import_button);
            UI_Driver.WaitUntilElementExists(PODashboard.import_files_header_text, 30);
            UI_Driver.textDisplayed(PODashboard.import_files_header_text);
            UI_Driver.textDisplayed(PODashboard.message_text);
            UI_Driver.Click(PODashboard.browse_files);
            var filePath = Out_Values.filePath + fileName;
            Driver_UI.Upload_file(filePath, fileName, action);
            UI_Driver.ElementIsDisplayed(PODashboard.reset_file_button);
            UI_Driver.Click(PODashboard.next_button);
            UI_Driver.WaitUntilElementExists(PODashboard.success_message, 30);
            UI_Driver.WaitUntilElementExists(PODashboard.proceed_button, 30);
            UI_Driver.Click(PODashboard.proceed_button);
            UI_Driver.textDisplayed(PODashboard.bulk_config_dashboard_title);
        }

        [Then(@"Verify the success message and the given assets (.*) are created successfully")]
        public void ThenSuccessMessageShouldBeReturnedToTheUser(string assetName)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 300);
            Out_Values.filterOptions.Add("AssetName", null);

            Driver.getAssets(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);

            string[] assetNames = assetName.Split(",");
            foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_name["name"]);
            }
            Assert.Contains(assetNames[0], Out_Values.HelperList);
            Assert.Contains(assetNames[1], Out_Values.HelperList);
        }

        [Then(@"Verify the success message and data for the given assets (.*) are not created or updated")]
        public void ThenVerifyTheSuccessMessageAndDataForTheGivenAssetsAreNotCreatedOrUpdated(string assetName)
        {
            string[] assetNames = assetName.Split(",");
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 300);
            Out_Values.filterOptions.Add("AssetName", null);

            Driver.getAssets(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);

            foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_name["name"]);
            }
            Assert.IsEmpty(Out_Values.HelperList);
        }

        [Then(@"Verify the given assets (.*) are updated successfully")]
        public void ThenVerifyTheGivenAssetsEnterpriseAreUpdatedSuccessfully(string assetName)
        {
            string[] assetNames = assetName.Split(",");
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", "idd7d9dccd-d29a-44af-bbdf-6a86e584b21c");
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 200);
            Out_Values.filterOptions.Add("AssetName", null);

            Driver.getAssets(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);

            foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_name["name"]);
            }
            Assert.Contains(assetNames[0], Out_Values.HelperList);
            Assert.Contains(assetNames[1], Out_Values.HelperList);
        }

        [Then(@"Verify the data for the given asset (.*) attributes (.*) are not created or updated")]
        public void ThenVerifyTheDataForTheGivenAssetsEnterpriseAreNotCreatedOrUpdated(string assetName, string attrValue)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            const int pageNumber = 1;
            const int pageSize = 1000;
            var asset_name = assetName;
            const string asset_type = null;

            Driver.getAssetAttribute(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetAttributeUrl, pageNumber, pageSize, asset_name, asset_type, Common.Inputs.API_urls.customer_Id);

            foreach (var attrList in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)attrList["attributeValue"]);
            }
            Assert.Contains(attrValue, Out_Values.HelperList);
        }

        [Then(@"Verify the given asset (.*) attribuites (.*) are updated successfully")]
        public void ThenVerifyTheGivenAssetAttribuitesAssetStatusAreUpdatedSuccessfully(string assetName, string attrValue)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            var pageNumber = 1;
            var pageSize = 1000;
            var asset_name = assetName;
            const string asset_type = null;

            Driver.getAssetAttribute(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetAttributeUrl, pageNumber, pageSize, asset_name, asset_type, Common.Inputs.API_urls.customer_Id);

            foreach (var attrList in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)attrList["attributeValue"]);
            }
            Assert.Contains(attrValue, Out_Values.HelperList);
        }

        [Then(@"Verify the given asset attribute property (.*) is updated successfully")]
        public void ThenVerifyTheGivenAssetsIsUpdatedSuccessfully(int attrPropertyValue)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 100);
            Out_Values.filterOptions.Add("AssetName", null);

            Driver.getAssetAttributeProperties(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetAttributeUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);
            foreach (var attr_property in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)attr_property["attribPropertyDetailsList"]["valueRef"]);
            }
            Assert.Contains(attrPropertyValue, Out_Values.HelperList);
        }

        [Then(@"Verify the given asset attribute property (.*) is not updated")]
        public void ThenVerifyTheGivenAssetAttributePropertyLowLimitIsNotUpdated(int attrPropertyValue)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 100);
            Out_Values.filterOptions.Add("AssetName", null);

            Driver.getAssetAttributeProperties(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetAttributeUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);
            foreach (var attr_property in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)attr_property["attribPropertyDetailsList"]["valueRef"]);
            }
            Assert.Contains(attrPropertyValue, Out_Values.HelperList);
        }

        [Then(@"Verify that calculations are created for the given assets (.*) successfully")]
        public void ThenVerifyThatCalculationsAreCreatedForTheGivenAssetsSuccessfully(string assetNames)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 100);
            Out_Values.filterOptions.Add("AssetName", null);
            Driver.getAssetModels(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetModelsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);
            foreach (var asset_calculation in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_calculation["assetName"]);
            }
            string[] assetNamesList = assetNames.Split(",");
            Assert.Contains(assetNamesList[0], Out_Values.HelperList);
            Assert.Contains(assetNamesList[1], Out_Values.HelperList);
        }

        [When(@"A user uploads a file (.*) with LoadSheet option in BulkLoadOptions sheet with action (.*)")]
        public void WhenAUserUploadsAFileCreate_Assets_Attrs_Props_Calcs_XlsxWithLoadSheetOptionInBulkLoadOptionsSheet(string fileName, string action)
        {
            //UI_Driver.Click(PODashboard.import_button);
            //UI_Driver.WaitUntilElementExists(PODashboard.import_files_header_text, 30);
            //UI_Driver.textDisplayed(PODashboard.import_files_header_text);
            //UI_Driver.textDisplayed(PODashboard.message_text);
            //UI_Driver.Click(PODashboard.browse_files);
            //var filePath = Out_Values.filePath + fileName;
            //Driver_UI.Upload_file(filePath, fileName, action);
            //UI_Driver.ElementIsDisplayed(PODashboard.reset_file_button);
            //UI_Driver.Click(PODashboard.next_button);
            //UI_Driver.WaitUntilElementExists(PODashboard.success_message, 30);
            //UI_Driver.WaitUntilElementExists(PODashboard.proceed_button, 30);
            //UI_Driver.Click(PODashboard.proceed_button);
            //UI_Driver.textDisplayed(PODashboard.bulk_config_dashboard_title);
            Console.WriteLine("*******");
        }

        [Then(@"Verify the given assets (.*) created with the necessary values")]
        public void ThenVerifyTheGivenAssetsCP_LOSS_SITCP_SSS_SITCreatedWithTheNecessaryValues(string assetNames)
        {
            Console.WriteLine("*******");
            //Common.Inputs.API_urls.customer_Id.Clear();
            //Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            //Out_Values.filterOptions.Clear();
            //Out_Values.filterOptions.Add("PageNumber", 1);
            //Out_Values.filterOptions.Add("PageSize", 100);
            //Out_Values.filterOptions.Add("AssetName", null);
            //Driver.getAssetModels(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetModelsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);
            //foreach (var asset_calculation in Out_Values.ApiJsonOutput[0])
            //{
            //    Out_Values.HelperList.Add((string)asset_calculation["assetName"]);
            //}
            //string[] assetNamesList = assetNames.Split(",");
            //Assert.Contains(assetNamesList[0], Out_Values.HelperList);
            //Assert.Contains(assetNamesList[1], Out_Values.HelperList);

            //Driver.getAssets(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);

            //foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            //{
            //    Out_Values.HelperList.Add((string)asset_name["name"]);
            //}
            //Assert.Contains(assetNamesList[0], Out_Values.HelperList);
            //Assert.Contains(assetNamesList[1], Out_Values.HelperList);

            //const int pageNumber = 1;
            //const int pageSize = 1000;
            //var assetName = assetNamesList[0];
            //const string asset_type = null;

            //Driver.getAssetAttribute(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetAttributeUrl, pageNumber, pageSize, asset_name, asset_type, Common.Inputs.API_urls.customer_Id);

            //foreach (var attrList in Out_Values.ApiJsonOutput[0])
            //{
            //    Out_Values.HelperList.Add((string)attrList["attributeValue"]);
            //}
            //Assert.Contains(attrValue, Out_Values.HelperList);
        }

        [Then(@"Verify the given assets (.*) calculations should not updated/created")]
        public void ThenVerifyTheGivenAssetsCP_LOSS_SITCP_SSS_SITCalculationsShouldNotUpdatedCreated(string assetNames)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", Common.Inputs.API_urls.custId);
            Out_Values.filterOptions.Clear();
            Out_Values.filterOptions.Add("PageNumber", 1);
            Out_Values.filterOptions.Add("PageSize", 100);
            Out_Values.filterOptions.Add("AssetName", null);
            Driver.getAssetModels(Common.Inputs.API_urls.modelServer + Common.Inputs.API_urls.getAssetModelsUrl, Out_Values.filterOptions, Common.Inputs.API_urls.customer_Id);
            foreach (var asset_calculation in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_calculation["assetName"]);
            }
            string[] assetNamesList = assetNames.Split(",");
            Assert.Contains(assetNamesList[0], Out_Values.HelperList);
            Assert.Contains(assetNamesList[1], Out_Values.HelperList);
        }
    }
}
