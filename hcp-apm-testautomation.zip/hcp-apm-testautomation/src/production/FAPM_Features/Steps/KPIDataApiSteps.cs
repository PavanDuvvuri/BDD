﻿using System;
using TechTalk.SpecFlow;
using FAPM_Driver.Helpers;
using FAPM_Driver;
using NUnit.Framework;
using FAPM_Driver.Share;
using System.Net;

namespace FAPM_Features.Steps
{
    [Binding]
    public class KPIDataApiSteps
    {

        [Given(@"a KPI data is generated with parameters like (.*), (.*),(.*),(.*) with (.*) for TODAY")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithForTODAY(string assetname, string metricname, string metricfield, string reportingperiod, int value)
        {
            DateTime now = DateTime.Now;
            var startDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            var reportingtime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield, reportingperiod, startDate, reportingtime, value);
        }

        [When(@"A request is placed with (.*) to get KPI data of an Asset (.*), (.*),(.*),(.*) for TODAY")]
        public void WhenARequestIsPlacedWithToGetKPIDataOfAnAssetForTODAY(string p0, string assetname, string metricname, string metricfield, string reportingperiod)
        {
            var startDate = DateTime.Now.AddDays(-1).ToString("yyyy-MM-ddThh:mm:ss");
            var endDate = DateTime.Now.AddDays(1).ToString("yyyy-MM-ddThh:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Given(@"a KPI data is generated with parameters like (.*), (.*), for Target(.*) and for Actual(.*) ,(.*) with (.*), (.*)")]
        public void GivenAKPIDataIsGeneraedWithParametersLikeForTargetAndForActualWith(string assetname, string metricname, string metricfield1, string metricfield2, string reportingperiod, int tvalue, int avalue)
        {
            DateTime now = DateTime.Now;
            var startDate = DateTime.Now.ToString("yyyy-MM-dd");
            var reportingtime = DateTime.Now.ToString("yyyy-MM-dd");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield1, reportingperiod, startDate, reportingtime, tvalue);
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield2, reportingperiod, startDate, reportingtime, avalue);
        }

        [Then(@"the KPI Data API should return both Target and actual Values (.*) and (.*)")]
        public void ThenTheKPIDataAPIShouldReturnBothTargetAndActualValues(string tvalue, string avalue)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(tvalue, Out_Values.KPIApi_json[0][4].ToString());
            Assert.AreEqual(avalue, Out_Values.KPIApi_json[0][5].ToString());
        }


        [Given(@"a KPI data is generated with parameters like (.*), (.*),(.*),(.*) with (.*)for this month")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithForThisMonth(string assetname, string metricname, string metricfield, string reportingperiod, int value)
        {
            DateTime now = DateTime.Now;
            var startDate = new DateTime(now.Year, now.Month, 1).ToString("yyyy-MM-dd");
            var reportingtime = new DateTime(now.Year, now.Month, 1).ToString("yyyy-MM-dd");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield, reportingperiod, startDate, reportingtime, value);
        }

        [When(@"A request is placed with (.*) to get KPI data of an Asset (.*), (.*),(.*),(.*)for this month")]
        public void WhenARequestIsPlacedWithToGetKPIDataOfAnAssetForThisMonth(string p0, string assetname, string metricname, string metricfield, string reportingperiod)
        {
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING THIS MONTH";
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"the KPI Data API should return the Value (.*)")]
        public void ThenTheKPIDataAPIShouldReturnTheValue(string expected_value)
        {
            string actual_value = Out_Values.KPIApi_json[0][4].ToString();
            Assert.AreEqual(expected_value, actual_value, $"Expected Metric Value: '{expected_value}' is not matched with actual Metric Value: '{actual_value}'");
        }


        [Given(@"a KPI data is generated with parameters like (.*), (.*),(.*),(.*) with (.*) for this year")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithForThisYear(string assetname, string metricname, string metricfield, string reportingperiod, int value)
        {
            DateTime now = DateTime.Now;
            var startDate = new DateTime(DateTime.Now.Year, 1, 1).ToString("yyyy-MM-dd");
            var reportingtime = new DateTime(DateTime.Now.Year, 1, 1).ToString("yyyy-MM-dd");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield, reportingperiod, startDate, reportingtime, value);
            
        }

        [When(@"A request is placed with (.*) to get KPI data of an Asset (.*), (.*),(.*),(.*) for this year")]
        public void WhenARequestIsPlacedWithToGetKPIDataOfAnAssetForThisYear(string p0, string assetname, string metricname, string metricfield, string reportingperiod)
        {
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING THIS YEAR";
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Given(@"a KPI data is generated with parameters like (.*), (.*),(.*),(.*) with (.*)for this week")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithForThisWeek(string assetname, string metricname, string metricfield, string reportingperiod, int value)
        {
            DateTime now = DateTime.Now;
            var Timestamp = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek + (int)DayOfWeek.Monday).ToString("yyyy-MM-dd");
            var reportingtime = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek + (int)DayOfWeek.Monday).ToString("yyyy-MM-dd");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname, metricfield, reportingperiod, Timestamp, reportingtime, value);
        }

        [When(@"A request is placed with (.*) to get KPI data of an Asset (.*), (.*),(.*),(.*) for this week")]
        public void WhenARequestIsPlacedWithToGetKPIDataOfAnAssetForThisWeek(string p0, string assetname, string metricname, string metricfield, string reportingperiod)
        {
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING THIS WEEK";
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data of an Asset (.*), (.*),(.*),(.*) and duration between startdate and enddate")]
        public void WhenARequestIsPlacedWithToGetKPIDataOfAnAssetAndDurationBetweenStartdateAndEnddate(string p0, string assetname, string metricname, string metricfield, string reportingperiod)
        {
            DateTime pastdate = DateTime.Now.AddDays(-1);
            string startdate = pastdate.ToString("yyyy-MM-ddTHH:mm:ss");
            DateTime futuredate = DateTime.Now.AddDays(+1);
            string enddate = futuredate.ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startdate + " AND " + enddate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }



        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), (.*) without reporting period")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetWithoutReportingPeriod(string cust_id, string assetname, string metricname)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), (.*) with Hourly reporting period(.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetWithHourlyReportingPeriod(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), (.*) with Monthly reporting period (.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetWithMonthlyReportingPeriod(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), (.*) with Shift reporting period (.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetWithShiftReportingPeriod(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Given(@"a KPI data is generated with multiple KPI with parameters like (.*), (.*),(.*),(.*),(.*) with (.*)")]
        public void GivenAKPIDataIsGeneratedWithMultipleKPIWithParametersLikeWith(string assetname, string metricname1, string metricname2, string metricfield, string reportingperiod, int value)
        {
            DateTime now = DateTime.Now;
            string startDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            var reportingtime = new DateTime(DateTime.Now.Year, 1, 1).ToString("yyyy-MM-dd");
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname1, metricfield, reportingperiod, startDate, reportingtime, value);
            ForgeAPMSQL.InsertKPIDataAPI(assetname, metricname2, metricfield, reportingperiod, startDate, reportingtime, value);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), multiple KPI (.*),(.*),(.*) during this year")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetMultipleKPIDuringThisYear(string cust_id, string assetname, string metricname1, string metricname2, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname1 + "," + metricname2 + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), KPI (.*),(.*) without passing asset name")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetKPIWithoutPassingAssetName(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._failure, status);
        }

        [Then(@"the KPI Data API should throw error response (.*)")]
        public void ThenTheKPIDataAPIShouldThrowErrorResponse(string error)
        {
            Assert.AreEqual(error, Out_Values.ResponseCode);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), KPI(.*), (.*) by passing invalid assetname")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetKPIByPassingInvalidAssetname(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + "InvalidAsset " + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"the KPI Data API should throw empty data")]
        public void ThenTheKPIDataAPIShouldThrowEmptyData()
        {
            string actual_value = Out_Values.ResponseCode;
            Assert.AreEqual("[]", Out_Values.KPIApi_json.ToString());
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), KPI(.*), (.*) by passing invalid Kpi name")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetKPIByPassingInvalidKpiName(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + "InvalidKPI" + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to get KPI data for an Asset (.*), KPI(.*), (.*) by passing invalid reporting period")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAnAssetKPIByPassingInvalidReportingPeriod(string cust_id, string assetname, string metricname, string reportingperiod)
        {
            var startDate = DateTime.Now.AddMinutes(-30).ToString("yyyy-MM-ddTHH:mm:ss");
            var endDate = DateTime.Now.AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss");
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + " InvalidPeriod " + " FOR ASSET " + assetname + " DURING " + startDate + " AND " + endDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname);
            Assert.AreEqual(Driver._success, status);
        }

        [Given(@"a KPI data is generated with for Asset (.*),(.*) with parameters like (.*),(.*),(.*),(.*) with date(.*) and (.*)")]
        public void GivenAKPIDataIsGeneratedWithForAssetWithParametersLikeWith(string assetname1, string assetname2, string metricname, string metricfield, string reportingperiod, string date,string reportingtime, int value)
        {

            ForgeAPMSQL.InsertKPIDataAPI(assetname1, metricname, metricfield, reportingperiod, reportingtime, date, value);
            ForgeAPMSQL.InsertKPIDataAPI(assetname2, metricname, metricfield, reportingperiod, reportingtime, date, value);
        }

        [When(@"A request is placed with (.*) to get KPI data for multiple Assets (.*),(.*) with (.*),(.*) during startdate(.*) and enddate(.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForMultipleAssetsWithDuringStartdateAndEnddate(string cust_id, string assetname1, string assetname2, string metricname, string reportingperiod, string startdate, string enddate)
        {
            string cmdQuery = "GET KPI " + metricname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname1 + " , " + assetname2 + " DURING " + startdate + " AND " + enddate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            ForgeAPMSQL.DeleteKPIData(assetname1);
            ForgeAPMSQL.DeleteKPIData(assetname2);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"the KPI Data API should return the data with all assets (.*) and (.*)")]
        public void ThenTheKPIDataAPIShouldReturnTheDataWithAllAssetsAnd(string assetname1, string assetname2)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(assetname1, Out_Values.KPIApi_json[0][0].ToString());
            Assert.AreEqual(assetname2, Out_Values.KPIApi_json[1][0].ToString());
        }

        [Given(@"a KPI data exists with KPI Category")]
        public void GivenAKPIDataExistsWithKPICategory()
        {
            Console.WriteLine("demo");
        }

        [When(@"A request is placed with (.*) to get KPI data for Asset (.*) with KpiCategory(.*),(.*) during startdate(.*) and enddate(.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAssetWithKpiCategoryDuringStartdateAndEnddate(string cust_id, string assetname, string kpicategoryname, string reportingperiod, string startdate, string enddate)
        {
            string cmdQuery = "GET KPI CATEGORY " + kpicategoryname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"the KPI Data API should return response and the data (.*)")]
        public void ThenTheKPIDataAPIShouldReturnResponseAndTheData(string assetname)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode, $"Expected Response: '{(HttpStatusCode.OK).ToString()}' is not matched with actual response: '{Out_Values.ResponseCode}'");
            Assert.AreEqual(assetname, Out_Values.KPIApi_json[0][0].ToString());
        }


        [When(@"A request is placed with (.*) to get KPI data for Asset (.*) with KpiName(.*) and KpiCategory(.*),(.*) during startdate(.*) and enddate(.*)")]
        public void WhenARequestIsPlacedWithToGetKPIDataForAssetWithKpiNameAndKpiCategoryDuringStartdateAndEnddate(string cust_id, string assetname, string kpiname, string kpicategoryname, string reportingperiod, string startdate, string enddate)
        {
            string cmdQuery = "GET KPI" + kpiname +" KPI CATEGORY " + kpicategoryname + " REPORT AT " + reportingperiod + " FOR ASSET " + assetname + " DURING " + startdate + " AND " + enddate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            var status = Driver.KPIData_API(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._failure, status);
        }

        [Then(@"the KPI Data API should return error response code")]
        public void ThenTheKPIDataAPIShouldReturnErrorResponseCode()
        {
            Assert.AreEqual((HttpStatusCode.BadRequest).ToString(), Out_Values.ResponseCode);
        }

        [Then(@"the KPI Data API should throw response success with empty data")]
        public void ThenTheKPIDataAPIShouldThrowResponseSuccessWithEmptyData()
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual("[]", Out_Values.KPIApi_json.ToString());
        }


    }
}