﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using FAPM_Driver;
using FAPM_Driver.Share;


namespace FAPM_Features.Steps
{
    [Binding]
    public class DataAPISteps
    {
        [Given(@"The Data API Service is up and running")]
        public void GivenTheDataAPIServiceIsUpAndRunning()
        {
            Console.WriteLine("demo");
        }

        [Given(@"user has privilege to access the Data API")]
        public void GivenUserHasPrivilegeToAccessTheDataAPI()
        {
            Console.WriteLine("demo");
        }


        [When(@"A request is placed for customerId (.*) to get KPI of an assets (.*) in a given time frame (.*)")]
        public void WhenARequestIsPlacedToGetKPIOfAnAssetsInAGivenTimeFrame(string p0, string p1, string p2)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            Driver.DataAPI_ByAssets(Common.Inputs.API_urls.server+ Common.Inputs.API_urls.QueryUrl, p1, p2, Common.Inputs.API_urls.customer_Id);
        }

        [Then(@"validate the response code returned to user")]
        public void ThenValidateTheResponseCodeReturnedToUser()
        {
            Console.WriteLine("demo");
            // Assert.AreEqual(p0, Driver.Get_ColumnCount(), $"Expected Column Count: '{p0}' is not matched with actual Column count: '{Driver.Get_ColumnCount()}'");
        }

        [When(@"A request is placed with customerId (.*) to get Trends of an assets (.*) in a given time frame (.*)")]
        public void WhenARequestIsPlacedToGetTrendsOfAnAssetsInAGivenTimeFrame(string p0, string p1, string p2)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            Driver.DataAPI_ByAssets(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, p1, p2, Common.Inputs.API_urls.customer_Id);

        }

        [Then(@"all the attributes for that asset (.*) are returned to user")]
        public void ThenAllTheAttributesForThatAssetAreReturnedToUser(int p3)
        {
            Console.WriteLine("demo");
            //Assert.AreEqual(p3, Driver.Get_ColumnCount(), $"Expected Column Count: '{p3}' is not matched with actual Column count: '{Driver.Get_ColumnCount()}'");
        }

        [When(@"A request is placed with customerId (.*) to get Events of an assets (.*) in a given time frame (.*)")]
        public void WhenARequestIsPlacedToGetEventsOfAnAssetsInAGivenTimeFrame(string p0, string p1, string p2)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", p0);
            Driver.DataAPI_ByAssets(Common.Inputs.API_urls.server + Common.Inputs.API_urls.QueryUrl, p1, p2, Common.Inputs.API_urls.customer_Id);
        }

        [Then(@"all the column (.*) are returned to user")]
        public void ThenAllTheColumnAreReturnedToUser(int p3)
        {
            Assert.AreEqual(p3, Out_Values.DataAPI_json.Count, $"Expected Column Count: '{p3}' is not matched with actual Column count: '{Out_Values.DataAPI_json.Count}'");
        }

        [When(@"A request is placed with customerId (.*) to  get trend data (.*) in a absolute time frame (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetTrendDataInAAbsoluteTimeFrameAnd(string p0, string p1, string p2, string p3)
        {
            Console.WriteLine("demo");
        }


    }
}
