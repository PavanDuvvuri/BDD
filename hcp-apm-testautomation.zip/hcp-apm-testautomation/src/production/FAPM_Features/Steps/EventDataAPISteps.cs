﻿using System;
using System.Net;
using TechTalk.SpecFlow;
using FAPM_Driver.Helpers;
using FAPM_Driver;
using FAPM_Driver.Share;
using System.Threading;
using NUnit.Framework;
using System.Collections.Generic;
using FAPM_Driver.Drivers;

namespace FAPM_Features.Steps
{
    [Binding]
    public class EventDataAPISteps
    {
        ForgeAPMSQL fsq = new ForgeAPMSQL();

        [Given(@"I load the appsettings json values")]
        public void GivenILoadTheAppsettingsJsonValues()
        {
            Helper.FillEnvironment_Values();
        }


        [Given(@"An active event is generated with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAnActiveEventIsGeneratedWithTheParametersLikeAssetNameAsDCAndEventStatusAsAndPriorityAsAndEventStateAsNEW(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"A potential event was already exists with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAPotentialEventWasAlreadyExistsWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAs(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            //DateTime localTime = DateTime.Now;
            //string currentUTC = localTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"An active event was already exists with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAnActiveEventWasAlreadyExistsWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAs(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            //DateTime pastDate = DateTime.Now.AddDays(-5);
            //string pastUTCDate = pastDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [When(@"A request is placed with customerId (.*) to get active events of an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetActiveEventsOfAnAssetInToday(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should retrieve the active event data created for the given asset (.*)")]
        public void ThenTheEventsDataAPIShouldRetrieveTheActiveEventDataCreatedForTheGivenAsset(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("active", Out_Values.ApiJsonOutput[0][0][6].ToString());
        }

        [Given(@"A potential event is generated with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAPotentialEventIsGeneratedWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAs(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [When(@"A request is placed with customerId (.*) to get potential events of an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetPotentialEventsOfAnAssetDuringLastweek(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET POTENTIAL EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should retrieve the potential events data created for the given asset (.*)")]
        public void ThenTheEventsDataAPIShouldRetrieveThePotentialEventsDataCreatedForTheGivenAsset(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("potential", Out_Values.ApiJsonOutput[0][0][6].ToString());
        }

        [Then(@"the Events Data API should return empty data in response\.")]
        public void ThenTheEventsDataAPIShouldReturnEmptyDataInResponse_()
        {
            Assert.IsEmpty(Out_Values.ApiJsonOutput[0]);
        }

        [When(@"A request is placed with customerId (.*) to get events data of an asset (.*) without passing duration period.")]
        public void WhenARequestIsPlacedWithCustomerIdToGetEventsDataOfAnAssetWithoutPassingDurationPeriod_(string custId, string assetName)
        {
            string cmdQuery = "GET ACTIVE EVENTS FOR ASSET" + " " + assetName;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }


        [Then(@"the Events Data API should return all active events for an asset (.*) till current day (.*) in response")]
        public void ThenTheEventsDataAPIShouldReturnAllActiveEventsTillCurrentDayInResponse(string assetName, string date)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(2, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("active", Out_Values.ApiJsonOutput[0][0][6].ToString());
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][1][1].ToString());
            Assert.AreEqual("active", Out_Values.ApiJsonOutput[0][1][6].ToString());
        }


        [When(@"A request is placed with customerId (.*) to get events data for multiple assets (.*) (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetEventsDataForMultipleAssets(string custId, string asset1, string asset2, string fromDate, string toDate)
        {
            string cmdQuery = "GET ACTIVE EVENTS FOR ASSET" + " " + asset1 + "," + asset2 + " " + "DURING PERIOD " + fromDate + " AND " +  toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }


        [Then(@"Then the Events Data API should return active events data for given assets (.*) (.*) in response\.")]
        public void ThenThenTheEventsDataAPIShouldReturnActiveEventsDataForGivenAssetsInResponse_(string asset1, string asset2)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(2, Out_Values.ApiJsonOutput[0].Count);
            Out_Values.HelperList.Clear();
            Assert.AreEqual(2, Out_Values.ApiJsonOutput[0].Count);
            foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_name[1]);
            }
            Assert.Contains(asset1, Out_Values.HelperList);
            Assert.Contains(asset2, Out_Values.HelperList);
        }


        [When(@"A request is placed with customerId (.*) to get potential events data for multiple assets (.*) (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetPotentialEventsDataForMultipleAssets(string custId, string asset1, string asset2, string fromDate, string toDate)
        {
            string cmdQuery = "GET POTENTIAL EVENTS FOR ASSET" + " " + asset1 + "," + asset2 + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return potential events data for given assets (.*) (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnPotentialEventsDataForGivenAssetsInResponse_(string assetName1, string assetName2)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            Assert.AreEqual(2, Out_Values.ApiJsonOutput[0].Count);
            foreach (var asset_name in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)asset_name[1]);
            }
            Assert.Contains(assetName1, Out_Values.HelperList);
            Assert.Contains(assetName2, Out_Values.HelperList);
        }

        [When(@"A request is placed with customerId (.*) to get high priority event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetHighPriorityEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET HIGH PRIORITY ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return high priority events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnHighPriorityEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual("CP_LOSS", Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("high", Out_Values.ApiJsonOutput[0][0][5].ToString());
        }

        [When(@"A request is placed with customerId (.*) to get medium priority event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetMediumPriorityEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {

            string cmdQuery = "GET MEDIUM PRIORITY ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return Medium priority events data for given asset (.*) in response.")]
        public void ThenTheEventsDataAPIShouldReturnMediumPriorityEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("medium", Out_Values.ApiJsonOutput[0][0][5].ToString());
        }

        [When(@"A request is placed with customerId (.*) to get low priority event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetLowPriorityEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET LOW PRIORITY ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return low priority events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnLowPriorityEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("low", Out_Values.ApiJsonOutput[0][0][5].ToString());
        }

        [When(@"A request is placed with customerId (.*) to get a New state event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetANewStateEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET NEW STATE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return New events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnNewEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("new", Out_Values.ApiJsonOutput[0][0][7].ToString());
        }

        [When(@"A request is placed with customerId (.*) to get a Open state event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetAOpenStateEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET OPEN STATE ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return Open events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnOpenEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("inprogress", Out_Values.ApiJsonOutput[0][0][7].ToString());
        }

        [Given(@"There was an potential event present with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenThereWasAnPotentialEventPresentWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsInLastWeek(string assetName, int eventStatus, int priority, int eventState, string startTime)
        {
            //DateTime lastWeek = DateTime.Now.AddDays(-7);
            //string lastWeekDate = lastWeek.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");

            fsq.InsertDataForEventDataAPI(assetName, eventState, eventStatus, priority, startTime);
        }
        

        [When(@"A request is placed with customerId (.*) to get High, Medium, Low priority event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetHighMediumLowPriorityEventDataForAnAssetDuringAPeriod(string custId, string assetName, string fromDate, string toDate)
        {
            //DateTime fromDate = DateTime.Now.AddDays(-31);
            //string from = fromDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
            //DateTime toDate = DateTime.Now.AddDays(1);
            //string to = toDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");

            string cmdQuery = "GET HIGH,MEDIUM,LOW PRIORITY ACTIVE,POTENTIAL EVENTS FOR ASSET" + " " + assetName + " DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }
        
        [Then(@"the Events Data API should return High, Medium, Low priority events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnHighMediumLowPriorityEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var priority in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string) priority[5]);
            }

            Assert.AreEqual(3, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.Contains("high", Out_Values.HelperList);
            Assert.Contains("medium", Out_Values.HelperList);
            Assert.Contains("low", Out_Values.HelperList);
        }
        
        [When(@"A request is placed with customerId (.*) to get a Closed state event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetAClosedStateEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET CLOSED STATE EVENTS FOR ASSET" + " " + assetName + " DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }
        
        [Then(@"the Events Data API should return Closed events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnClosedEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("closed", Out_Values.ApiJsonOutput[0][0][7].ToString());
        }
        
        [When(@"A request is placed with customerId (.*) to get a Rejected state event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetARejectedStateEventDataForAnAsset(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET REJECTED STATE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }
        
        [Then(@"the Events Data API should return Rejected events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnRejectedEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual("rejected", Out_Values.ApiJsonOutput[0][0][7].ToString());
        }

        [Then(@"the Events Data API should return error message in response\.")]
        public void ThenTheEventsDataAPIShouldReturnErrorMessageInResponse_()
        {
            Assert.AreEqual("no viable alternative at input 'invalidSTATE'", (string) Out_Values.ApiJsonOutput[0]["detail"]);
        }

        [Given(@"An active and New state event is generated with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAnActiveAndNewStateEventIsGeneratedWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndStartedAt(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"There was an potential and Open state event with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenThereWasAnPotentialAndOpenStateEventWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndStartedAt(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"There was an potential and Rejected state event with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*)and started at (.*)")]
        public void GivenThereWasAnPotentialAndRejectedStateEventWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndStartedAt(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"There was an potential and Closed state event with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenThereWasAnPotentialAndClosedStateEventWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndStartedAt(string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertDataForEventDataAPI(assetName, faultState, eventStatus, priority, startTime);
        }

        [When(@"A request is placed with customerId (.*) to get Active,Potential event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetActivePotentialEventDataForAnAssetDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET ACTIVE,POTENTIAL EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return New,Open,Closed,Rejected events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnNewOpenClosedRejectedEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var state in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string) state[7]);
            }

            Assert.AreEqual(4, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.Contains("inprogress", Out_Values.HelperList);
            Assert.Contains("closed", Out_Values.HelperList);
            Assert.Contains("new", Out_Values.HelperList);
            Assert.Contains("rejected", Out_Values.HelperList);
        }

        [When(@"A request is placed with customerId (.*) to get Event data for an asset (.*) with (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedToGetEventDataForAnAssetWithDuringAnd(string custId, string assetName, string state, string fromDate, string toDate)
        {
            string cmdQuery = "GET " + state + " STATE ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should return active and potential events data for given asset (.*) in response\.")]
        public void ThenTheEventsDataAPIShouldReturnAndEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var status_ in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)status_[6]);
            }

            Assert.AreEqual(2, Out_Values.ApiJsonOutput[0].Count);
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][0][1].ToString());
            Assert.AreEqual(assetName, Out_Values.ApiJsonOutput[0][1][1].ToString());
            Assert.Contains("active", Out_Values.HelperList);
            Assert.Contains("potential", Out_Values.HelperList);
        }

        [When(@"A request is placed with customerId (.*) to get events data of an asset (.*) and his child assets during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetEventsDataOfAnAssetAndHisChildAssetsDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET ACTIVE EVENTS FOR ALL ASSETS IN" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate; ;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Events Data API should retrieve the event data created for the given asset (.*) with children assets (.*) and (.*)")]
        public void ThenTheEventsDataAPIShouldRetrieveTheEventDataCreatedForTheGivenAssetWithChildrenAssetsAnd(string assetName, string child1, string child2)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var childAsset in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string) childAsset[1]);
            }
            Assert.AreEqual(3, Out_Values.ApiJsonOutput[0].Count);
            Assert.Contains(assetName, Out_Values.HelperList);
            Assert.Contains(child1, Out_Values.HelperList);
            Assert.Contains(child2, Out_Values.HelperList);
        }

        [Then(@"the Events Data API should return an error message in response\.")]
        public void ThenTheEventsDataAPIShouldRaiseAnErrorInResponse_()
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual("mismatched input 'STATE' expecting FOR", Out_Values.ApiJsonOutput[0]["detail"]);
        }

        [Given(@"An active event under (.*) category is generated with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenAPotentialEventUnderHealthCategoryIsGeneratedWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndAndStartedAt(string eventCategory, string assetName, int eventStatus, int priority, int faultState, string startTime)
        {
            fsq.InsertEventCategoryDataForEventDataAPI(eventCategory, assetName, faultState, eventStatus, priority, startTime);
        }

        [Given(@"There was an potential event under (.*) category with the parameters like asset name as (.*) and event status as (.*) and priority as (.*) and event state as (.*) and started at (.*)")]
        public void GivenThereWasAnPotentialEventUnderSafetyCategoryWithTheParametersLikeAssetNameAsAndEventStatusAsAndPriorityAsAndEventStateAsAndAndStartedAt(string eventCategory, string assetName, int faultState, int eventStatus, int priority, string startTime)
        {
            fsq.InsertEventCategoryDataForEventDataAPI(eventCategory, assetName, faultState, eventStatus, priority, startTime);
        }

        [When(@"A request is placed with customerId (.*) to get Health, Safety, Performance event data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetHealthSafetyPerformanceEventDataForAnAssetDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET NEW,OPEN STATE HEALTH,SAFETY,PERFORMANCE ACTIVE,POTENTIAL EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Event Data API should return  Health, Safety, Performance events data for given asset (.*) in response\.")]
        public void ThenTheEventManagementServiceShouldReturnHealthSafetyPerformanceEventsDataForGivenAssetInResponse_(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(3, Out_Values.ApiJsonOutput[0].Count);
        }

        [When(@"A request is placed with customerId (.*) to get Safety event category data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetSafetyEventCategoryDataForAnAssetDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET NEW STATE SAFETY ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Event Data API should return event data for the given asset (.*) under (.*) in response\.")]
        public void ThenTheEventDataAPIShouldReturnEventDataForForTheGivenAssetInResponse_(string assetName, string eventCategory)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(1, Out_Values.ApiJsonOutput.Count);
            Assert.AreEqual(eventCategory, (string) Out_Values.ApiJsonOutput[0][0][15]);
        }

        [When(@"A request is placed with customerId (.*) to get Health event category data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetHealthEventCategoryDataForAnAssetDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET OPEN STATE HEALTH ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [When(@"A request is placed with customerId (.*) to get Performance event category data for an asset (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedWithCustomerIdToGetPerformanceEventCategoryDataForAnAssetDuringAnd(string custId, string assetName, string fromDate, string toDate)
        {
            string cmdQuery = "GET NEW STATE PERFORMANCE ACTIVE EVENTS FOR ASSET" + " " + assetName + " " + "DURING PERIOD " + fromDate + " AND " + toDate;
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custId);
            Driver.EventsDataAPIResponse(Environment_Values.DataAPIServer + Environment_Values.QueryUrl, cmdQuery, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }
    }
}
