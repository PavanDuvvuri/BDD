﻿using AutomationFramework;
using FAPM_Driver;
using FAPM_Driver.Drivers;
using FAPM_Driver.Helpers;
using FAPM_Driver.Share;
using FAPM_Features.Common;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using TechTalk.SpecFlow;
using FAPM_Features.Utilities;
using AutomationFramework.PageElements;

namespace FAPM_Features.Features
{
    [Binding]
    public class AssetHelathDashboardSteps
    {
        private static int longWait = 120;
        private static int mediumWait = 60;
        private static int shortWait = 30;
        String strRowData = "";
        Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();

        ForgeAPMSQL fsq = new ForgeAPMSQL();


        #region Given steps

        [Given(@"user is on Asset health page")]
        public void GivenUserIsOnAssetHealthPage()
        {
            Driver_UI.Launch_DashboardUI(Environment_Values.assetHealthDasboardUrl);
        }

        #endregion Background steps

        #region When steps common for all

        [When(@"asset (.*) and time period (.*) are selected")]
        public void WhenAssetAlaskaAndTimePeriodCurrentShiftAreSelected(string assetName, string duration)
        {
            UI_Driver.WaitUntilElementExisting(AssetDashoard.AssetHealthHeader, shortWait);
            switch (duration.ToLower().Trim())
            {
                case "current day":
                case "current month":
                case "current  shift":
                    UI_Driver.Click(AssetDashoard.duration_Dropdown_click);
                    IWebElement select_duration = UI_Driver.selectDuration(duration);
                    select_duration.Click();
                    break;
            }
            UI_Driver.Click(AssetDashoard.asset_Dropdown_click);
            IWebElement assetSelection = UI_Driver.selectAsset(assetName);
            assetSelection.Click();
        }

        [When(@"Time period (.*) is selected")]
        public void WhenTimePeriodCurrentShiftIsSelected(string duration)
        {
            UI_Driver.WaitUntilElementExisting(AssetDashoard.AssetDetailsHeader, shortWait);
            switch (duration)
            {
                case "Current Day":
                case "Current Month":
                case "Current Shift":
                    UI_Driver.Click(AssetDashoard.AssetDetailsDurationDropDown);
                    IWebElement select_duration = UI_Driver.selectDurationUnderAssetDetails(duration);
                    select_duration.Click();
                    break;
            }
        }


        [When(@"asset (.*) under asset (.*) is selected")]
        public void WhenAssetEthyneCrackerUnderAssetMalibuIsSelected(string subAsset, string assetName)
        {
            UI_Driver.Click(AssetDashoard.asset_Dropdown_click);
            IWebElement expandAssets = UI_Driver.expandAssetSelection(assetName);
            expandAssets.Click();
            IWebElement assetSelection = UI_Driver.selectAsset(subAsset);
            assetSelection.Click();
        }


        #endregion

        #region OEE



        [Then(@"user reads the (.*) value from dashbaord")]
        public void ThenUserReadsTheOEEValueFromDashbaord(string widgetName)
        {
            if (widgetName == "OEE")
            {
                UI_Driver.VerifyText("OVERALL EQUIPMENT EFFICIENCY", AssetDashoard.OEE_title);
            }

            else if (widgetName == "Availability")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Availability_title);
            }

            else if (widgetName == "Performance")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Performance_title);
            }

            else if (widgetName == "Quality")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Quality_title);
            }
        }

        [Then(@"user reads the (.*) value from Asset details dashboard")]
        public void ThenUserReadsTheAvailabilityValueFromAssetDetailsDashboard(string widgetName)
        {

            if (widgetName == "OEE")
            {
                UI_Driver.VerifyText("OVERALL EQUIPMENT EFFICIENCY", AssetDashoard.OEE_title);
            }

            else if (widgetName == "Availability")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Availability_title);
            }

            else if (widgetName == "Performance")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Performance_title);
            }

            else if (widgetName == "Quality")
            {
                UI_Driver.VerifyText(widgetName.ToUpper(), AssetDashoard.Quality_title);
            }
        }

        [Then(@"the (.*) value for asset (.*) and time period (.*) are as Expected")]
        public void ThenTheOEEValueForAssetAlaskaAndTimePeriodCurrentShiftAreAsExpected(string widget, string assetName, string duration)
        {
            var scoresValue = DBConnection.AssetDahboardvalues(assetName, duration, "");
            fsq.DeleteDataForEventDataAPI();
            if (scoresValue.ContainsKey(widget) && widget == "OEE")
            {
                var OEE_DB_Score = scoresValue[widget];
                string OEE_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.OEE_score);
                Assert.IsTrue(OEE_DB_Score.Equals(OEE_UI_Score), $"The expected string: '{OEE_DB_Score}' is not matched with actual string: '{OEE_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Availability")
            {
                //string Availability_DB_Score = DBConnection.GetAvailabilityScore(assetName, duration);
                var Availability_DB_Score = scoresValue[widget];
                string Availability_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.Availability_score);
                Assert.IsTrue(Availability_DB_Score.Equals(Availability_UI_Score), $"The expected string: '{Availability_DB_Score}' is not matched with actual string: '{Availability_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Performance")
            {
                //string Performance_DB_Score = DBConnection.GetPerformanceScore(assetName, duration);
                var Performance_DB_Score = scoresValue[widget];
                string Performance_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.Performance_score);
                Assert.IsTrue(Performance_DB_Score.Equals(Performance_UI_Score), $"The expected string: '{Performance_DB_Score}' is not matched with actual string: '{Performance_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Quality")
            {
                //string Quality_DB_Score = DBConnection.GetQualityScore(assetName, duration);
                var Quality_DB_Score = scoresValue[widget];
                string Quality_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.Quality_score);
                Assert.IsTrue(Quality_DB_Score.Equals(Quality_UI_Score), $"The expected string: '{Quality_DB_Score}' is not matched with actual string: '{Quality_UI_Score}'");
            }
        }

        [Then(@"The (.*) value for asset (.*) and time period (.*) in Asset Details dashboard are as Expected")]
        public void ThenTheAvailabilityValueForAssetAlaskaAndTimePeriodCurrentShiftInAssetDetailsDashboardAreAsExpected(string widget, string assetName, string duration)
        {
            var scoresValue = DBConnection.AssetDahboardvalues(assetName, duration, "");
            fsq.DeleteDataForEventDataAPI();
            if (scoresValue.ContainsKey(widget) && widget == "OEE")
            {
                var OEE_DB_Score = scoresValue[widget];
                string OEE_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.AssetDetails_OEE_score);
                Assert.IsTrue(OEE_DB_Score.Equals(OEE_UI_Score), $"The expected string: '{OEE_DB_Score}' is not matched with actual string: '{OEE_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Availability")
            {
                //string Availability_DB_Score = DBConnection.GetAvailabilityScore(assetName, duration);
                var Availability_DB_Score = scoresValue[widget];
                string Availability_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.AssetDetails_Availability_score);
                Assert.IsTrue(Availability_DB_Score.Equals(Availability_UI_Score), $"The expected string: '{Availability_DB_Score}' is not matched with actual string: '{Availability_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Performance")
            {
                //string Performance_DB_Score = DBConnection.GetPerformanceScore(assetName, duration);
                var Performance_DB_Score = scoresValue[widget];
                string Performance_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.AssetDetails_Performance_score);
                Assert.IsTrue(Performance_DB_Score.Equals(Performance_UI_Score), $"The expected string: '{Performance_DB_Score}' is not matched with actual string: '{Performance_UI_Score}'");
            }

            else if (scoresValue.ContainsKey(widget) && widget == "Quality")
            {
                //string Quality_DB_Score = DBConnection.GetQualityScore(assetName, duration);
                var Quality_DB_Score = scoresValue[widget];
                string Quality_UI_Score = UI_Driver.FetchDynamicValue(AssetDashoard.AssetDetails_Quality_score);
                Assert.IsTrue(Quality_DB_Score.Equals(Quality_UI_Score), $"The expected string: '{Quality_DB_Score}' is not matched with actual string: '{Quality_UI_Score}'");
            }
        }

        #endregion

        #region Risk Matrix
        [Given(@"user has an asset (.*) configured in model with criticality (.*)")]
        public void GivenUserHasAnAssetConfiguredInModelWithCriticality(string assetName, string criticality)
        {
            Console.WriteLine("Asset '" + assetName + "' is exist in the EOM");
        }

        [Given(@"faults (.*) with priority (.*) for the asset (.*) with criticality (.*) is available")]
        public void GivenFaultWithPriorityHighForTheAsset_GIsAvailable(int faultCount, string priority, string assetName, string criticality)
        {
            fsq.InsertDataForAllCriticalities(criticality, faultCount, priority);
        }

        [When(@"user reads the data and retrives the value of criticality (.*) and priority (.*)")]
        public void WhenUserReadsTheDataAndRetrivesTheValueOfCriticalitySafetyAndPriorityHigh(string criticality, string priority)
        {
            Driver_UI.Risk_Matrix_Read();
        }

        [Then(@"the fault count (.*) of Major criticality shown correctly on the grid")]
        public void ThenTheFaultCountIsShownCorrectlyOnTheGrid(int faultCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_3"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_3"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_4"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_4"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_5"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_5"]}'");
        }

        [Then(@"the fault count (.*) of Safety criticality shown correctly on the grid")]
        public void ThenTheFaultCountOfSafetyCriticalityShownCorrectlyOnTheGrid(int faultCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_0"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_0"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_1"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_1"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_2"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_2"]}'");
        }

        [Then(@"the fault count (.*) of None criticality shown correctly on the grid")]
        public void ThenTheFaultCountForNoneCriticalityShownCorrectlyOnTheGrid(int faultCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_12"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_12"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_13"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_13"]}'");
            Assert.IsTrue(faultCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_14"]), $"The expected string: '{faultCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_14"]}'");
        }

        #endregion

        #region

        [When(@"user reads the Uptime value and graph from the Key KPI widget")]
        public void WhenUserReadsTheEnergyValueAndGraphFromTheKeyKPIWidget()
        {
            UI_Driver.WaitUntilElementExisting(AssetDashoard.KeyKPI, shortWait);
            UI_Driver.VerifyText("Uptime", AssetDashoard.UptimeText);
            UI_Driver.VerifyText("Utilization", AssetDashoard.UtilizationText);
            UI_Driver.VerifyText("Energy", AssetDashoard.EnergyText);
        }

        [Then(@"the value of Uptime should shown correctly on the grid")]
        public void ThenTheValueOfEnergyShouldShownCorrectlyOnTheGrid()
        {
            var uptimeValue_UI = UI_Driver.FetchDynamicValue(AssetDashoard.UptimeValue);
            var utilizationValue_UI = UI_Driver.FetchDynamicValue(AssetDashoard.UtilizationValue);
            var energyValue_UI = UI_Driver.FetchDynamicValue(AssetDashoard.EnergyValue);
        }

        [When(@"user reads the (.*) value and graph from the Key KPI widget for asset (.*) during period (.*)")]
        public void WhenUserReadsTheUtilizationValueAndGraphFromTheKeyKPIWidgetForAssetEthyneCrackerDuringPeriodDaily(string kpiName, string assetName, string reportingPeriod)
        {
            UI_Driver.WaitUntilElementExisting(AssetDashoard.KeyKPI, shortWait);
            if (kpiName == "Uptime")
            {
                UI_Driver.VerifyText("Uptime", AssetDashoard.UptimeText);
            }

            else if (kpiName == "Utilization")
            {
                UI_Driver.VerifyText("Utilization", AssetDashoard.UtilizationText);
            }

            else if (kpiName == "Energy")
            {
                UI_Driver.VerifyText("Energy", AssetDashoard.EnergyText);
            }

        }

        [When(@"user reads the (.*) value from the Key KPI widget in Asset details page for asset (.*) during period (.*)")]
        public void WhenUserReadsTheCapacityLossValueFromTheKeyKPIWidgetInAssetDetailsPageForAsset_CDuringPeriodDaily(string kpiName, string assetName, string reportingPeriod)
        {
            UI_Driver.WaitUntilElementExisting(AssetDashoard.KeyKPI, shortWait);
            if (kpiName == "CapacityLoss")
            {
                UI_Driver.VerifyText("CapacityLoss", AssetDashoard.CapacityLoss_Text);
            }

            else if (kpiName == "Energy")
            {
                UI_Driver.VerifyText("Energy", AssetDashoard.Energy_Text);
            }

            else if (kpiName == "GasFlowRate")
            {
                UI_Driver.VerifyText("GasFlowRate", AssetDashoard.GasFlowRate_Text);
            }

            else if (kpiName == "PolytropicEfficiency")
            {
                UI_Driver.VerifyText("PolytropicEfficiency", AssetDashoard.PolytropicEfficiency_Text);
            }

            else if (kpiName == "PolytropicHead")
            {
                UI_Driver.VerifyText("PolytropicHead", AssetDashoard.PolytropicHead_Text);
            }
        }

        [Then(@"The value of (.*) in Asset Details page for asset (.*) during period (.*) should shown correctly on the widget")]
        public void ThenTheValueOfCapacityLossInAssetDetailsPageForAsset_CAResidueGasCompDuringPeriodDailyShouldShownCorrectlyOnTheWidget(string kpiName, string assetName, string reportingPeriod)
        {
            fsq.DeleteDataForEventDataAPI();
            if (kpiName == "CapacityLoss")
            {
                var CapacityLoss_UI = UI_Driver.FetchDynamicValue(AssetDashoard.CapacityLoss_value);
                var CapacityLoss_DB = DBConnection.GetKeyKPIValues(assetName, kpiName, reportingPeriod, "");

                Assert.IsTrue(CapacityLoss_DB.ToString().Equals(CapacityLoss_UI), $"The expected string: '{CapacityLoss_DB}' is not matched with actual string: '{CapacityLoss_UI}'");
            }

            else if (kpiName == "Energy")
            {
                var Energy_UI = UI_Driver.FetchDynamicValue(AssetDashoard.Energy_value);
                var Energy_DB = DBConnection.GetUtilizationValue(assetName, kpiName, reportingPeriod, "");
                Assert.IsTrue(Energy_DB.ToString().Equals(Energy_UI), $"The expected string: '{Energy_DB}' is not matched with actual string: '{Energy_UI}'");
            }

            else if (kpiName == "PolytropicHead")
            {
                var PolytropicHead_UI = UI_Driver.FetchDynamicValue(AssetDashoard.PolytropicHead_value);
                var PolytropicHead_DB = DBConnection.GetUtilizationValue(assetName, kpiName, reportingPeriod, "");
                Assert.IsTrue(PolytropicHead_DB.ToString().Equals(PolytropicHead_UI), $"The expected string: '{PolytropicHead_DB}' is not matched with actual string: '{PolytropicHead_UI}'");
            }

            else if (kpiName == "PolytropicEfficiency")
            {
                var PolytropicEfficiency_UI = UI_Driver.FetchDynamicValue(AssetDashoard.PolytropicEfficiency_value);
                var PolytropicEfficiency_DB = DBConnection.GetUtilizationValue(assetName, kpiName, reportingPeriod, "");
                Assert.IsTrue(PolytropicEfficiency_DB.ToString().Equals(PolytropicEfficiency_UI), $"The expected string: '{PolytropicEfficiency_DB}' is not matched with actual string: '{PolytropicEfficiency_UI}'");
            }

            else if (kpiName == "GasFlowRate")
            {
                var GasFlowRate_UI = UI_Driver.FetchDynamicValue(AssetDashoard.GasFlowRate_value);
                var GasFlowRate_DB = DBConnection.GetUtilizationValue(assetName, kpiName, reportingPeriod, "");
                Assert.IsTrue(GasFlowRate_DB.ToString().Equals(GasFlowRate_UI), $"The expected string: '{GasFlowRate_DB}' is not matched with actual string: '{GasFlowRate_UI}'");
            }
        }


        [Then(@"the value of (.*) for asset (.*) during period (.*) should shown correctly on the widget")]
        public void ThenTheValueOfUtilizationShouldShownCorrectlyOnTheGrid(string kpiName, string assetName, string reportingPeriod)
        {
            fsq.DeleteDataForEventDataAPI();
            if (kpiName == "Uptime")
            {
                var uptimeValue_UI = UI_Driver.FetchDynamicValue(AssetDashoard.UptimeValue);
                var uptimeValue_DB = DBConnection.GetUptimeValue(assetName, kpiName, reportingPeriod, "");

                Assert.IsTrue(uptimeValue_DB.ToString().Equals(uptimeValue_UI), $"The expected string: '{uptimeValue_DB}' is not matched with actual string: '{uptimeValue_UI}'");
            }

            else if (kpiName == "Utilization")
            {
                var utilizationValue_UI = UI_Driver.FetchDynamicValue(AssetDashoard.UtilizationValue);
                var utilizationValue_DB = DBConnection.GetUtilizationValue(assetName, kpiName, reportingPeriod, "");

                Assert.IsTrue(utilizationValue_DB.ToString().Equals(utilizationValue_UI), $"The expected string: '{utilizationValue_DB}' is not matched with actual string: '{utilizationValue_UI}'");
            }

            else if (kpiName == "Energy")
            {
                var energy_UI = UI_Driver.FetchDynamicValue(AssetDashoard.EnergyValue);
                var energy_DB = DBConnection.GetEnergyValue(assetName, kpiName, reportingPeriod, "");

                Assert.IsTrue(energy_DB.ToString().Equals(energy_UI), $"The expected string: '{energy_DB}' is not matched with actual string: '{energy_UI}'");
            }
        }

        [When(@"User navigate to Asset Summary table")]
        public void WhenUserNavigateToAssetSummaryTable()
        {
            UI_Driver.ScrollToElementUsingJavaScript(AssetDashoard.AssetSummaryHeader);
            UI_Driver.WaitUntilElementExists(AssetDashoard.AssetSummaryHeader, shortWait);
            UI_Driver.VerifyText("ASSET SUMMARY", AssetDashoard.AssetSummaryHeader);
        }

        [Then(@"The details for given asset (.*) (.*) (.*) should be shown")]
        public void ThenTheDetailsForGivenAssetKShouldBeShown(string assetDisplayName, int faultCount, string criticality)
        {
            //fsq.DeleteDataForEventDataAPI();
            //UI_Driver.ScrollToElementUsingJavaScript(AssetDashoard.AssetSummaryHeader);
            Dictionary<string, string> values = UI_Driver.TableRowAndColumnForCommonType(AssetDashoard.AssetSummaryTableRow, AssetDashoard.AssetSummaryTableHeader);
            Assert.IsTrue(values["1ASSET DETAILS"].Contains(assetDisplayName), $"The expected string: '{values["1ASSET DETAILS"]}' is not matched with actual string: '{assetDisplayName}'");
            Assert.IsTrue(values["1CRITICALITY"].Contains(criticality), $"The expected string: '{values["1CRITICALITY"]}' is not matched with actual string: '{criticality}'");
            Assert.IsTrue(values["1ACTIVE EVENTS"].Equals(faultCount), $"The expected string: '{values["1ACTIVE EVENTS"]}' is not matched with actual value: '{faultCount}'");
        }

        [When(@"User clicks on the Asset name (.*) under Asset Details column in Asset summary table")]
        public void WhenUserClicksOnTheAssetNameUnderAssetDetailsColumnInAssetSummaryTable(string assetName)
        {
            IWebElement AssetDetailsredirectLink = UI_Driver.assetDetailsRedirectLink(assetName);
            UI_Driver.WaitUntilElementExists(By.XPath("//span[@class='redirect-link' and contains(text(),'" + assetName + "')]"), mediumWait);
            UI_Driver.ScrollToElementUsingJavaScript(By.XPath("//span[@class='redirect-link' and contains(text(),'" + assetName + "')]"));
            AssetDetailsredirectLink.Click();
        }

        [Then(@"Verify that user navigated to Asset details page for an asset (.*)")]
        public void ThenVerifyThatUserNavigatedToAssetDetailsPage(string assetName)
        {
            UI_Driver.WaitUntilElementExists(AssetDashoard.AssetDetailsHeader, mediumWait);
            var AssetDetailsHeaderText = UI_Driver.GetText(AssetDashoard.AssetDetailsHeader);
            UI_Driver.WaitUntilElementExists(AssetDashoard.AssetDashboardTitle, mediumWait);
            var AssetNameTitleText = UI_Driver.GetText(AssetDashoard.AssetDashboardTitle);
            Assert.IsTrue(AssetDetailsHeaderText[0].Contains("Asset Details"), $"The expected string: '{"Asset Details"}' is not matched with actual string: '{AssetDetailsHeaderText[0]}'");
            //Assert.IsTrue(AssetNameTitleText[0].Equals(assetName), $"The expected string: '{assetName}' is not matched with actual string: '{AssetNameTitleText[0]}'");
        }

        [When(@"user reads the data from Assets view in Top Faulted Assets widget")]
        public void WhenUserReadsTheDataFromAssetsViewInTopFaultedAssetsWidget()
        {
            UI_Driver.ScrollToElementUsingJavaScript(AssetDashoard.headerText);
            UI_Driver.VerifyText("TOP FAULTED ASSETS", AssetDashoard.headerText);
            UI_Driver.VerifyText("Asset Name", AssetDashoard.assetName_TopFaulted);
        }


        [Then(@"expected Asset display name (.*) should shown correctly on the grid")]
        public void ThenExpectedAssetDisplayNameShouldShownCorrectlyOnTheGrid(string assetdisplayname)
        {
            fsq.DeleteDataForEventDataAPI();
            var retrived_values_UI = Driver_UI.topFaulted(AssetDashoard.textNameFor_AssetAndFaults_TopFaulted, "Assets");

            Assert.IsTrue(retrived_values_UI.Contains(assetdisplayname), $"The expected string: '{assetdisplayname}' is not matched with actual string: '{retrived_values_UI.Contains(assetdisplayname)}'");
        }

        [Then(@"The expected Asset display name (.*) should shown correctly on the grid")]
        public void ThenTheExpectedAssetDisplayNameRecycleGasCompressorShouldShownCorrectlyOnTheGrid(string assetdisplayname)
        {
            fsq.DeleteDataForEventDataAPI();
            var retrived_values_UI = Driver_UI.topFaulted(AssetDashoard.Assets_TitleText_TopFaulted, "Assets");

            Assert.IsTrue(retrived_values_UI.Contains(assetdisplayname), $"The expected string: '{assetdisplayname}' is not matched with actual string: '{retrived_values_UI}'");
        }


        [When(@"user reads the data from Faults view in Top Faulted Assets widget")]
        public void WhenUserReadsTheDataFromFaultsViewInTopFaultedAssetsWidget()
        {
            UI_Driver.ScrollToElementUsingJavaScript(AssetDashoard.headerText);
            UI_Driver.Click(AssetDashoard.AssetDetails_FaultsButton_TopFaulted);
            UI_Driver.VerifyText("FREQUENT FAULTS", AssetDashoard.Header_FreqFaults);
            UI_Driver.VerifyText("Fault Name", AssetDashoard.faultName_FreqFaults);
        }

        [Then(@"expected fault display name (.*) should shown correctly on the grid")]
        public void ThenExpectedFaultDisplayNameRecycleGasCompressorShouldShownCorrectlyOnTheGrid(string faultDisplayNames)
        {
            fsq.DeleteDataForEventDataAPI();
            var retrived_values_UI = Driver_UI.topFaulted(AssetDashoard.textNameFor_AssetAndFaults_TopFaulted, "Faults");

            if (faultDisplayNames.Contains(","))
            {
                var temp = faultDisplayNames.Split(",");
                for (int i = 0; i < temp.Length; i++)
                {
                    string name = temp[i];
                    Assert.IsTrue(retrived_values_UI.Contains(name), $"The expected string '{name}' is not matched with actual string: '{retrived_values_UI.Contains(name)}");
                }
            }
        }

        [Then(@"The expected fault display name (.*) should shown correctly on the grid")]
        public void ThenTheExpectedFaultDisplayNameShouldShownCorrectlyOnTheGrid(string faultDisplayNames)
        {
            fsq.DeleteDataForEventDataAPI();
            var retrived_values_UI = Driver_UI.topFaulted(AssetDashoard.Faults_TitleText_TopFaulted, "Faults");

            if (faultDisplayNames.Contains(","))
            {
                var temp = faultDisplayNames.Split(",");
                for (int i = 0; i < temp.Length; i++)
                {
                    string name = temp[i];
                    Assert.IsTrue(retrived_values_UI.Contains(name), $"The expected string '{name}' is not matched with actual string: '{retrived_values_UI.Contains(name)}");
                }
            }
        }


        [When(@"user reads the asset count and retrives the value of asset grid for criticality (.*)")]
        public void WhenUserReadsTheAssetCountAndRetrivesTheValueOfAssetGridForCriticalityNone(string criticality)
        {
            UI_Driver.WaitUntilElementExists(AssetDashoard.RiskMatrixAssetButton, shortWait);
            UI_Driver.Click(AssetDashoard.RiskMatrixAssetButton);
            Driver_UI.Risk_Matrix_Read();
        }


        [Then(@"the Asset count (.*) of None criticality shown correctly on the Assets section")]
        public void ThenTheAssetCountOfNoneCriticalityShownCorrectlyOnTheAssetsSection(int assetCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(assetCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_2"]), $"The expected string: '{assetCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_2"]}'");
        }

        [Then(@"the Asset count (.*) of Major criticality shown correctly on the Assets section")]
        public void ThenTheAssetCountOfMajorCriticalityShownCorrectlyOnTheAssetsSection(int assetCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(assetCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_1"]), $"The expected string: '{assetCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_1"]}'");
        }

        [Then(@"the Asset count (.*) of Safety criticality shown correctly on the Assets section")]
        public void ThenTheAssetCountOfSafetyCriticalityShownCorrectlyOnTheAssetsSection(int assetCount)
        {
            fsq.DeleteDataForEventDataAPI();
            Assert.IsTrue(assetCount.ToString().Equals(Out_Values.Risk_Matrix_Values["cell_0"]), $"The expected string: '{assetCount}' is not matched with actual string: '{Out_Values.Risk_Matrix_Values["cell_0"]}'");
        }
    }
}
        #endregion
