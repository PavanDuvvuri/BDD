﻿using AutomationFramework;
using AutomationFramework.PageElements;
using FAPM_Driver;
using FAPM_Driver.AutomationModel;
using FAPM_Driver.Drivers;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class PODashboardSteps
    {
        public static IWebDriver driver;

        #region Background steps

        [Given(@"user is navigated to (.*) Ops dashboard page.")]
        public void GivenUserIsNavigatedToQAForgeAPMLandingPage_(string env)
        {
            if (env.ToLower() == "qa")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_QA_Ops);
            else if (env.ToLower() == "stage")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_Stage_Ops);
        }

        [Given(@"user is navigated to (.*) Panda Dashboard page\.")]
        public void GivenUserIsNavigatedToQAPandaDashboardPage_(string env)
        {
            if (env.ToLower() == "qa")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_QA_Panda);
            else if (env.ToLower() == "stage")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_Stage_Panda);
        }

        [Given(@"user is navigated to (.*) Picking Dashboard page\.")]
        public void GivenUserIsNavigatedToEnvironmentPickingDashboardPage_(string env)
        {
            if (env.ToLower() == "qa")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_QA_Picking);
            else if (env.ToLower() == "stage")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_Stage_Picking);
        }

        [Given(@"user is navigated to (.*) Shipping Dashboard page\.")]
        public void GivenUserIsNavigatedToEnvironmentShippingDashboardPage_(string env)
        {
            if (env.ToLower() == "qa")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_QA_Shipping);
            else if (env.ToLower() == "stage")
                Driver_UI.Launch_DashboardUI(Environment_Values.dashboardUrl_Stage_Shipping);
        }

        #endregion Background steps

        #region When steps common for all

        [When(@"user selects an asset(.*) and duration (.*)")]
        public void WhenUserSelectsAnAssetDCAndDurationShift(string assetCollection = null, string ViewByDay_ViewByShift = null)
        {
          
                UI_Driver.WaitUntilElementExisting(PODashboard.header_HoneywellForge, 120);
                UI_Driver.Wait(2000);
                UI_Driver.WaitUntilElementExisting(PODashboard.viewbyday_button1, 60);
                switch (ViewByDay_ViewByShift.ToLower().Trim())
                {
                    case "daily":
                        UI_Driver.Click(PODashboard.viewbyday_button1);
                        break;
                    case "shift":
                        UI_Driver.Click(PODashboard.viewbyshift_button1);
                        UI_Driver.Wait(1000);
                        break;
                }
                if (assetCollection.Contains(","))
                {
                    var temp = assetCollection.Split(",");
                    for (int i = 0; i < temp.Length; i++)
                    {
                        UI_Driver.Click(PODashboard.asset_Selection);
                        Thread.Sleep(2000);
                        UI_Driver.ClickForMultipleElement(temp[i]);
                    }
                }
                else
                {
                    UI_Driver.Click(PODashboard.asset_Selection);
                    Thread.Sleep(2000);
                    UI_Driver.ClickForMultipleElement(assetCollection);
                }
             
            }
        
    #endregion

    #region common logic

    public static void refreshPageMethod(string ViewByDay_ViewByShift)
        {
            if (ViewByDay_ViewByShift == "Daily")
            {
                UI_Driver.Click(PODashboard.viewbyshift_button1);
                UI_Driver.Wait(1000);
                UI_Driver.Click(PODashboard.viewbyday_button1);
            }
            else
            {
                UI_Driver.Click(PODashboard.viewbyday_button1);
                UI_Driver.Wait(1000);
                UI_Driver.Click(PODashboard.viewbyshift_button1);
            }
        }

        #endregion

        #region Order Quota

        [Then(@"tool tip is as expected on ops Dashboard for duration (.*)")]
        public void ThenToolTipIsAsExpectedOnOpsDashboardForDurationShift(string ViewByDay_ViewByShift)
        {
            if (ViewByDay_ViewByShift == "day")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the day in DC", PODashboard.text_orderQuota, PODashboard.tooltip_orderQuota);
            }
            else if (ViewByDay_ViewByShift == "shift")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the shift in DC", PODashboard.text_orderQuota, PODashboard.tooltip_orderQuota_shift);
            }
        }

        [Then(@"the order quota value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheOrderQuotaValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection = null, string ViewByDay_ViewByShift = null, string env = null)
        {
            string _orderQuota_DB = null;
            string _orderQuota_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _orderQuota_DB = DBConnection.GetOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                //string _orderQuota_DB = DBConnection.GetVerifyOrderQuota(assetCollection, ViewByDay_ViewByShift);
                Thread.Sleep(1000);
                _orderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_orderQuota);
                if (_orderQuota_DB.Equals(_orderQuota_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_orderQuota_DB.Equals(_orderQuota_UI), $"The expected string: '{_orderQuota_DB}' is not matched with actual string: '{_orderQuota_UI}'");
        }

        [Then(@"tool tip is as expected on Shipping Dashboard for duration (.*)")]
        public void ThenToolTipIsAsExpectedOnShippingDashboard(string ViewByDay_ViewByShift)
        {
            if (ViewByDay_ViewByShift == "day")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the day in DC", PODashboard.text_shipping_orderQuota, PODashboard.tooltip_orderQuota);
            }
            else if (ViewByDay_ViewByShift == "shift")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the shift in DC", PODashboard.text_shipping_orderQuota, PODashboard.tooltip_orderQuota_shift);
            }

        }

        [Then(@"tool tip is as expected on Picking Dashboard for duration (.*)")]
        public void ThenToolTipIsAsExpectedOnPickingDashboard(string ViewByDay_ViewByShift)
        {
            if (ViewByDay_ViewByShift == "day")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the day in DC", PODashboard.text_picking_orderQuota, PODashboard.tooltip_orderQuota);
            }
            else if (ViewByDay_ViewByShift == "shift")
            {
                UI_Driver.VerifyToolTipText("Total number of orders planned for the shift in DC", PODashboard.text_picking_orderQuota, PODashboard.tooltip_orderQuota_shift);
            }
        }

        [Then(@"the order quota value for asset(.*) and duration (.*) is as Expected on Shipping Dashboard for (.*)")]
        public void ThenTheOrderQuotaValueForAssetDCAndDurationShiftIsAsExpectedOnShippingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _orderQuota_DB = null;
                string _orderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _orderQuota_DB = DBConnection.GetOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _orderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_orderQuota_forShipping);
                    if (_orderQuota_DB.Equals(_orderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_orderQuota_DB.Equals(_orderQuota_UI), $"The expected string: '{_orderQuota_DB}' is not matched with actual string: '{_orderQuota_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_orderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        [Then(@"the order quota value for asset(.*) and duration (.*) is as Expected on Picking Dashboard in (.*)")]
        public void ThenTheOrderQuotaValueForAssetDCAndDurationShiftIsAsExpectedOnPickingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _orderQuota_DB = null;
                string _orderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _orderQuota_DB = DBConnection.GetOrderQuota_PickingDAshboard(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _orderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_orderQuota_forPicking);
                    if (_orderQuota_DB.Equals(_orderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_orderQuota_DB.Equals(_orderQuota_UI), $"The expected string: '{_orderQuota_DB}' is not matched with actual string: '{_orderQuota_UI}'");
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_orderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }



        #endregion

        #region currentPlan

        [Then(@"tool tip is as expected for Current/Plan")]
        public void ThenToolTipIsAsExpectedForCurrentPlan()
        {
            UI_Driver.VerifyToolTipText("The deviation between the total orders shipped and the planned cumulative progress predicted", PODashboard.text_currentplan, PODashboard.tooltip_currentplan);
        }

        [Then(@"the CurrentPlan value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheCurrentPlanValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _CurrentPlanorderQuota_DB = null;
            string _CurrentPlanorderQuota_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _CurrentPlanorderQuota_DB = DBConnection.GetCurrentPlan(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _CurrentPlanorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_currentPlan);
                if (_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI))
                    Assert.IsTrue(true);
                break;
            }
            Assert.IsTrue(_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI), $"The expected string: '{_CurrentPlanorderQuota_DB}' is not matched with actual string: '{_CurrentPlanorderQuota_UI}'");
        }

        [Then(@"tool tip is as expected for Current/Plan on Shipping Dashboard")]
        public void ThenToolTipIsAsExpectedForCurrentPlanOnShippingDashboard()
        {
            UI_Driver.VerifyToolTipText("The deviation between the total orders shipped and the planned cumulative progress predicted", PODashboard.text_shipping_currentplan, PODashboard.tooltip_shipping_currentplan);
        }

        [Then(@"the CurrentPlan value for asset(.*) and duration (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenTheCurrentPlanValueForAssetDCAndDurationShiftIsAsExpectedOnShippingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _CurrentPlanorderQuota_DB = null;
                string _CurrentPlanorderQuota_UI1 = null;
                for (int i = 1; i <= 3; i++)
                {
                    _CurrentPlanorderQuota_DB = DBConnection.GetCurrentPlan(assetCollection, ViewByDay_ViewByShift, env);//split into array and then concatinate
                    Thread.Sleep(1000);
                    string _CurrentPlanorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_currentPlan_forShipping);
                    string[] currentplanShipping = _CurrentPlanorderQuota_UI.Split(" ");
                    _CurrentPlanorderQuota_UI1 = currentplanShipping[0] + currentplanShipping[1];
                    if (_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI1))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI1), $"The expected string: '{_CurrentPlanorderQuota_DB}' is not matched with actual string: '{_CurrentPlanorderQuota_UI1}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_CurrentPlanorderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }


        [Then(@"tool tip is as expected for Current/Plan on Picking Dashboard")]
        public void ThenToolTipIsAsExpectedForCurrentPlanOnPickingDashboard()
        {
            UI_Driver.VerifyToolTipText("The deviation between the total orders picked and the planned cumulative progress predicted", PODashboard.text_picking_currentplan, PODashboard.tooltip_currentplan);
        }

        [Then(@"the CurrentPlan value for asset(.*) and duration (.*) is as Expected on Picking Dashboard in (.*)")]
        public void ThenTheCurrentPlanValueForAssetDCAndDurationShiftIsAsExpectedOnPickingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _CurrentPlanorderQuota_DB = null;
                string _CurrentPlanorderQuota_UI1 = null;
                for (int i = 1; i <= 3; i++)
                {
                    _CurrentPlanorderQuota_DB = DBConnection.GetCurrentPlan_PickingDashboard(assetCollection, ViewByDay_ViewByShift, env);//split into array and then concatinate
                    Thread.Sleep(1000);
                    string _CurrentPlanorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_currentPlan_forPicking);
                    string[] currentplanPicking = _CurrentPlanorderQuota_UI.Split(" ");
                    _CurrentPlanorderQuota_UI1 = currentplanPicking[0] + currentplanPicking[1];
                    if (_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI1))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_CurrentPlanorderQuota_DB.Equals(_CurrentPlanorderQuota_UI1), $"The expected string: '{_CurrentPlanorderQuota_DB}' is not matched with actual string: '{_CurrentPlanorderQuota_UI1}'");
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_CurrentPlanorderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }



        #endregion

        #region Picked

        [Then(@"tool tip is as expected for Picked")]
        public void ThenToolTipIsAsExpectedForPicked()
        {
            UI_Driver.VerifyToolTipText("Number of orders picked", PODashboard.text_picked, PODashboard.tooltip_picked);
        }

        [Then(@"the Picked value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenThePickedValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _PickedOrderQuota_DB = null;
            string _PickedorderQuota_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _PickedOrderQuota_DB = DBConnection.GetPickededOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _PickedorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_orderQuotaPicked);
                if (_PickedOrderQuota_DB.Equals(_PickedorderQuota_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_PickedOrderQuota_DB.Equals(_PickedorderQuota_UI), $"The expected string: '{_PickedOrderQuota_DB}' is not matched with actual string: '{_PickedorderQuota_UI}'");
        }

        [Then(@"tool tip is as expected for Picked on Picking Dashboard")]
        public void ThenToolTipIsAsExpectedForPickedOnPickingDashboard()
        {
            UI_Driver.VerifyToolTipText("Number of orders picked", PODashboard.text_picked, PODashboard.tooltip_picked);
        }

        [Then(@"the Picked value for asset(.*) and duration (.*) is as Expected on Picking Dashboard in (.*)")]
        public void ThenThePickedValueForAssetDCAndDurationShiftIsAsExpectedOnPickingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _PickedOrderQuota_DB = null;
                string _PickedorderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _PickedOrderQuota_DB = DBConnection.GetPickededOrderQuota_PickingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _PickedorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_picked_forPicking);
                    if (_PickedOrderQuota_DB.Equals(_PickedorderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_PickedOrderQuota_DB.Equals(_PickedorderQuota_UI), $"The expected string: '{_PickedOrderQuota_DB}' is not matched with actual string: '{_PickedorderQuota_UI}'");
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_PickedOrderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }


        #endregion

        #region Picked Progress bar

        [Then(@"the Picked Progress Bar value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenThePickedProgressBarValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _PickedProgressBar_DB = null;
            string _PickedProgressBar_UI = null;
            for (int i = 0; i <= 5; i++)
            {
                _PickedProgressBar_DB = DBConnection.PickedProgressBar(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _PickedProgressBar_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_PickedProgressBar);
                refreshPageMethod(ViewByDay_ViewByShift);
                if (_PickedProgressBar_DB.Equals(_PickedProgressBar_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_PickedProgressBar_DB.Equals(_PickedProgressBar_UI), $"The expected string: '{_PickedProgressBar_DB}' is not matched with actual string: '{_PickedProgressBar_UI}'");
        }

        [Then(@"the Picked Progress Bar value for asset(.*) and duration (.*) is as Expected on Picking Dashboard in (.*)")]
        public void ThenThePickedProgressBarValueForAssetDCAndDurationShiftIsAsExpectedOnPickingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _PickedProgressBar_DB = null;
                string _PickedProgressBar_UI = null;
                for (int i = 0; i <= 5; i++)
                {
                    _PickedProgressBar_DB = DBConnection.PickedProgressBar(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _PickedProgressBar_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Picked_pickedProgressbar);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    if (_PickedProgressBar_DB.Equals(_PickedProgressBar_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_PickedProgressBar_DB.Equals(_PickedProgressBar_UI), $"The expected string: '{_PickedProgressBar_DB}' is not matched with actual string: '{_PickedProgressBar_UI}'");
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_PickedProgressBar" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }


        #endregion

        #region Shipped

        [Then(@"tool tip is as expected for Shipped")]
        public void ThenToolTipIsAsExpectedForShipped()
        {
            UI_Driver.VerifyToolTipText("Number of orders shipped", PODashboard.text_shipped, PODashboard.tooltip_shipped);
        }

        [Then(@"the Shipped value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheShippedValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ShippedOrderQuota_DB = null;
            string _ShippedorderQuota_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _ShippedOrderQuota_DB = DBConnection.GetShippedOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ShippedorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_orderQuotaShipped);
                if (_ShippedOrderQuota_DB.Equals(_ShippedorderQuota_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_ShippedOrderQuota_DB.Equals(_ShippedorderQuota_UI), $"The expected string: '{_ShippedOrderQuota_DB}' is not matched with actual string: '{_ShippedorderQuota_UI}'");
        }

        [Then(@"tool tip is as expected for Shipped on Shipping Dashboard")]
        public void ThenToolTipIsAsExpectedForShippedOnShippingDashboard()
        {
            UI_Driver.VerifyToolTipText("Number of orders shipped", PODashboard.text_shipped, PODashboard.tooltip_shipping_shipped);
        }


        [Then(@"the Shipped value for asset(.*) and duration (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenTheShippedValueForAssetDCAndDurationShiftIsAsExpectedOnShippingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _ShippedOrderQuota_DB = null;
                string _ShippedorderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _ShippedOrderQuota_DB = DBConnection.GetShippedOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _ShippedorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Shipped);
                    if (_ShippedOrderQuota_DB.Equals(_ShippedorderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_ShippedOrderQuota_DB.Equals(_ShippedorderQuota_UI), $"The expected string: '{_ShippedOrderQuota_DB}' is not matched with actual string: '{_ShippedorderQuota_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_ShippedOrderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Shipped Progress bar

        [Then(@"the Shipped Progress Bar value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheShippedProgressBarValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ShippedProgressBar_DB = null;
            string _ShippedProgressBar_UI = null;
            for (int i = 0; i <= 5; i++)
            {
                _ShippedProgressBar_DB = DBConnection.ShippedProgressBar(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ShippedProgressBar_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_ShippedProgressBar);
                refreshPageMethod(ViewByDay_ViewByShift);
                if (_ShippedProgressBar_DB.Equals(_ShippedProgressBar_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_ShippedProgressBar_DB.Equals(_ShippedProgressBar_UI), $"The expected string: '{_ShippedProgressBar_DB}' is not matched with actual string: '{_ShippedProgressBar_UI}'");
        }

        [Then(@"the Shipped Progress Bar value for asset(.*) and duration (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenTheShippedProgressBarValueForAssetDCAndDurationShiftIsAsExpectedOnShippingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _ShippedProgressBar_DB = null;
                string _ShippedProgressBar_UI = null;
                for (int i = 1; i <= 10; i++)
                {
                    _ShippedProgressBar_DB = DBConnection.ShippedProgressBar(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _ShippedProgressBar_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_ShippedProgressBar_shipping);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    if (_ShippedProgressBar_DB.Equals(_ShippedProgressBar_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_ShippedProgressBar_DB.Equals(_ShippedProgressBar_UI), $"The expected string: '{_ShippedProgressBar_DB}' is not matched with actual string: '{_ShippedProgressBar_UI}'");
            }
            catch (Exception ex)
            {
               UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_ShippedProgressBar" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }


        #endregion

        #region AssetDownTime

        [Then(@"tool tip is as expected for AssetDownTime")]
        public void ThenToolTipIsAsExpectedForAssetDownTime()
        {
            UI_Driver.VerifyToolTipText("Average downtime of all the assets in the warehouse", PODashboard.text_asset, PODashboard.tooltip_Asset);
        }

        [Then(@"the AssetDownTime value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheAssetDownTimeValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _AssetDowntimeorderQuota_DB = null;
            string _AssetDowntimeorderQuota_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _AssetDowntimeorderQuota_DB = DBConnection.GetAssetDowntimeOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _AssetDowntimeorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_assetDowntime);
                if (_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI), $"The expected string: '{_AssetDowntimeorderQuota_DB}' is not matched with actual string: '{_AssetDowntimeorderQuota_UI}'");
        }

        [Then(@"tool tip is as expected for AssetDownTime on Shipping Dashboard")]
        public void ThenToolTipIsAsExpectedForAssetDownTimeOnShippingDashboard()
        {
            UI_Driver.VerifyToolTipText("Average downtime of all picking assets in the warehouse", PODashboard.text_shipping_asset, PODashboard.tooltip_shipping_asset);
        }

        [Then(@"the AssetDownTime value for asset(.*) and duration (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenTheAssetDownTimeValueForAssetDCAndDurationShiftIsAsExpectedOnShippingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _AssetDowntimeorderQuota_DB = null;
                string _AssetDowntimeorderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _AssetDowntimeorderQuota_DB = DBConnection.GetAssetDowntime_ShiipingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _AssetDowntimeorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_assetDowntime_forShipping);
                    if (_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI), $"The expected string: '{_AssetDowntimeorderQuota_DB}' is not matched with actual string: '{_AssetDowntimeorderQuota_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_AssetDowntimeorderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        [Then(@"tool tip is as expected for AssetDownTime on Picking Dashboard")]
        public void ThenToolTipIsAsExpectedForAssetDownTimeOnPickingDashboard()
        {
            UI_Driver.VerifyToolTipText("Average downtime of all picking assets in the warehouse", PODashboard.text_picking_asset, PODashboard.tooltip_AssetDowntime_PickingDashboard);
        }

        [Then(@"the AssetDownTime value for asset(.*) and duration (.*) is as Expected on Picking Dashboard in (.*)")]
        public void ThenTheAssetDownTimeValueForAssetDCAndDurationShiftIsAsExpectedOnPickingDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try {
                string _AssetDowntimeorderQuota_DB = null;
                string _AssetDowntimeorderQuota_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _AssetDowntimeorderQuota_DB = DBConnection.GetAssetDowntimeOrderQuota_PickingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _AssetDowntimeorderQuota_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_assetDowntime_forPicking);
                    if (_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_AssetDowntimeorderQuota_DB.Equals(_AssetDowntimeorderQuota_UI), $"The expected string: '{_AssetDowntimeorderQuota_DB}' is not matched with actual string: '{_AssetDowntimeorderQuota_UI}'");
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_AssetDowntimeorderQuota" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Current/Planned_Shipping

        [Then(@"the Current/Planned value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheCurrentPlannedValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _CurrentPlanShippingCartons_DB = null;
            string _CurrentPlanShippingCartons_UI = null;
            for (int i = 1; i <= 5; i++)
            {
                _CurrentPlanShippingCartons_DB = DBConnection.GetCurrentPlanShippingPanel(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _CurrentPlanShippingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Shipping_CurrentPlan);
                if (_CurrentPlanShippingCartons_DB.Equals(_CurrentPlanShippingCartons_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_CurrentPlanShippingCartons_DB.Equals(_CurrentPlanShippingCartons_UI), $"The expected string: '{_CurrentPlanShippingCartons_DB}' is not matched with actual string: '{_CurrentPlanShippingCartons_UI}'");
        }

        #endregion

        #region Expected_Shipping

        [Then(@"the Expected value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheExpectedValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ExpectedShippingCartons_DB = null;
            string _ExpectedShippingCartons_UI = null;
            for (int i = 1; i <= 10; i++)
            {
                _ExpectedShippingCartons_DB = DBConnection.GetExpectedShippingPanel(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ExpectedShippingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Shipping_Expected);
                refreshPageMethod(ViewByDay_ViewByShift);
                if (_ExpectedShippingCartons_DB.Equals(_ExpectedShippingCartons_UI))
                    Assert.IsTrue(true);
                break;
            }
            Assert.IsTrue(true, $"The expected string: '{_ExpectedShippingCartons_DB}' is not matched with actual string: '{_ExpectedShippingCartons_UI}'");
        }

        #endregion

        #region Shipped_Shipping

        [Then(@"the SHIPPED value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheSHIPPEDValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ShippedShippingCartons_DB = null;
            string _ShippedShippingCartons_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                _ShippedShippingCartons_DB = DBConnection.GetShippedOrderQuota(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ShippedShippingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Shipping_Shipped);
                if (_ShippedShippingCartons_DB.Equals(_ShippedShippingCartons_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(true, $"The expected string: '{_ShippedShippingCartons_DB}' is not matched with actual string: '{_ShippedShippingCartons_UI}'");
        }

        #endregion

        #region Efficiency_Shipping

        [Then(@"the Efficiency value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheEfficiencyValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _CurrentPlanShippingCartons_DB = null;
                string _CurrentPlanShippingCartons_UI = null;
                for (int i = 1; i <= 5; i++)
                {
                    _CurrentPlanShippingCartons_DB = DBConnection.GetEfficiencyShippingPanel(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _CurrentPlanShippingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Shipping_Efficiency);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    if (_CurrentPlanShippingCartons_DB.Equals(_CurrentPlanShippingCartons_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_CurrentPlanShippingCartons_DB.Equals(_CurrentPlanShippingCartons_UI), $"The expected string: '{_CurrentPlanShippingCartons_DB}' is not matched with actual string: '{_CurrentPlanShippingCartons_UI}'");
            }
            //catch (AssertionException)
            //{
            //    throw;
            //}
            catch (Exception ex)
            {
                Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
               UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_CurrentPlanShippingCartons" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Current/Planned_Picking Widget

        [Then(@"the CURRENT/PLANNED value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheCURRENTPLANNEDValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
           try
            {
            string _CurrentPlanPickingCartons_DB = null;
            string _CurrentPlanPickingCartons_UI = null;
            for (int i = 1; i <= 5; i++)
            {
                _CurrentPlanPickingCartons_DB = DBConnection.GetCurrentPlanPickingPanel(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _CurrentPlanPickingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Picking_CurrentPlan);
                if (_CurrentPlanPickingCartons_DB.Equals(_CurrentPlanPickingCartons_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_CurrentPlanPickingCartons_DB.Equals(_CurrentPlanPickingCartons_UI), $"The expected string: '{_CurrentPlanPickingCartons_DB}' is not matched with actual string: '{_CurrentPlanPickingCartons_UI}'");
           }
          
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_CurrentPlanPickingCartons" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Expected_Picking Widget

        [Then(@"the Expected Picking value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheExpectedPickingValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _ExpectedPickingCartons_DB = null;
                string _ExpectedPickingCartons_UI = null;
                for (int i = 1; i <= 5; i++)
                {
                    _ExpectedPickingCartons_DB = DBConnection.GetExpectedPickingPanel(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _ExpectedPickingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Picking_Expected);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    if (_ExpectedPickingCartons_DB.Equals(_ExpectedPickingCartons_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_ExpectedPickingCartons_DB.Equals(_ExpectedPickingCartons_UI), $"The expected string: '{_ExpectedPickingCartons_DB}' is not matched with actual string: '{_ExpectedPickingCartons_UI}'");
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_ExpectedPickingCartons" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }

        }

        #endregion

        #region Released/Picked

        [Then(@"the Released/Picked value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheReleasedPickedValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _ReleasedPickingCartons_DB = null;
                string _ReleasedPickingCartons_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _ReleasedPickingCartons_DB = DBConnection.ReleasedPickedPickingData(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _ReleasedPickingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Picking_Released);
                    if (_ReleasedPickingCartons_DB.Equals(_ReleasedPickingCartons_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_ReleasedPickingCartons_DB.Equals(_ReleasedPickingCartons_UI), $"The expected string: '{_ReleasedPickingCartons_DB}' is not matched with actual string: '{_ReleasedPickingCartons_UI}'");
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_ReleasedPickingCartons" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }

        }

        #endregion

        #region Efficiency_Picking Widget

        [Then(@"the EFFICIENCY value for asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenTheEFFICIENCYValueForAssetDCAndDurationShiftIsAsExpected(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                string _EfficiencyPickingCartons_DB = null;
                string _EfficiencyPickingCartons_UI = null;
                for (int i = 1; i <= 10; i++)
                {
                    _EfficiencyPickingCartons_DB = DBConnection.GetEfficiencyPickingPanel(assetCollection, ViewByDay_ViewByShift, env);
                    Thread.Sleep(1000);
                    _EfficiencyPickingCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamicValue_Picking_Efficiency);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    if (_EfficiencyPickingCartons_DB.Equals(_EfficiencyPickingCartons_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_EfficiencyPickingCartons_DB.Equals(_EfficiencyPickingCartons_UI), $"The expected string: '{_EfficiencyPickingCartons_DB}' is not matched with actual string: '{_EfficiencyPickingCartons_UI}'");
            }

            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_EfficiencyPickingCartons" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Optimal Performance/Asset impacted

        [Then(@"user will verify text displaying on UI as per color of CURRENT")]
        public void ThenUserWillVerifyTextDisplayingOnUIAsPerColorOfCURRENT()
        {
            string colorDisplayingOn_UI = UI_Driver.GetColor(PODashboard.dynamicValue_Shipping_OnlyCurrent);
            if (colorDisplayingOn_UI == "#008813")
            {
                UI_Driver.VerifyText("Optimal Performance", PODashboard.color_optimalperformance);
                UI_Driver.VerifyText("You have reached/exceeded the planned rate !", PODashboard.optimal_performance);
            }
            else if (colorDisplayingOn_UI == "#D60B13")
                UI_Driver.VerifyText("Asset is Impacted", PODashboard.AssetIsImpacted);

        }

        #endregion

        #region Optimal Performance/Picking is Impacted

        [Then(@"user will verify Picking is Impacted displaying on UI for Picking Widget as per color of CURRENT")]
        public void ThenUserWillVerifyPickingIsImpactedDisplayingOnUIForPickingWidgetAsPerColorOfCURRENT()
        {
            string colorDisplayingOn_UI = UI_Driver.GetColor(PODashboard.dynamicValue_Picking_OnlyCurrent);
            if (colorDisplayingOn_UI == "#008813")
            {
                UI_Driver.VerifyText("Optimal Performance", PODashboard.color_optimalperformance);
                UI_Driver.VerifyText("You have reached/exceeded the planned rate !", PODashboard.optimal_performance);
            }
            else if (colorDisplayingOn_UI == "#D60B13")
                UI_Driver.VerifyText("Picking is Impacted", PODashboard.color_pickingImpacted);
        }

        #endregion

        #region Time

        [Then(@"user will verify time on Dashboard")]
        public void ThenUserWillVerifyTimeOnDashboard()
        {
            UI_Driver.VerifyTimeWithAttribute(PODashboard.dynamicValue_CurrentPlan_Time, "innerHTML");
        }

        #endregion

        #region ViewDetails Btn

        [Then(@"user will navigate to Picking dashboard")]
        public void ThenUserWillNavigateToPickingDashboard()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.Picking_Header, 20);
        }

        [Then(@"user will click on Outbound Operations button on Picking dashboard")]
        public void ThenUserWillClickOnOutboundOperationsButtonOnPickingDashboard()
        {
            UI_Driver.Click(PODashboard.LeftArrowOf_OutboundOperation_pickDB);
            UI_Driver.WaitUntilElementExists(PODashboard.outbound_header, 30);
            Thread.Sleep(2000);
        }

        [Then(@"user will click on View Details button of Picking widget")]
        public void ThenUserWillClickOnViewDetailsButtonOfPickingWidget()
        {
            UI_Driver.WaitUntilElementExisting(PODashboard.link_viewDetails1, 20);
            Driver_UI.shipping_dashboard(PODashboard.link_viewDetails1);
        }

        [Then(@"user will click on View Details button")]
        public void ThenUserWillClickOnViewDetailsButton()
        {
            UI_Driver.WaitUntilElementExisting(PODashboard.link_viewDetails2, 20);
            Driver_UI.shipping_dashboard(PODashboard.link_viewDetails2);
        }

        [Then(@"user will navigate to Shipping Page")]
        public void ThenUserWillNavigateToShippingPage()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.Shipping_Header, 20);
        }

        [Then(@"user will click on Outbound Operations button on Shipping page")]
        public void ThenUserWillClickOnOutboundOperationsButtonOnShippingPage()
        {
            UI_Driver.Click(PODashboard.LeftArrowOf_OutboundOperation);
            UI_Driver.WaitUntilElementExists(PODashboard.outbound_header, 30);
            Thread.Sleep(2000);
        }

        [Then(@"user will click on Outbound Operations button on Shipping page (.*)")]
        public void ThenUserWillClickOnOutboundOperationsButtonOnShippingPage(string ViewByDay_ViewByShift = null)
        {
            UI_Driver.Click(PODashboard.LeftArrowOf_OutboundOperation);
            UI_Driver.WaitUntilElementExists(PODashboard.outbound_header, 30);
            Thread.Sleep(2000);
        }

        #endregion

        #region Badge

        [Then(@"user will verify the count of badge with the number of assets display in notification window")]
        public void ThenUserWillVerifyTheCountOfBadgeWithTheNumberOfAssetsDisplayInNotificationWindow()
        {
            if (UI_Driver.ElementIsExists(PODashboard.color_pickingImpacted))
            {
                string badgeNumber;
                UI_Driver.Wait(3000);
                badgeNumber = UI_Driver.GetElementAttribute("innerHTML", PODashboard.dynamicValue_Picking_badgeTextbtn);
                UI_Driver.Click(PODashboard.dynamicValue_Picking_badgeTextbtn);
                UI_Driver.Wait(2000);
                UI_Driver.VerifyText("NOTIFICATIONS", PODashboard.header_notification);
                UI_Driver.VerifyTextwithAttribute("Picking", PODashboard.dynamicValue_notification_textselected, "innerHTML");
                int countfromNotification = UI_Driver.TotalCount(PODashboard.dynamic_assetcount);
                int countFromBadge = int.Parse(badgeNumber);
                UI_Driver.verifyTwoIntNumber(countfromNotification, countFromBadge);
            }
        }

        #endregion

        #region Precision

        [Then(@"user will check the expected precision")]
        public void ThenUserWillCheckTheExpectedPrecision()
        {
            string colorDisplayingOn_UI = UI_Driver.GetColor(PODashboard.dynamicValue_Shipping_OnlyCurrent);
            if (colorDisplayingOn_UI == "#D60B13")
                UI_Driver.VerifyText("Asset is Impacted", PODashboard.AssetIsImpacted);
            UI_Driver.VerifyTextwithAttribute(PODashboard.shipping_description_error, PODashboard.dynamicValue_Shipping_Expected, "innerHTML");

        }

        [Then(@"user will check the expected precision in Picking Widget")]
        public void ThenUserWillCheckTheExpectedPrecisionInPickingWidget()
        {
            string colorDisplayingOn_UI = UI_Driver.GetColor(PODashboard.dynamicValue_Picking_OnlyCurrent);
            if (colorDisplayingOn_UI == "#D60B13")
                UI_Driver.VerifyText("Picking is Impacted", PODashboard.color_pickingImpacted);
            UI_Driver.VerifyTextwithAttribute(PODashboard.picking_description_error, PODashboard.dynamicValue_Picking_Expected, "innerHTML");
        }

        #endregion

        #region Sorter

        [Then(@"user will select LowerSorter2 from dropdown")]
        public void ThenUserWillSelectLowerSorterFromDropdown()
        {
            UI_Driver.Click(PODashboard.click_OnSorter);
            Thread.Sleep(2000);
            UI_Driver.ClickAndWaitForPageToLoad(PODashboard.clickOn_LowerSorter, 10);
        }

        #endregion

        #region Notification

        [When(@"user click on Notification bell icon")]
        public void WhenUserClickOnNotificationBellIcon()
        {
            Driver_UI.Notification_Window(PODashboard.clickOnNotification_icon);
            UI_Driver.Wait(2000);
            UI_Driver.WaitUntilElementExists(PODashboard.header_notification, 20);
        }

        [Then(@"Notification window will open with View All, Filter & Sort button and Notifications header")]
        public void ThenNotificationWindowWillOpenWithViewAllFilterSortButtonAndNotificationsHeader()
        {
            UI_Driver.Click(PODashboard.btn_viewAll);
            UI_Driver.Click(PODashboard.btn_filterSort);
        }

        [Then(@"user close Notification window")]
        public void ThenUserCloseNotificationWindow()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.closeNotification_icon, 20);
            UI_Driver.Click(PODashboard.closeNotification_icon);
        }


        [When(@"user click on Filter & Sort button")]
        public void WhenUserClickOnFilterSortButton()
        {
            UI_Driver.Wait(2000);
            UI_Driver.WaitUntilElementExists(PODashboard.btn_viewAll, 20);
            UI_Driver.Click(PODashboard.btn_viewAll);
            UI_Driver.WaitUntilElementExists(PODashboard.btn_filterSort, 10);
            UI_Driver.Click(PODashboard.btn_filterSort);
        }

        [Then(@"user will verify SORT & FILTER header")]
        public void ThenUserWillVerifySORTFILTERHeader()
        {
            UI_Driver.VerifyText("FILTER & SORT", PODashboard.header_sortFilter);
        }

        [Then(@"user will click on clear all button")]
        public void ThenUserWillClickOnClearAllButton()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.btn_clearAll, 10);
            UI_Driver.Click(PODashboard.btn_clearAll);
        }

        [Then(@"user will select Date Descending from sort dropdown")]
        public void ThenUserWillSelectDateDescendingFromSortDropdown()
        {
            UI_Driver.Click(PODashboard.btn_chooseAsort);
            UI_Driver.WaitUntilElementExists(PODashboard.sortByOldestToNewest, 10);
            UI_Driver.Click(PODashboard.sortByOldestToNewest);
        }

        [Then(@"user will select Date Ascending from sort dropdown")]
        public void ThenUserWillSelectDateAscendingFromSortDropdown()
        {
            UI_Driver.Click(PODashboard.btn_chooseAsort);
            UI_Driver.WaitUntilElementExists(PODashboard.btn_DateAscending, 10);
            UI_Driver.Click(PODashboard.btn_DateAscending);
        }

        [Then(@"user will select asset")]
        public void ThenUserWillSelectAsset()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.checkbox_selection, 10);
            UI_Driver.Click(PODashboard.checkbox_selection);
        }

        [Then(@"user will select multiple from category list")]
        public void ThenUserWillSelectMultipleFromCategoryList()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.btn_category, 10);
            UI_Driver.Click(PODashboard.btn_category);
            UI_Driver.WaitUntilElementExists(PODashboard.checkbox_selectionForCategory, 10);
            UI_Driver.CheckBoxOrRadioButtonIsSelected(PODashboard.checkbox_selectionForCategory);
        }


        [Then(@"user will select only one from category list")]
        public void ThenUserWillSelectOnlyOneFromCategoryList()
        {
            UI_Driver.WaitUntilElementExists(PODashboard.btn_category, 10);
            UI_Driver.Click(PODashboard.btn_category);
            UI_Driver.WaitUntilElementExists(PODashboard.checkbox_selectionForCategory, 10);
            UI_Driver.CheckBoxOrRadioButtonIsSelected(PODashboard.checkbox_operatingLimit);
        }

        [Then(@"user will click on show result")]
        public void ThenUserWillClickOnShowResult()
        {
            UI_Driver.Wait(1000);
            UI_Driver.Click(PODashboard.click_OnPriority);
            UI_Driver.Click(PODashboard.select_PriorityFromDD);
            UI_Driver.WaitUntilElementExists(PODashboard.btn_showResult, 10);
            UI_Driver.Click(PODashboard.btn_showResult);
        }

        [Then(@"user will verify first,last,count value for asset(.*) is as Expected")]
        public void ThenUserWillVerifyFirstLastCountValueForAssetDCIsAsExpected(string assetCollection)
        {
            UI_Driver.Wait(1000);
        }

        [Then(@"user will see data in Ascending order (.*)")]
        public void ThenUserWillSeeDataInAscendingOrder(string order)
        {
            //UI_Driver.CommonLogicForAscendingDescending(PODashboard.text_notificationtymForAscendingDescending, order);
        }

        [Then(@"user will verify all selected sort& filter with result")]
        public void ThenUserWillVerifyAllSelectedSortFilterWithResult()
        {
            var name_sortAndFilter = UI_Driver.GetText(PODashboard.verify_allSortAndFilterData);
            UI_Driver.VerifyText("Asset", PODashboard.text_AssetNotification);
        }

        [Then(@"user will click on Asset Tab")]
        public void ThenUserWillClickOnAssetTab()
        {
            UI_Driver.Click(PODashboard.text_AssetNotification);
        }

        [Then(@"verify all the details")]
        public void ThenVerifyAllTheDetails()
        {
            UI_Driver.VerifyText("Event Details", PODashboard.text_EventDetails);
            UI_Driver.VerifyText("Description", PODashboard.text_description);
            UI_Driver.VerifyText("Cause", PODashboard.text_cause);
            UI_Driver.VerifyText("Consequence", PODashboard.text_consequence);
            UI_Driver.VerifyText("Recommenedations", PODashboard.text_recommenedation);
            UI_Driver.VerifyText("Add Observations", PODashboard.text_addObservation);
            UI_Driver.VerifyText("Fault Category", PODashboard.text_faultCategory);
            UI_Driver.VerifyText("Reason", PODashboard.text_reason);
            UI_Driver.VerifyText("Related Information", PODashboard.text_relatedInfo);
            UI_Driver.Click(PODashboard.click_FaultCategory);
            UI_Driver.Click(PODashboard.Select_firstCategory);
            UI_Driver.Click(PODashboard.click_ChooseReason);
            UI_Driver.Click(PODashboard.Select_firstReason);
            UI_Driver.EnterText("Entered text through Automation", PODashboard.text_additionalComments);
            UI_Driver.Click(PODashboard.click_CloseEvent);
            //UI_Driver.VerifyText("Save", PODashboard.btn_save);
        }
        [Then(@"user click on back button")]
        public void ThenUserClickOnBackButton()
        {
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.btn_back);
        }

        [Then(@"user will verify Notifications header")]
        public void ThenUserWillVerifyNotificationsHeader()
        {
            UI_Driver.VerifyText("NOTIFICATIONS", PODashboard.header_notification);
        }

        [Then(@"again user will click on Asset Tab")]
        public void ThenAgainUserWillClickOnAssetTab()
        {
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.text_AssetNotification);
        }

        [Then(@"user will click save button")]
        public void ThenUserWillClickSaveButton()
        {
            UI_Driver.Click(PODashboard.click_FaultCategory);
            UI_Driver.Click(PODashboard.Select_firstCategory);
            UI_Driver.Click(PODashboard.click_ChooseReason);
            UI_Driver.Click(PODashboard.Select_firstReason);
            UI_Driver.EnterText("Entered another text through Automation", PODashboard.text_additionalComments);
            UI_Driver.Click(PODashboard.click_CloseEvent);
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.btn_back);
            //UI_Driver.Click(PODashboard.btn_save);
            UI_Driver.Wait(5000);
        }

        [Then(@"user will click on clear filter button")]
        public void ThenUserWillClickOnClearFilterButton()
        {
            UI_Driver.Click(PODashboard.btn_FilterClear);

        }

        [Then(@"user click on Notification bell icon")]
        public void ThenUserClickOnNotificationBellIcon()
        {
            UI_Driver.Click(PODashboard.btn_closeNotificationWindow);
            //UI_Driver.Click(PODashboard.clickOnNotification_icon);
            UI_Driver.WaitUntilElementExists(PODashboard.header_notification, 10);
        }

        #endregion

        #region Avg production loss

        [Then(@"user will verify cpm count as six for Avg production loss")]
        public void ThenUserWillVerifyCpmCountAsSixForAvgProductionLoss()
        {
            UI_Driver.WaitUntilElementExisting(PODashboard.avgProdLossPanel, 60);
            var totalCount = UI_Driver.TotalCount(PODashboard.AverageProductionLoss);
            if (totalCount != 6)
                Assert.IsTrue(totalCount.Equals(6), $"The expected string: '{6}' is not matched with actual string: '{totalCount}'");
        }

        [Then(@"user will check all six cpm name")]
        public void ThenUserWillCheckAllSixCpmName()
        {
            IList<string> AllCpmName = UI_Driver.GetText(PODashboard.AverageProductionLoss);
            foreach (string cpmName in AllCpmName)
            {
                if (cpmName.Contains("AbortLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"AbortLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else if (cpmName.Contains("BadGapLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"BadGapLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else if (cpmName.Contains("DowntimeLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"DowntimeLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else if (cpmName.Contains("IdletimeLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"IdletimeLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else if (cpmName.Contains("MistrackLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"MistrackLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else if (cpmName.Contains("ReadErrorLossCPM"))
                    Assert.IsTrue(true, $"The expected string: '{"ReadErrorLossCPM"}' is not existing in the List of actual string: '{cpmName}'");
                else
                    Assert.IsTrue(false, $"The expected string is not existing in the List of actual string: '{cpmName}'");
            }
        }

        #endregion

        #region Asset Utilization

        [Then(@"user will check (.*) kpi data for asset(.*), asset(.*) and duration (.*) is as Expected in (.*)")]
        public void ThenUserWillCheckAllEightKpiNameAndDataForAllAssetDCAndDurationShiftIsAsExpected(string KpiName, string assetname, string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            try
            {
                //KPI data from DB
                Dictionary<string, string> kpiData_DB = DBConnection.Getkpivalues(assetname, assetCollection, ViewByDay_ViewByShift, env);

                //KPI data from UI
                List<string> kpi_value = new List<string>();
                IList<string> hourCpmNameUI = UI_Driver.GetText(PODashboard.Utilize_DD1);
                foreach (string kpiValue1 in hourCpmNameUI)
                {
                    kpi_value.Add(kpiValue1);
                }
                IList<string> hourminCpmNameUI = UI_Driver.GetText(PODashboard.Utilize_DD2);
                foreach (string kpiValue2 in hourminCpmNameUI)
                {
                    kpi_value.Add(kpiValue2);
                }
                IList<string> CpmNameUI = UI_Driver.GetText(PODashboard.Utilize_DD3);
                foreach (string kpiValue3 in CpmNameUI)
                {
                    kpi_value.Add(kpiValue3);
                }

                //KPI DB verification with UI
                IList<string> AllCpmName = UI_Driver.GetText(PODashboard.All_AvgProductionLoss_Utilization);
                HashSet<string> uniqueName = new HashSet<string>(AllCpmName);
                if (KpiName == "ALL")
                {
                    foreach (string cpmName in uniqueName)
                    {
                        if (cpmName.Equals("Downtime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            var downtimeCPMValue_DB = kpiData_DB[cpmName + "1"];
                            Assert.IsTrue(kpi_value.Contains(downtimeCPMValue_DB), $"The expected string: '{downtimeCPMValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{downtimeValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                        }
                        else if (cpmName.Contains("EnergyOff"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"EnergyOff"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("FullTime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"FullTime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Idletime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            var downtimeCPMValue_DB = kpiData_DB[cpmName + "1"];
                            Assert.IsTrue(kpi_value.Contains(downtimeCPMValue_DB), $"The expected string: '{downtimeCPMValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Idletime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Uptime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Uptime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Remaining"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Remaining"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Aborts"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Aborts"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Bad Gaps"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Bad Gaps"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Mistracks"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Mistracks"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Read Errors"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Read Errors"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                    }

                }
                else if (KpiName == "Utilization")
                {
                    foreach (string cpmName in uniqueName)
                    {
                        if (cpmName.Equals("Downtime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{downtimeValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                        }
                        else if (cpmName.Contains("EnergyOff"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"EnergyOff"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("FullTime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"FullTime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Idletime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Idletime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Uptime"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Uptime"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Remaining"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Remaining"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                    }
                }
                else if (KpiName == "Average Production Loss")
                {
                    foreach (string cpmName in uniqueName)
                    {
                        if (cpmName.Equals("Downtime"))
                        {
                            var downtimeCPMValue_DB = kpiData_DB[cpmName + "1"];
                            Assert.IsTrue(kpi_value.Contains(downtimeCPMValue_DB), $"The expected string: '{downtimeCPMValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                        }
                        else if (cpmName.Contains("Idletime"))
                        {
                            var downtimeCPMValue_DB = kpiData_DB[cpmName + "1"];
                            Assert.IsTrue(kpi_value.Contains(downtimeCPMValue_DB), $"The expected string: '{downtimeCPMValue_DB}' is not existing in the List of actual string: '{kpi_value}'");
                        }
                        else if (cpmName.Contains("Aborts"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Aborts"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Bad Gaps"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Bad Gaps"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Mistracks"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Mistracks"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                        else if (cpmName.Contains("Read Errors"))
                        {
                            var downtimeValue_DB = kpiData_DB[cpmName];
                            Assert.IsTrue(kpi_value.Contains(downtimeValue_DB), $"The expected string: '{"Read Errors"}' is not existing in the List of actual string: '{cpmName}'");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("KpiNameAndData" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        [When(@"user will select (.*) from dropdown it will display kpi")]
        public void WhenUserWillSelectAllFromDropdownAndItWillDisplayKpi(string component)
        {
            UI_Driver.Wait(5000);
            UI_Driver.WaitUntilElementExisting(PODashboard.dropdown_abortText, 60);
            UI_Driver.Click(PODashboard.click_AllAvgprodUtilizationDD);
            Driver_UI.kpiSelectionFromDD(component);
            int actualCount = UI_Driver.TotalCount(PODashboard.All_AvgProductionLoss_Utilization);
            //Assert.IsTrue(expectedCount.Equals(actualCount), $"The expected kpi count is not matching with the actual kpi count: '{actualCount}'");
        }

        #endregion

        #region ErrorKpi

        [Then(@"user will verify NoRead,Recircularation rate and Full lanes text")]
        public void ThenUserWillVerifyNoReadPercent()
        {
            UI_Driver.VerifyText("No Reads", PODashboard.ErrorKPi);
            UI_Driver.VerifyText("Recirculation Rate", PODashboard.RecirculationRate);
            UI_Driver.VerifyText("Full Lanes", PODashboard.FullLanes);
        }

        [When(@"user select shipping(.*) from drop down")]
        public void WhenUserSelectShippingDCLowerShippingFromDropDown(string ddShippingselection)
        {
            UI_Driver.Wait(1000);
            UI_Driver.Click(PODashboard.click_shippingSelectionDD);
            Driver_UI.click_shippingDD(ddShippingselection);
        }


        [Then(@"NoReadPercent of ErrorKpi(.*) value with respect to asset(.*), asset(.*) as Expected on Shipping Dashboard in (.*) mode in (.*)")]
        public void ThenNoReadPercentRecirculationPercentLaneAvailablePercentOfErrorKpiNoReadPercentValueWithRespectiveAssetDCAsExpectedOnShippingDashboard(string errorKpi, string assetCollection, string assetname, string expansion, string env)
        {
            try {
                string _NoRead_DB = null;
                string _NoRead_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _NoRead_DB = DBConnection.GetNoRead(errorKpi, assetCollection, assetname, env);
                    Thread.Sleep(1000);
                    _NoRead_UI = UI_Driver.FetchDynamicValue(PODashboard.Noread);
                    if (expansion == "Expansion")
                    {
                        UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 30);
                        _NoRead_UI = UI_Driver.FetchDynamicValue(PODashboard.Noread_expansion);
                    }
                    if (_NoRead_DB.Equals(_NoRead_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_NoRead_DB.Equals(_NoRead_UI), $"The expected string: '{_NoRead_DB}' is not matched with actual string: '{_NoRead_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_NoRead" + DateTime.Now.ToString("yyyyMMddHHmmss"));
               // Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        [Then(@"RecirculationPercent of ErrorKpi(.*) value with respect to asset(.*), asset(.*) as Expected on Shipping Dashboard in (.*) mode in (.*)")]
        public void ThenRecirculationPercentLaneAvailablePercentOfErrorKpiRecirculationPercentValueWithRespectiveAssetDCAsExpectedOnShippingDashboard(string errorKpi, string assetCollection, string assetname, string expansion, string env)
        {
            try {
                string _RecirculationRate_DB = null;
                string _RecirculationRate_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _RecirculationRate_DB = DBConnection.GetRecirculationRate(errorKpi, assetCollection, assetname, env);
                    Thread.Sleep(1000);
                    _RecirculationRate_UI = UI_Driver.FetchDynamicValue(PODashboard.RecirculationRates);
                    if (expansion == "Expansion")
                    {
                        UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 30);
                        _RecirculationRate_UI = UI_Driver.FetchDynamicValue(PODashboard.RecirculationRates_expansion);
                    }
                    if (_RecirculationRate_DB.Equals(_RecirculationRate_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_RecirculationRate_DB.Equals(_RecirculationRate_UI), $"The expected string: '{_RecirculationRate_DB}' is not matched with actual string: '{_RecirculationRate_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_RecirculationRate" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        [Then(@"LaneAvailablePercent of ErrorKpi(.*) value with respect to asset(.*), asset(.*) as Expected on Shipping Dashboard in (.*) mode in (.*)")]
        public void ThenLaneAvailablePercentOfErrorKpiRecirculationPercentValueWithRespectiveAssetDCAsExpectedOnShippingDashboard(string errorKpi, string assetCollection, string assetname, string expansion, string env)
        {
            try {
                string _FullLane_DB = null;
                string _FullLane_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _FullLane_DB = DBConnection.GetFullLane(errorKpi, assetCollection, assetname, env);
                    Thread.Sleep(1000);
                    _FullLane_UI = UI_Driver.FetchDynamicValue(PODashboard.FullLane);
                    if (expansion == "Expansion")
                    {
                        UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 30);
                        _FullLane_UI = UI_Driver.FetchDynamicValue(PODashboard.FullLane_expansion);
                    }
                    if (_FullLane_DB.Equals(_FullLane_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_FullLane_DB.Equals(_FullLane_UI), $"The expected string: '{_FullLane_DB}' is not matched with actual string: '{_FullLane_UI}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_FullLane" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Expansion Error KPI

        [Then(@"Gapping Errors of ErrorKpi(.*) value with respect to asset(.*), asset(.*) as Expected on Shipping Dashboard in (.*) mode in (.*)")]
        public void ThenGappingErrorsOfErrorKpiBadGapPercentValueWithRespectiveAssetDCAsExpectedOnShippingDashboardInExpansionMode(string errorKpi, string assetCollection, string assetname, string expansion, string env)
        {
            try
            {
                string _GappingError_DB = null;
                string _GappingError_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _GappingError_DB = DBConnection.GetGappingError(errorKpi, assetCollection, assetname, env);
                    Thread.Sleep(1000);
                    _GappingError_UI = UI_Driver.FetchDynamicValue(PODashboard.GappingError_expansion);
                    if (_GappingError_DB.Equals(_GappingError_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_GappingError_DB.Equals(_GappingError_UI), $"The expected string: '{_GappingError_DB}' is not matched with actual string: '{_GappingError_UI}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_GappingError" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }

        }

        [Then(@"Tracking Errors of ErrorKpi(.*) value with respect to asset(.*), asset(.*) as Expected on Shipping Dashboard in (.*) mode in (.*)")]
        public void ThenTrackingErrorsOfErrorKpiMistrackPercentValueWithRespectiveAssetDCAsExpectedOnShippingDashboardInExpansionMode(string errorKpi, string assetCollection, string assetname, string expansion, string env)
        {
            try {
                string _TrackingError_DB = null;
                string _TrackingError_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    _TrackingError_DB = DBConnection.GetTrackingError(errorKpi, assetCollection, assetname, env);
                    Thread.Sleep(1000);
                    _TrackingError_UI = UI_Driver.FetchDynamicValue(PODashboard.TrackingError_expansion);
                    if (_TrackingError_DB.Equals(_TrackingError_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(_TrackingError_DB.Equals(_TrackingError_UI), $"The expected string: '{_TrackingError_DB}' is not matched with actual string: '{_TrackingError_UI}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("_TrackingError" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }
    

        #endregion

        #region Picking Dashboard

        [When(@"user will click on Filter drop down")]
        public void WhenUserWillClickOnFilterDropDown()
        {
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.clk_filter);
        }

        [Then(@"user will select (.*) from Filter drop down")]
        public void ThenUserWillSelectLowThroughputFromFilterDropDown(string kpiName)
        {
            Driver_UI.selectKPIFromDD_pickingDashboard(kpiName);
        }

        [Then(@"user will verify PicMod(.*) PickMod(.*) Efficiency, Throughput, Rate/Hr for (.*) UI value with DB for selected kpi (.*) in (.*)")]
        public void ThenUserWillVerifyDCPickModDCPickModEfficiencyThroughputRateHrForShiftUIValueWithDBForSelectedKpiLowThroughput(string pickmod, string assetCollection, string ViewByDay_ViewByShift, string kpiname, string env)
        {
            try
            {
                List<string> pickModule = null;
                string efficiency;
                string rateHr;
                string status;
                for (int i = 1; i <= 10; i++)
                {
                    status = DBConnection.GetStatusForPickModule(assetCollection, ViewByDay_ViewByShift, env);
                    efficiency = DBConnection.GetEfficiencyForPickingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    if (efficiency.Contains("∞"))
                        efficiency = efficiency.Replace(efficiency, "--");
                    string throughput = DBConnection.GetThroughputForPickingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    rateHr = DBConnection.GetRate_HrForPickingDashboard(assetCollection, ViewByDay_ViewByShift, env);
                    UI_Driver.Wait(2000);

                    switch (assetCollection)
                    {
                        case "DC3PickMod1":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                        case "DC3PickMod2":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                        case "DC3PickMod3":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                        case "DC5PickMod1":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                        case "DC5PickMod2":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                        case "DC5PickMod3":
                            pickModule = Driver_UI.performPickModuleFromFilterForAll3_PickMod1(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column);
                            break;
                    }


                    UI_Driver.Wait(1000);
                    UI_Driver.Click(PODashboard.close_openKpi);
                    refreshPageMethod(ViewByDay_ViewByShift);
                    UI_Driver.Wait(1000);
                    UI_Driver.Click(PODashboard.ClickOnFilterDD);
                    UI_Driver.Wait(1000);
                    Driver_UI.selectKPIFromDD_pickingDashboard(kpiname);
                    if (pickModule.Contains(efficiency) && pickModule.Contains(throughput))
                    {
                        Assert.IsTrue(pickModule.Contains(efficiency), $"The expected string: '{efficiency}' is not existing in the List of actual string: '{pickModule}'");
                        Assert.IsTrue(pickModule.Contains(status), $"The expected string: '{status}' is not existing in the List of actual string: '{pickModule}'");
                        Assert.IsTrue(pickModule.Contains(throughput), $"The expected string: '{throughput}' is not existing in the List of actual string: '{pickModule}'");
                        Assert.IsTrue(pickModule.Contains(rateHr), $"The expected string: '{rateHr}' is not existing in the List of actual string: '{pickModule}'");
                        break;
                    }

                }
            }
            catch (Exception ex)
            {
                //Assert.Fail();
                //_logger.Error("Driver_UI || Method_Name: Exception {0} ", ex.Message);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("pickMod_efficiency" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        [Then(@"Average Throughput value of (.*) with asset (.*), (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenAverageThroughputValueOfLowerShippingWithShiftIsAsExpectedOnShippingDashboard(string shipping, string assetname, string shift_day, string env)
        {
            try {
                string AvgThroughput_DB = null;
                string AvgThroughput_UI = null;
                for (int i = 1; i <= 3; i++)
                {
                    AvgThroughput_DB = DBConnection.GetAvgThroughput(shipping, assetname, shift_day, env);
                    UI_Driver.Wait(1000);
                    AvgThroughput_UI = UI_Driver.FetchDynamicValue(PODashboard.dynamic_avgThroughput);
                    AvgThroughput_UI = AvgThroughput_UI + "%";
                    if (AvgThroughput_DB.Equals(AvgThroughput_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(AvgThroughput_DB.Equals(AvgThroughput_UI), $"The expected string: '{AvgThroughput_DB}' is not matched with actual string: '{AvgThroughput_UI}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("AvgThroughput" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        [Then(@"Cartons per minute peak value of (.*) with asset(.*), (.*) is as Expected on Shipping Dashboard in (.*)")]
        public void ThenCartonsPerMinutePickValueOfDCLowerShippingWithShiftIsAsExpectedOnShippingDashboard(string shipping, string assetname, string shift_day, string env)
        {
            try {
                string CartonsPerMin_DB = null;
                string CartonsPerMin_UI = null;
                List<string> values;
                for (int i = 1; i <= 3; i++)
                {
                    CartonsPerMin_DB = DBConnection.GetCartonsPerMinPeakValue(shipping, assetname, shift_day, env);
                    UI_Driver.Wait(1000);
                    values = Driver_UI.FetchLastDynamicElement(PODashboard.dynamic_cpm_value);
                    int count = values.Count;
                    CartonsPerMin_UI = values[count - 1];
                    if (CartonsPerMin_DB.Equals(CartonsPerMin_UI))
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(CartonsPerMin_DB.Equals(CartonsPerMin_UI), $"The expected string: '{CartonsPerMin_DB}' is not matched with actual string: '{CartonsPerMin_UI}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("CartonsPerMin" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        [Then(@"user will verify Asset Utlization value with PicMod(.*) data for PickMod(.*) asset with respect to (.*) UI value with DB for selected kpi (.*) in (.*)")]
        public void ThenUserWillVerifyAssetUtlizationValueWithPicModPickModDataForDCPickModDCPickModAssetWithRespectToShiftUIValueWithDBForSelectedKpiLowThroughputInQA(string pickmodHeader, string assetCollection, string ViewByDay_ViewByShift, string kpiname, string env)
        {
            try
            {
                Dictionary<string, string> assetUtilization_DB = null;
                Dictionary<string, string> assetUtilization_UI = null;
                Dictionary<string, string> diff = null;

                for (int i = 1; i <= 5; i++)
                {
                    assetUtilization_DB = DBConnection.AssetUtilizationValue(assetCollection, ViewByDay_ViewByShift, env);

                    switch (assetCollection)
                    {
                        case "DC3PickMod1":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod1, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                        case "DC3PickMod2":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod2, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                        case "DC3PickMod3":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod3, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                        case "DC5PickMod1":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod1, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                        case "DC5PickMod2":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod2, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                        case "DC5PickMod3":
                            assetUtilization_UI = Driver_UI.captureAssetUtlizationData(assetCollection, PODashboard.clickOnPickMod3, PODashboard.assetUtilize_keyKPIName, PODashboard.assetUtilize_ValueOfKPIName);
                            break;
                    }

                    refreshPageMethod(ViewByDay_ViewByShift);
                    UI_Driver.Wait(1000);
                    UI_Driver.Click(PODashboard.clk_filter);
                    UI_Driver.Wait(1000);
                    Driver_UI.selectKPIFromDD_pickingDashboard(kpiname);

                    diff = assetUtilization_DB.Where(x => x.Value != assetUtilization_UI[x.Key]).ToDictionary(x => x.Key, x => x.Value);
                    if (diff.Count == 0)
                    {
                        Assert.IsTrue(true);
                        break;
                    }
                }
                Assert.IsTrue(diff.Count == 0, $"The expected string: '{assetUtilization_DB.Keys}' is not matched with actual string: '{assetUtilization_UI.Keys}'");
            }
            catch (Exception ex)
            {
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("assetUtilizationWithPicMod" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        #endregion

        #region Panda Dashboad

        #region Error KPis

        [When(@"user click on Expand button")]
        public void WhenUserClickOnExpandButton()
        {
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.clk_Expandbtn);
        }

        [Then(@"user close Error kpi window")]
        public void ThenUserCloseErrorKpiWindow()
        {
            UI_Driver.Wait(2000);
            UI_Driver.Click(PODashboard.closeErrorKpiWindow);
        }

        [Then(@"user verify Mislabeled Errors value of Error KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenUserVerifyMislabeledErrorsValueOfErrorKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard_withoutExpanded(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _MislabeledErrors_DB = null;
            string _MislabeledErrors_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 20);
                _MislabeledErrors_DB = DBConnection.GetMislabeledError_ErrorKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _MislabeledErrors_UI = UI_Driver.FetchDynamicValue(PODashboard.Mislabeled_errorKpi_expanded);
                if (_MislabeledErrors_DB.Equals(_MislabeledErrors_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_MislabeledErrors_DB.Equals(_MislabeledErrors_UI), $"The expected string: '{_MislabeledErrors_DB}' is not matched with actual string: '{_MislabeledErrors_UI}'");
        }

        [Then(@"user verify Tracking Errors value of Error KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard for (.*)")]
        public void ThenUserVerifyTrackingErrorsValueOfErrorKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _TrackingErrors_DB = null;
            string _TrackingErrors_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 20);
                _TrackingErrors_DB = DBConnection.GetTrackingError_ErrorKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _TrackingErrors_UI = UI_Driver.FetchDynamicValue(PODashboard.Tracking_errorKpi);
                if (_TrackingErrors_DB.Equals(_TrackingErrors_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_TrackingErrors_DB.Equals(_TrackingErrors_UI), $"The expected string: '{_TrackingErrors_DB}' is not matched with actual string: '{_TrackingErrors_UI}'");
        }

        [Then(@"user verify Scanner Errors value of Error KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenUserVerifyScannerErrorsValueOfErrorKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ScannerErrors_DB = null;
            string _ScannerErrors_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ErrorKPI_Header, 60);
                _ScannerErrors_DB = DBConnection.GetScannerError_ErrorKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ScannerErrors_UI = UI_Driver.FetchDynamicValue(PODashboard.Scanner_errorKpi);
                if (_ScannerErrors_DB.Equals(_ScannerErrors_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_ScannerErrors_DB.Equals(_ScannerErrors_UI), $"The expected string: '{_ScannerErrors_DB}' is not matched with actual string: '{_ScannerErrors_UI}'");
        }


        #endregion

        #region Productivity Kpi's

        [Then(@"Total Cartons value of Productivity KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenTotalCartonsValueOfProductivityKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _TotalCartons_DB = null;
            string _TotalCartons_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ProductivityKPI_Header, 60);
                Thread.Sleep(1000);
                _TotalCartons_DB = DBConnection.GetTotalCartons_ProductivityKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _TotalCartons_UI = UI_Driver.FetchDynamicValue(PODashboard.totalCartons);
                if (_TotalCartons_DB.Equals(_TotalCartons_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_TotalCartons_DB.Equals(_TotalCartons_UI), $"The expected string: '{_TotalCartons_DB}' is not matched with actual string: '{_TotalCartons_UI}'");
        }

        [Then(@"Total Rejects value of Productivity KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenTotalRejectsValueOfProductivityKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _TotalRejects_DB = null;
            string _TotalRejects_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ProductivityKPI_Header, 60);
                Thread.Sleep(1000);
                _TotalRejects_DB = DBConnection.GetTotalRejects_ProductivityKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _TotalRejects_UI = UI_Driver.FetchDynamicValue(PODashboard.totalrejects);
                if (_TotalRejects_DB.Equals(_TotalRejects_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_TotalRejects_DB.Equals(_TotalRejects_UI), $"The expected string: '{_TotalRejects_DB}' is not matched with actual string: '{_TotalRejects_UI}'");
        }

        [Then(@"Average Carton Length value of Productivity KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenAverageCartonLengthValueOfProductivityKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _AverageCartonLength_DB = null;
            string _AverageCartonLength_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ProductivityKPI_Header, 60);
                Thread.Sleep(1000);
                _AverageCartonLength_DB = DBConnection.GetAverageCartonLength_ProductivityKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _AverageCartonLength_UI = UI_Driver.FetchDynamicValue(PODashboard.avgCartonLength);
                if (_AverageCartonLength_DB.Equals(_AverageCartonLength_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_AverageCartonLength_DB.Equals(_AverageCartonLength_UI), $"The expected string: '{_AverageCartonLength_DB}' is not matched with actual string: '{_AverageCartonLength_UI}'");
        }

        [Then(@"Active Labelers value of Productivity KPI's for asset(.*) and duration (.*) is as Expected on Panda Dashboard in (.*)")]
        public void ThenActiveLabelersValueOfProductivityKPISForAssetDCAndDurationShiftIsAsExpectedOnPandaDashboard(string assetCollection, string ViewByDay_ViewByShift, string env)
        {
            string _ActiveLabelers_DB = null;
            string _ActiveLabelers_UI = null;
            for (int i = 1; i <= 3; i++)
            {
                UI_Driver.WaitUntilElementExisting(PODashboard.ProductivityKPI_Header, 60);
                Thread.Sleep(1000);
                _ActiveLabelers_DB = DBConnection.GetActiveLabelers_ProductivityKpi(assetCollection, ViewByDay_ViewByShift, env);
                Thread.Sleep(1000);
                _ActiveLabelers_UI = UI_Driver.FetchDynamicValue(PODashboard.activeLabelers);
                if (_ActiveLabelers_DB.Equals(_ActiveLabelers_UI))
                {
                    Assert.IsTrue(true);
                    break;
                }
            }
            Assert.IsTrue(_ActiveLabelers_DB.Equals(_ActiveLabelers_UI), $"The expected string: '{_ActiveLabelers_DB}' is not matched with actual string: '{_ActiveLabelers_UI}'");
        }


        #endregion

        #region Panda Lanes

        [Then(@"(.*) value of Panda Lanes for asset(.*) and duration (.*) is as Expected on Panda Dashboard (.*) in (.*)")]
        public void ThenLowThroughputValueOfPandaLanesForAssetDCPandALineAndDurationShiftIsAsExpectedOnPandaDashboardPandALine(string kpi, string assetCollection, string ViewByDay_ViewByShift, string kpiName_UI, string env)
        {
            for (int i = 1; i <= 5; i++)
            {
                List<string> pandaLane = null;
                string throughput = DBConnection.GetThroughput_PandaLane(assetCollection, ViewByDay_ViewByShift, env);
                string reject = DBConnection.GetReject_PandaLane(assetCollection, ViewByDay_ViewByShift, env);
                string scannerError = DBConnection.GetScannerErrors_PandaLane(assetCollection, ViewByDay_ViewByShift, env);
                string trackingError = DBConnection.GetTrackingErrors_PandaLane(assetCollection, ViewByDay_ViewByShift, env);
                string labelsPrinted = DBConnection.GetLabelsPrinted_PandaLane(assetCollection, ViewByDay_ViewByShift, env);

                switch (kpi.ToLower().Trim())
                {
                    case "low throughput":
                    case "rejects":
                    case "scanner errors":
                    case "tracking scanner errors":
                    case "mislabeled errors":
                    case "downtime":
                        pandaLane = Driver_UI.VerifyPandaLanesValuesFromFilterDD(assetCollection, PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column, kpiName_UI);
                        break;
                }

                if (pandaLane.Contains(throughput))
                {
                    Assert.IsTrue(pandaLane.Contains(throughput), $"The expected string: '{throughput}' is not existing in the List of actual string: '{pandaLane}'");
                    Assert.IsTrue(pandaLane.Contains(reject), $"The expected string: '{reject}' is not existing in the List of actual string: '{pandaLane}'");
                    Assert.IsTrue(pandaLane.Contains(scannerError), $"The expected string: '{scannerError}' is not existing in the List of actual string: '{pandaLane}'");
                    Assert.IsTrue(pandaLane.Contains(trackingError), $"The expected string: '{trackingError}' is not existing in the List of actual string: '{pandaLane}'");
                    //Assert.IsTrue(pandaLane.Contains(labelsPrinted), $"The expected string: '{labelsPrinted}' is not existing in the List of actual string: '{pandaLane}'");
                    break;
                }
            }
        }

        #endregion

        #endregion

        #region Expand btn

        [When(@"user will click on Expand button")]
        public void WhenUserWillClickOnExpandButton()
        {
            UI_Driver.Click(PODashboard.btn_expand);
        }

        [Then(@"user will see the Expanded dashboard is as Expected")]
        public void ThenUserWillSeeTheExpandedDashboardIsAsExpected()
        {
            UI_Driver.Wait(2000);
        }


        #endregion

        #region Shipping Lanes

        [Then(@"(.*) value of Shipping Lanes for asset(.*) and duration (.*) is as Expected (.*) in (.*)")]
        public void ThenKpiValueForSorter(string kpiname, string assetName, string ViewByDay_ViewByShift, string sorterLane, string env)
        {
            try
            {
                Dictionary<string, string> values_DB = null;
                Dictionary<string, string> values_UI = null;
                Dictionary<string, string> diff_DB = null;
                Dictionary<string, string> diff_UI = null;
                //Dictionary<string, string> keyValue = null;
                string[] a1 = null;

                for (int i = 1; i <= 5; i++)
                {
                    switch (kpiname)
                    {
                        case "Low Throughput":
                        case "Aborts":
                        case "Downtime":
                        case "Volume":
                        case "100% Full":
                            values_DB = DBConnection.GetkpivaluesForSorter(assetName, ViewByDay_ViewByShift, env);
                            break;
                    }

                    values_UI = Driver_UI.VerifyShippingLanesValues(PODashboard.pickModule_picking_row, PODashboard.pickModule_picking_column, sorterLane);
                    refreshPageMethod(ViewByDay_ViewByShift);

                    //If you sure all keys are same you can do:
                    //var result = values_DB.Except(values_UI).ToDictionary(x => x.Key, x => x.Value);
                    diff_DB = values_DB.Where(x => x.Value != values_UI[x.Key]).ToDictionary(x => x.Key, x => x.Value);

                    diff_UI = values_UI.Where(x => x.Value != values_DB[x.Key]).ToDictionary(x => x.Key, x => x.Value);
                    a1 = diff_DB.Keys.ToArray();

                    //string[] keyValue = diff.;
                    //var val  = keyValue.ToArray<string>();
                    //var listValue = diff_DB.ToList<string>();
                    if (diff_DB.Count == 0)
                    {
                        Assert.IsTrue(true);
                        break;
                    }

                }
                StringBuilder s = null;
                StringBuilder s1 = null;
                StringBuilder s2 = null;

                for (int j = 0; j < a1.Length; j++)
                {
                    string a = a1[j];
                    s = new StringBuilder(a1[j]);
                    s = s.Append(s + " ");

                    string v1 = diff_DB[a];
                    s1 = new StringBuilder(diff_DB[a]);
                    s1 = s1.Append(s1 + " ");

                    string v2 = diff_UI[a];
                    s2 = new StringBuilder();
                    s2 = s2.Append(s2 + " ");

                    ///Assert.IsTrue(diff_DB.Count == 0, $"The expected value for the column: '{a}' is '{v1}' not matched with actual string: '{v2}'");
                }


                Assert.IsTrue(diff_DB.Count == 0, $"The expected values for the columns: '{s}' is '{s1}' not matched with actual values of the columns: '{s2}'");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                UI_Driver.screenshotpath = UI_Driver.GetScreenshot("diff_DB" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }

        #endregion

    }


}

