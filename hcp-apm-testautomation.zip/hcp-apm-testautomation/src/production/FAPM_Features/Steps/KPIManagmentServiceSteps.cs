﻿using System;
using System.Collections.Generic;
using System.Net;
using FAPM_Driver;
using FAPM_Driver.Helpers;
using FAPM_Driver.Share;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class KPIManagmentServiceSteps
    {

        [Given(@"a KPI data is generated with parameters like (.*),(.*),(.*),(.*),(.*),(.*) with Target (.*)")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithTarget(string assetname, string kpiname, string metricfield , string reportingperiod, string startdate, string effectivedate, int tvalue)
        {
            ForgeAPMSQL.InsertKPIDataAPI(assetname, kpiname, metricfield, reportingperiod,startdate, effectivedate, tvalue);
        }

        [Given(@"a KPI data is generated with parameters like (.*),(.*),(.*),(.*),(.*),(.*) with Actual (.*)")]
        public void GivenAKPIDataIsGeneratedWithParametersLikeWithActual(string assetname, string kpiname, string metricfield, string reportingperiod, string startdate, string effectivedate, int avalue)
        {
            ForgeAPMSQL.InsertKPIDataAPI(assetname, kpiname, metricfield, reportingperiod,startdate, effectivedate, avalue);
        }

        [When(@"A request is placed for Metric data with (.*), KPI names (.*), frequency (.*), (.*) and (.*) for asset (.*)")]
        public void WhenARequestIsPlacedForMetricDataWithKPINamesFrequencyAnd(string custid, string kpiname, string frequency, string startdate, string enddate, string assetname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("Frequency", frequency);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._success, response);
            ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [Then(@"the service should return that metrics data for that asset (.*)")]
        public void ThenTheServiceShouldReturnThatMetricsDataForThatAsset(string assetname)
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed for Metric data with (.*) without asset name(.*) and KPI names (.*), frequency(.*), (.*) and (.*)")]
        public void WhenARequestIsPlacedForMetricDataWithWithoutAssetNameAndKPINamesFrequencyAnd(string custid, string assetname, string kpiname, string frequency, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("Frequency", frequency);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._failure, response);

            ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [Then(@"user should error with appropriate response code and message(.*)")]
        public void ThenUserShouldErrorWithAppropriateResponseCodeAndMessage(string error_message)
        {
            Assert.AreEqual((HttpStatusCode.BadRequest).ToString(), Out_Values.ResponseCode);
            Assert.AreEqual(error_message, " "+ Out_Values.KPIApi_json["message"].ToString());
            

        }

        [When(@"A request is placed without startdate for Metric data with (.*) Assetname (.*) and KPI names (.*), frequency (.*) and (.*)")]
        public void WhenARequestIsPlacedWithoutStartdateForMetricDataWithAssetnameAndKPINamesFrequencyAnd(string custid, string assetname, string kpiname, string frequency, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("Frequency", frequency);
            Queryparams.Add("EndDate", enddate);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._failure, response);

            ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [When(@"A request is placed without enddate for Metric data with (.*) Assetname (.*) and KPI names (.*), frequency (.*) and (.*)")]
        public void WhenARequestIsPlacedWithoutEnddateForMetricDataWithAssetnameAndKPINamesDatesAnd(string custid, string assetname, string kpiname, string frequency, string startdate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("Frequency", frequency);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._success, response);

            ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [When(@"A request is placed without frequency for Metric data with (.*) Assetname (.*) and KPI names (.*), duration (.*) and (.*)")]
        public void WhenARequestIsPlacedWithoutFrequencyForMetricDataWithAssetnameAndKPINamesDurationAnd(string custid, string assetname, string kpiname, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._failure, response);

            ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [When(@"A request is placed for Metric data with (.*) Assetname (.*), Frequency (.*), KPI Group Name(.*), duration (.*) and (.*)")]
        public void WhenARequestIsPlacedForMetricDataWithAssetnameKPIGroupNameDurationAnd(string custid, string assetname, string frequency, string kpigroupname, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KPIGroupName", kpigroupname);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            Queryparams.Add("Frequency", frequency);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._success, response);

            //ForgeAPMSQL.DeleteKPIData(assetname);
        }

        [When(@"A request is placed for the Metric data with (.*) Assetname (.*) KPI Group Name (.*), KPI Name (.*), duration (.*) and (.*)")]
        public void WhenARequestIsPlacedForTheMetricDataWithAssetnameKPIGroupNameKPINameDurationAnd(string custid, string assetname, string kpigroupname, string kpiname, string startdate, string enddate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", custid);
            Dictionary<string, string> Queryparams = new Dictionary<string, string>();
            Queryparams.Add("KPIGroupName", kpigroupname);
            Queryparams.Add("KpiNames", kpiname);
            Queryparams.Add("StartDate", startdate);
            Queryparams.Add("EndDate", enddate);
            Queryparams.Add("AssetName", assetname);
            var response = Driver.KPI_Metric_Service(Common.Inputs.API_urls.Kpiserver + Common.Inputs.API_urls.kpiMetricUrl, Common.Inputs.API_urls.customer_Id, Queryparams);
            Assert.AreEqual(Driver._failure, response);
        }

    }

}
