﻿using System;
using System.Net;
using TechTalk.SpecFlow;
using FAPM_Driver.Helpers;
using FAPM_Driver;
using FAPM_Driver.Share;
using System.Threading;
using NUnit.Framework;
using FAPM_Driver.Drivers;

namespace FAPM_Features.Steps
{
    [Binding]
    public class EventManagmentServiceSteps
    {
        ForgeAPMSQL fsq = new ForgeAPMSQL();


        [Given(@"The fault data for an asset (.*) exists in the database with following specifications (.*), (.*), (.*), (.*), (.*)")]
        public void GivenTheFalutDataForAnAssetExistsInTheDatabaseWithFollowingSpecifications(string assetName, string category, int faultState, int faultStatus, int priority, string startDate)
        {
            fsq.InsertEventCategoryDataForEventDataAPI(category, assetName, faultState, faultStatus, priority, startDate);
        }

        [When(@"User requested to get the faults count during a period (.*) and (.*) for an asset (.*) having category (.*)")]
        public void WhenUserRequestedToGetTheFaultsCountDuringAPeriodAnd(string fromDate, string toDate, string assetName, string faultCategory)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getFaultCountData(Environment_Values.EventMgmtServer + Environment_Values.GetAssetFaultCountDataEndPoint, assetName, fromDate, toDate, faultCategory, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return the asset fault count (.*) for given asset (.*) in response")]
        public void ThenTheAPIShouldReturnTheAssetFaultCountInResponse(int count, string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            Assert.AreEqual(count, Out_Values.ApiJsonOutput[0].Count);
            foreach (var assetFaultCountData in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)assetFaultCountData["assetName"]);
            }
            Assert.AreEqual(count, Out_Values.HelperList.Count);
            Assert.Contains(assetName, Out_Values.HelperList);
        }

        [When(@"User requested to get the faults count for an invalid asset (.*) during a period (.*) and (.*) having category (.*)")]
        public void WhenUserRequestedToGetTheFaultsCountForAnInvalidAssetDuringAPeriodAnd(string assetName, string fromDate, string toDate, string faultCategory)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getFaultCountData(Environment_Values.EventMgmtServer + Environment_Values.GetAssetFaultCountDataEndPoint, assetName, fromDate, toDate, faultCategory, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return empty response")]
        public void ThenTheAPIShouldReturnEmptyResponse()
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.IsEmpty(Out_Values.ApiJsonOutput[0]);
        }

        [When(@"User requested to get the failure faults count for an asset (.*) during a period (.*) and (.*) having category (.*)")]
        public void WhenUserRequestedToGetTheFailureFaultsCountForAnAssetDuringAPeriodAnd(string assetName, string fromDate, string toDate, string faultCategory)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getFaultCountData(Environment_Values.EventMgmtServer + Environment_Values.GetFailureFaultCountDataEndPoint, assetName, fromDate, toDate, faultCategory, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return the failure fault count (.*) for an asset (.*) in response")]
        public void ThenTheAPIShouldReturnTheFailureFaultCountForAnAssetInResponse(int count, string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var assetFaultData in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)assetFaultData["faultDisplayName"]);
            }
            Assert.AreEqual(count, Out_Values.HelperList.Count);
            Assert.Contains("SIT_FAULT_1", Out_Values.HelperList);
        }

        [When(@"User requested to get the failure faults count for an invalid asset (.*) during a period (.*) and (.*) having category (.*)")]
        public void WhenUserRequestedToGetTheFailureFaultsCountForAnInvalidAssetDuringAPeriodAndHavingCategory(string assetName, string fromDate, string toDate, string faultCategory)
        {

            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getFaultCountData(Environment_Values.EventMgmtServer + Environment_Values.GetFailureFaultCountDataEndPoint, assetName, fromDate, toDate, faultCategory, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [When(@"User requested to get the heat map matrix data (.*) (.*) (.*) during a period (.*) and (.*)")]
        public void WhenUserRequestedToGetTheHeatMapMatrixDataDuringAPeriodAnd(string hieararchyName, string rootNode, string heatMapFor, string startTime, string endTime)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getHeatMapMatrixData(Environment_Values.EventMgmtServer + Environment_Values.GetHeatMapMatrixEndPoint, startTime, endTime, hieararchyName, rootNode, heatMapFor, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return the heat map matrix data in response")]
        public void ThenTheAPIShouldReturnTheHeatMapMatrixDataInResponse()
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var matrixData in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)matrixData["assetName"]);
            }
            Assert.AreEqual(1, Out_Values.HelperList.Count);
            Assert.AreEqual("TTCBSorter", Out_Values.HelperList[0]);
        }

        [Given(@"The fault categories already exists in the database")]
        public void GivenTheFaultCategoriesAlreadyExistsInTheDatabase()
        {
            Console.WriteLine("All the categories exists in the data base");
        }

        [When(@"A user requested for fault categories list")]
        public void WhenAUserRequestedForFaultCategoriesList()
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getFaultCategoryData(Environment_Values.EventMgmtServer + Environment_Values.GetFaultCategoryDataEndPoint, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return the given categories (.*) (.*) (.*) in response")]
        public void ThenTheAPIShouldReturnTheGivenCategoriesInResponse(string category1, string category2, string category3)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var fault_categories in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)fault_categories["name"]);
            }
            Assert.Contains(category1, Out_Values.HelperList);
            Assert.Contains(category2, Out_Values.HelperList);
            Assert.Contains(category3, Out_Values.HelperList);
        }

        [When(@"A user required to update the notification request by passing (.*), (.*), (.*), (.*), (.*), (.*) (.*), (.*)")]
        public void WhenAUserRequiredToUpdateTheNotificationRequestByPassing(string assetId, string faultDisplayName, string timeStamp, string comments, string eventCategoryId, string reasonCode, string firstName, string lastName)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.updateNotificationRequest(Environment_Values.EventMgmtServer + Environment_Values.UpdateNotificationDataEndPoint, assetId, faultDisplayName, timeStamp, comments, eventCategoryId, reasonCode, firstName, lastName, Common.Inputs.API_urls.customer_Id);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"The API should return the valid response (.*)")]
        public void ThenTheAPIShouldReturnTheValidResponse(string p0)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Assert.Contains(true, Out_Values.ApiJsonOutput);
        }

        [Given(@"The Reason Codes are exists in the Database")]
        public void GivenTheReasonCodesAreExistsInTheDatabase()
        {
            Console.WriteLine("Reson codes are created in database");
        }

        [When(@"A User requested for Reason code data")]
        public void WhenAUserRequestedForReasonCodeData()
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.getReasonCodeData(Environment_Values.EventMgmtServer + Environment_Values.GetReasonCodeDataEndPoint, Common.Inputs.API_urls.customer_Id);
        }

        [Then(@"The API should return the Reason code data (.*), (.*), (.*) in response")]
        public void ThenTheAPIShouldReturnTheReasonCodeDataInResponse(string resonCode1, string resonCode2, string resonCode3)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var fault_categories in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)fault_categories["description"]);
            }
            Assert.Contains(resonCode1, Out_Values.HelperList);
            Assert.Contains(resonCode2, Out_Values.HelperList);
            Assert.Contains(resonCode3, Out_Values.HelperList);
        }

        [When(@"A request is placed to get active events of an asset (.*) with criticality (.*), assetId (.*), status (.*), rootNode (.*) during (.*) and (.*)")]
        public void WhenARequestIsPlacedToGetActiveEventsOfAnAssetDuringAnd(string assetName, int criticality, string assetId, string status, string rootNode, string fromDate, string toDate)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customer-id", Common.Inputs.API_urls.custId);
            Driver.GetEventsData(Environment_Values.EventMgmtServer + Environment_Values.GetEventDataEndPoint, Common.Inputs.API_urls.customer_Id, criticality, assetName, fromDate, toDate, status, assetId, rootNode);
            fsq.DeleteDataForEventDataAPI();
        }

        [Then(@"the Event API should retrieve the active event data created for the given asset (.*)")]
        public void ThenTheEventAPIShouldRetrieveTheActiveEventDataCreatedForTheGivenAsset(string assetName)
        {
            Assert.AreEqual((HttpStatusCode.OK).ToString(), Out_Values.ResponseCode);
            Out_Values.HelperList.Clear();
            foreach (var assetFaultData in Out_Values.ApiJsonOutput[0])
            {
                Out_Values.HelperList.Add((string)assetFaultData["assetName"]);
            }
            Assert.AreEqual(1, Out_Values.ApiJsonOutput[0].Count);
        }

    }
}
