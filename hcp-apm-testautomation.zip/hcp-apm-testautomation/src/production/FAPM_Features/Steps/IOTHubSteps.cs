﻿using System;
using System.Collections.Generic;
using System.Net;
using FAPM_Driver;
using FAPM_Driver.Share;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class IOTHubSteps
    {

        [Given(@"authorization is successfull")]
        public void GivenAuthorizationIsSuccessfull()
        {
          Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
            Console.WriteLine("Authorization Successfull");
        }
        
        [When(@"A request is placed to get the tag value for tags (.*)")]
        public void WhenARequestIsPlacedToGetTheTagValue(string tag)
        {
            List<string> tag_names = new List<string>();
            tag_names.Add(tag);
            string token = Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
            var res = Driver.Tag_Value(Common.Inputs.API_urls.iot_url, token, Common.Inputs.API_urls.tagvalue_url, Common.Inputs.API_urls.guid, tag_names);
            Assert.AreEqual(Driver._success, res);
        }

        [When(@"A request is placed to get the tag value for multiple tags (.*), (.*)")]
        public void WhenARequestIsPlacedToGetTheTagValueForMultipleTags(string tag1, string tag2)
        {
            List<string> tag_names = new List<string>();
            tag_names.Add(tag1);
            tag_names.Add(tag2);
            string token = Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
            var res = Driver.Tag_Value(Common.Inputs.API_urls.iot_url, token, Common.Inputs.API_urls.tagvalue_url, Common.Inputs.API_urls.guid, tag_names);
            Assert.AreEqual(Driver._success, res);
        }

        [Then(@"it should be successful")]
        public void ThenItShouldBeSuccessful()
        {
            var output = Out_Values.KPIApi_json[0];
           
            foreach (JProperty index in output) {

                if (output["ItemId"].ToString() == "man07")
                {
                    
                    string tagValue = output["Value"];
                    Console.WriteLine("+++++Value is" + tagValue);
                    Console.WriteLine("");
                }
            }
        }

        [When(@"A request is placed to get the tag list")]
        public void WhenARequestIsPlacedToGetTheTagList()
        {
            string token = Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
           var res =  Driver.Tag_List(Common.Inputs.API_urls.iot_url, token, Common.Inputs.API_urls.taglist_url, Common.Inputs.API_urls.guid);
            Assert.AreEqual(Driver._success, res);
        }

        [When(@"A request is placed to get the points history value for tag names(.*) startdate(.*) and enddate(.*)")]
        public void WhenARequestIsPlacedToGetThePointsHistoryValueForTagNamesStartdateAndEnddate(string tag, string startdate, string enddate)
        {
            List<string> tag_names = new List<string>();
            tag_names.Add(tag);
            string token = Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
            var res = Driver.Points_history(Common.Inputs.API_urls.iot_url, token, Common.Inputs.API_urls.pointshistory_url, Common.Inputs.API_urls.guid, startdate, enddate, tag_names);
            Assert.AreEqual(Driver._success, res);
        }

        [When(@"A request is placed to get the points history value for multiple tag names(.*), (.*) startdate(.*) and enddate(.*)")]
        public void WhenARequestIsPlacedToGetThePointsHistoryValueForMultipleTagNamesStartdateAndEnddate(string tag1, string tag2, string startdate, string enddate)
        {
            List<string> tag_names = new List<string>();
            tag_names.Add(tag1);
            tag_names.Add(tag2);
            string token = Driver.Authorization(Common.Inputs.API_urls.authenticationUrl, Common.Inputs.API_urls.clientId, Common.Inputs.API_urls.clientSecret);
            var res = Driver.Points_history(Common.Inputs.API_urls.iot_url, token, Common.Inputs.API_urls.pointshistory_url, Common.Inputs.API_urls.guid, startdate, enddate, tag_names);
            Assert.AreEqual(Driver._success, res);
        }

    }
}
