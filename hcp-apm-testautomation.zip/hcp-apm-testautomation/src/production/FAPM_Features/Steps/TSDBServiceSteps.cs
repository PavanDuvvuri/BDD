﻿using System;
using System.Collections.Generic;
using System.Net;
using FAPM_Driver;
using FAPM_Driver.Share;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class TSDBServiceSteps
    {
        [Given(@"the service is up and running")]
        public void GivenTheServiceIsUpAndRunning()
        {
            Console.WriteLine("Demo");
        }
        
        [When(@"a request is made with customer id (.*) to get the tag values for a tag name (.*) between start (.*) and end (.*)")]
        public void WhenARequestIsMadeWithCustomerIdToGetTheTagValuesForATagNameBetweenStartAndEnd(string cust_id, string tagname, string starttime, string endtime)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            List<string> tags = new List<string>();
            tags.Add(tagname);

            var status = Driver.Read_Tag_Data(Common.Inputs.API_urls.tsdb_server, Common.Inputs.API_urls.tagDataURL, tags, starttime, endtime, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }
        
        [Then(@"api should return the tag values for the tag (.*)")]
        public void ThenApiShouldReturnTheTagValuesForTheTag(string tagname)
        {
            Assert.AreEqual(Out_Values.ResponseCode, HttpStatusCode.OK.ToString());
            var tag_Value = Out_Values.KPIApi_json[tagname][1]["Value"].ToString();
            Console.WriteLine("Tag Value is = " + tag_Value);
        }

        [When(@"a request is made with customer id (.*) to get the tag values for a incorrect tag name (.*) between start (.*) and end (.*)")]
        public void WhenARequestIsMadeWithCustomerIdToGetTheTagValuesForAIncorrectTagNameBetweenStartAndEnd(string cust_id, string tagname, string starttime, string endtime)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            List<string> tags = new List<string>();
            tags.Add(tagname);
            var status = Driver.Read_Tag_Data(Common.Inputs.API_urls.tsdb_server, Common.Inputs.API_urls.tagDataURL, tags, starttime, endtime, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }
        [Then(@"api should return empty value for the tag (.*)")]
        public void ThenApiShouldReturnEmptyValueForTheTag(string tagname)
        {
            Assert.AreEqual(Out_Values.ResponseCode, HttpStatusCode.OK.ToString());
            Assert.AreEqual("{}", Out_Values.KPIApi_json.ToString());
        }

        [When(@"a request is made with customer id (.*) to get the tag values for multiple tags (.*), (.*) between start (.*) and end (.*)")]
        public void WhenARequestIsMadeWithCustomerIdToGetTheTagValuesForMultipleTagsBetweenStartAndEnd(string cust_id, string tagname1, string tagname2, string starttime, string endtime)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", cust_id);
            List<string> tags = new List<string>();
            tags.Add(tagname1);
            tags.Add(tagname2);

            var status = Driver.Read_Tag_Data(Common.Inputs.API_urls.tsdb_server, Common.Inputs.API_urls.tagDataURL, tags, starttime, endtime, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }
        [Then(@"api should return the tag values for both the tags (.*) and (.*)")]
        public void ThenApiShouldReturnTheTagValuesForBothTheTagsAnd(string tagname1, string tagname2)
        {
            Assert.AreEqual(Out_Values.ResponseCode, HttpStatusCode.OK.ToString());
            var tag1_Value = Out_Values.KPIApi_json[tagname1][1]["Value"].ToString();
            var tag2_Value = Out_Values.KPIApi_json[tagname2][1]["Value"].ToString();

            Console.WriteLine("Value for "+ tagname1+" is = " + tag1_Value);
            Console.WriteLine("Value for " + tagname2 + " is = " + tag2_Value);


        }

    }
}
