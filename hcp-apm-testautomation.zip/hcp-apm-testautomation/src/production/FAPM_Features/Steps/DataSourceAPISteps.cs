﻿using System;
using System.Collections.Generic;
using System.Net;
using FAPM_Driver;
using FAPM_Driver.Share;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace FAPM_Features.Steps
{
    [Binding]
    public class DataSourceAPISteps
    {
        [Given(@"a the api is up and running")]
        public void GivenATheApiIsUpAndRunning()
        {
            Console.WriteLine("demo");
        }

        [When(@"A request is placed with (.*) to get all the data sources")]
        public void WhenARequestIsPlacedWithToGetAllTheDataSources(string custid)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DatasourceAPI(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"api should retrieve all the existing data sources")]
        public void ThenApiShouldRetrieveAllTheExistingDataSources()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
            List<string> names = new List<string>();
            foreach(var c in Out_Values.KPIApi_json) 
            {
                names.Add(c["name"].ToString());
            }

            Assert.Contains("DCSimulation", names);

        }

        [Given(@"a data source data is newly inserted with (.*) for DataSource (.*)")]
        public void GivenADataSourceDataIsNewlyInsertedWithForDataSource(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        

        [Given(@"there is a data source with name (.*) and (.*)")]
        public void GivenThereIsADataSourceWithNameAnd(string dsname, string custid)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
           int status = Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*)  and name of the data source (.*) to get the data sources")]
        public void WhenARequestIsPlacedWithAndNameOfTheDataSourceToGetTheDataSources(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourceByName(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);
            Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);

        }

        [When(@"A request is placed with (.*) and invalid name (.*) to get  the details")]
        public void WhenARequestIsPlacedWithAndInvalidNameToGetTheDetails(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourceByName(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._failure, status);
        }

        [When(@"A request is placed with (.*) and multiple datasource names (.*), (.*) to get  the details")]
        public void WhenARequestIsPlacedWithAndMultipleDatasourceNamesToGetTheDetails(string custid, string dsname1, string dsname2)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourceByName(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname1+","+dsname2);
            Assert.AreEqual(Driver._failure, status);
        }

        [When(@"A request is placed with (.*) request body data to insert data for data source (.*)")]
        public void WhenARequestIsPlacedWithRequestBodyDataToInsertDataForDataSource(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }


        [Then(@"api should retrieve that particular (.*) data source data")]
        public void ThenApiShouldRetrieveThatParticularDataSourceData(string dsname)
        {
            Assert.AreEqual(Out_Values.KPIApi_json["name"].ToString(), dsname);
        }

        [Then(@"api should retrieve the error (.*)")]
        public void ThenApiShouldRetrieveTheError(string error)
        {
            Assert.AreEqual(error, Out_Values.KPIApi_json["reasonPhrase"].ToString());
        }

        [Then(@"the insertion should be successfull")]
        public void ThenTheInsertionShouldBeSuccessfull_()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [Then(@"api should retrieve the data source data (.*) which is inserted along with all other existing data sources\.""")]
        public void ThenApiShouldRetrieveTheDataSourceDataWhichIsInsertedAlongWithAllOtherExistingDataSources_(string dsname)
        {
            List<string> names = new List<string>();
            foreach (var c in Out_Values.KPIApi_json)
            {
                names.Add(c["name"].ToString());
            }

            Assert.Contains(dsname, names);
        }


        [When(@"A request is placed with (.*) to get the particular data sources (.*)")]
        public void WhenARequestIsPlacedWithToGetTheParticularDataSources(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourceByName(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);
            Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);

        }

        [Then(@"api should retrieve only the inserted data source (.*) data")]
        public void ThenApiShouldRetrieveOnlyTheInsertedDataSourceData(string dsname)
        {
            Assert.AreEqual(dsname, Out_Values.KPIApi_json["name"].ToString());
        }

        [When(@"A request is placed with (.*) request body data by excluding name field, to insert data in data source api")]
        public void WhenARequestIsPlacedWithRequestBodyDataByExcludingNameFieldToInsertDataInDataSourceApi(string custid)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, "", Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._failure, status);
        }

        [Then(@"api should throw appropriate error (.*)")]
        public void ThenApiShouldThrowAppropriateError(string error)
        {
            Assert.AreEqual(error, Out_Values.KPIApi_json["errors"]["Name"][0].ToString());
        }

        
        [Given(@"the data is existing for a data source (.*) with (.*)")]
        public void GivenTheDataIsExistingForADataSource_(string dsname, string custid)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            Assert.AreEqual(Driver._success, status);
        }


        [When(@"A request is placed with (.*) to update the data source (.*) with Updated desc (.*) in data source api")]
        public void WhenARequestIsPlacedWithToUpdateDataSourceWithUpdatedNameAndDescInDataSourceApi(string custid, string dsname, string desc)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            Dictionary<string, string> updated_values = new Dictionary<string, string>();
            updated_values.Add("name", dsname);
            updated_values.Add("description", desc);
            int status = Driver.DataSourceUpdate(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, updated_values);
            Assert.AreEqual(Driver._success, status);
        }


        [Then(@"the update should be successfull")]
        public void ThenTheUpdateShouldBeSuccessfull()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [Given(@"a data source (.*) with (.*) is updated with few details like (.*)")]
        public void GivenADataSourceWithIsUpdatedWithFewDetailsLike(string dsname, string custid, string desc)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            Assert.AreEqual(Driver._success, Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id));
            Dictionary<string, string> updated_values = new Dictionary<string, string>();
            updated_values.Add("name", dsname);
            updated_values.Add("description", desc);
            int status = Driver.DataSourceUpdate(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, updated_values);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"api should retrieve the data source (.*) data with updated desc (.*)")]
        public void ThenApiShouldRetrieveTheDataSourceDataWithUpdatedDesc(string dsname, string desc)
        {
            Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            List<string> desc_all = new List<string>();
            foreach (var c in Out_Values.KPIApi_json)
            {
                desc_all.Add(c["description"].ToString());
            }

            Assert.Contains(desc, desc_all);
        }


        [When(@"A request is placed with (.*) to get the particular data source with updated values")]
        public void WhenARequestIsPlacedWithToGetTheParticularDataSourceWithUpdatedValues(string p0)
        {
            Console.WriteLine("demo");
        }

        [Then(@"api should retrieve the data source data with updated values (.*)")]
        public void ThenApiShouldRetrieveTheDataSourceDataWithUpdatedValues(string desc)
        {
            Assert.AreEqual(desc, Out_Values.KPIApi_json["description"].ToString());
        }

        [When(@"A request is placed with (.*) updated request body data with invalid data source name (.*)")]
        public void WhenARequestIsPlacedWithUpdatedRequestBodyDataWithInvalidDataSourceName(string custid, string dsname)
        {
            Dictionary<string, string> updated_values = new Dictionary<string, string>();
            updated_values.Add("name", dsname);
            updated_values.Add("description", "");
            int status = Driver.DataSourceUpdate(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, updated_values);
            Assert.AreEqual(Driver._failure, status);
        }



        [Then(@"the api should throw error (.*)")]
        public void ThenTheApiShouldThrowError(string p0)
        {
            Console.WriteLine("demo");
        }

        [Given(@"a data source with (.*) and data source name (.*) is deleted")]
        public void GivenADataSourceWithAndDataSourceNameIsDeleted(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            int status = Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);
        }


        [When(@"A request is placed with (.*) , data source name (.*) to delete the data")]
        public void WhenARequestIsPlacedWithDataSourceNameToDeleteTheData(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            Driver.DataSourcePost(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, dsname, Common.Inputs.API_urls.customer_Id);
            int status = Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);
        }

        [When(@"A request is placed with (.*) to delete datasource data with non existing datasource name (.*)")]
        public void WhenARequestIsPlacedWithToDeleteDatasourceDataWithNonExistingDatasourceName(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.DataSourceDelete(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._failure, status);
        }


        [Then(@"api should not retrieve the (.*) data which is deleted\.")]
        public void ThenApiShouldNotRetrieveTheDataWhichIsDeleted_(string dsname)
        {
            List<string> names = new List<string>();
            foreach (var c in Out_Values.KPIApi_json)
            {
                names.Add(c["name"].ToString());
            }
                Assert.IsFalse(names.Contains(dsname));
        }

        [Then(@"the delete should be successfull")]
        public void ThenTheDeleteShouldBeSuccessfull()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed with (.*) to get the IOT health tags data for a particular data source (.*)")]
        public void WhenARequestIsPlacedWithToGetTheIOTHealthTagsDataForAParticularDataSource(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
           int status =  Driver.healthtags_iot(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);

        }

        [Then(@"api should retrieve all the IOT health tags related to that data source")]
        public void ThenApiShouldRetrieveAllTheIOTHealthTagsRelatedToThatDataSource()
        {
            Assert.AreEqual(HttpStatusCode.OK.ToString(), Out_Values.ResponseCode);
        }

        [When(@"A request is placed with (.*) to get the Engine health tags data for a particular data source (.*)")]
        public void WhenARequestIsPlacedWithToGetTheEngineHealthTagsDataForAParticularDataSource(string custid, string dsname)
        {
            Common.Inputs.API_urls.customer_Id.Clear();
            Common.Inputs.API_urls.customer_Id.Add("customerId", custid);
            int status = Driver.healthtags_engine(Common.Inputs.API_urls.dsServer, Common.Inputs.API_urls.dsURL, Common.Inputs.API_urls.customer_Id, dsname);
            Assert.AreEqual(Driver._success, status);
        }

        [Then(@"api should retrieve all the Engine health tags related to that data source")]
        public void ThenApiShouldRetrieveAllTheEngineHealthTagsRelatedToThatDataSource()
        {
            ScenarioContext.Current.Pending();
        }


    }
}
