﻿using System.Reflection;
using System.Runtime.InteropServices;
using NUnit.Framework;

[assembly: AssemblyDescription("")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
//[assembly: Parallelizable(ParallelScope.Fixtures)]
//[assembly: CollectionBehavior(DisableTestParallelization = true)]
[assembly: ComVisible(false)]

[assembly: Guid("2365416c-eec3-4d56-a49f-f172bd1ba694")]