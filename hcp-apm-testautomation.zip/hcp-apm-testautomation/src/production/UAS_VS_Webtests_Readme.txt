To run the UAS VS web tests, the following setups are needed.
1. The machine running the VS web tests needs to have MSTest installed (i.e. from Visual Studio 2015)
2. Test.WebServer1 environment variable needs to be defined for the UAS web server URL, i.e. http://UASAuto03
3. Set Test.WebServer1 http://UASAuto03 needs to be run to set up the context parameter if the tests are run through command line
4. If new web test files need to be added to the test run, RunTests.bat in the web test solution folder at E:\UASWebTests needs to be modified with the new MSTest parameter i.e. /TestContainer:E:\UASWebTests\EventManagement\{newTestName}.webtest

Some test development tips:
1. To use Think time (seconds), need to add a web test setting file and check "Simulate think times" checkbox in the web test configuration page. It's been done and saved in Local.testsettings in the solution folder.
2. To extract a string from the response, such as token, create a extraction rule and the extracted string can be saved to an variable to be used for a later web request.
3. To validate the response, such as a symptom status, create a validation rule and use search rule i.e. regular expression, start with and end, etc.
4. QueryString Parameters->connectionToken->URL Encode needs to be "True" when a extracted token is used
5. The whole webtest file will be reported as one test. If a new test is expected in the report, a new webtest file needs to be created.
6. Context parameter can be used to pass in web server URL prefix. The syntax to use the context paramter is: {{WebServer1}}/MES/AM/SentinelWebUI/api/AttributeViewerApi/SaveAttributeValues
7. To use the web recording feature, you need to enable web recorder 14.0 in IE add-in manager.