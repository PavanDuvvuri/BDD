﻿Get-Date
$PSVersionTable
Write-Host "Hello, World!"