﻿using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace AutomationFramework
{
    public class Rest
    {

        
        public static (HttpStatusCode, string) Get_Restclient_With_Params(string api, string token, string header, Dictionary<string, string> id, Dictionary<string, string> queryparams)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.GET);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddHeader("Content-Type", "application/json");
            foreach (KeyValuePair<string, string> entry in id)
            {
                restRequest.AddHeader(entry.Key, entry.Value);
            }
            foreach (KeyValuePair<string, string> entry in queryparams)
            {
                restRequest.AddQueryParameter(entry.Key, entry.Value);
            }
             IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }
        public static (HttpStatusCode, string) Post_Restclient_With_Params(string api, string token, string header, Dictionary<string, string> headers, Dictionary<string, string> param, string body_data)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.POST);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
           if (body_data!= null)
            {
                restRequest.AddParameter("application/json", body_data, ParameterType.RequestBody);
            }
            foreach (KeyValuePair<string, string> entry in param)
            {
                restRequest.AddParameter(entry.Key, entry.Value);
            }
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Post_Restclient_UploadFile(string api, string filepath, string token, string header, Dictionary<string, string> id)
        {

            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.POST);
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddFile("TargetsFile", filepath);
            //restRequest.AddFile("TargetsFile", @"C:/Users/neha/Downloads/TargetsImport/ImportTargetTemplateWithSampleData.xlsx");
            restRequest.AddHeader("accept", "*/*");
            restRequest.AddHeader("Content-Type", "multipart/form-data");
            foreach (KeyValuePair<string, string> entry in id)
            {
                restRequest.AddHeader(entry.Key, entry.Value);
            }
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Post_Restclient_TokenGenerator(string api)
        {

            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.POST);
            restRequest.AddHeader("accept", "application/json");
            restRequest.AddParameter("grant_type", "client_credentials");
            restRequest.AddParameter("resource", "https://honidentitydev.onmicrosoft.com/aist-hbsportalapi-ase/");
            restRequest.AddParameter("client_id", "af75bb24-4e00-4e22-b129-36ef4a5fc7fd");
            restRequest.AddParameter("client_secret", "1.QznzMwH79eMWSYLBLDO-_p-7~fdVFs7f");
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Post_Restclient(string api, string data, string token, string header, Dictionary<string, string> id)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.POST);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restRequest.AddJsonBody(data);
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddHeader("Content-Type", "application/json");
            foreach (KeyValuePair<string, string> entry in id)
            {
                restRequest.AddHeader(entry.Key, entry.Value);
            }
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Get_Restclient(string api, string token, string header, Dictionary<string, string> id)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.GET);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddHeader("Content-Type", "application/json");
            foreach (KeyValuePair<string, string> entry in id)
            {
                restRequest.AddHeader(entry.Key, entry.Value);
            }
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Put_Restclient(string api, string data, string token, string header, Dictionary<string, string> id)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.PUT);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restRequest.AddJsonBody(data);
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddHeader("Content-Type", "application/json");
            restRequest.AddHeader("customerId", id["customerId"]);
            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }

        public static (HttpStatusCode, string) Delete_Restclient(string api, string token, string header, Dictionary<string, string> id)
        {
            RestClient restClient = new RestClient(api);
            RestRequest restRequest = new RestRequest(api, Method.DELETE);
            restClient.Authenticator = new NtlmAuthenticator("Level3" + @"\installer", "Password1");
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            if (token != "") { restRequest.AddHeader(header, token); }
            restRequest.AddHeader("Content-Type", "application/json");
            restRequest.AddHeader("customerId", id["customerId"]);

            IRestResponse restResponse = restClient.Execute(restRequest);
            string response = restResponse.Content;
            HttpStatusCode responsecode = restResponse.StatusCode;
            return (responsecode, response);
        }
        public static string Ping_IP(string ip)
        {
            Ping ping = new Ping();
            PingReply pingresult = ping.Send(ip);
            string respone = pingresult.Status.ToString();
            return respone;
        }

        public static string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }

        public static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public static DateTime RandomDate(int duration, int days)
        {
            Random gen = new Random();
            // int range = days;
            var t = gen.Next(days);
            if (t == 0) { t += 1; }
            DateTime randomDate = DateTime.UtcNow;
            if (duration == 1)
            {
                randomDate = DateTime.UtcNow.AddDays(-t);
            }
            else if (duration == -1)
            {
                t = gen.Next(20);
                randomDate = DateTime.UtcNow.AddDays(-days).AddDays(-t);
            }
            else if (duration == -6)
            {
                t = gen.Next(120);
                randomDate = DateTime.UtcNow.AddMonths(-3).AddDays(-t);
            }
            return randomDate;
        }

        public static string NTML_Auth(string _baseURL, string userid, string pwd)
        {
            RestClient restClient = new RestClient();
            var uid = userid;
            restClient.BaseUrl = new Uri(_baseURL);
            restClient.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;
            RestRequest restRequest = new RestRequest(Method.GET);
            restRequest.AddHeader("Accept-Language", "en-US,en;q=0.9");
            restClient.Authenticator = new NtlmAuthenticator(uid, pwd);
            IRestResponse restResponse = restClient.Execute(restRequest);
            var temp = restResponse.Content.Split("=");

            for (int i = 0; i < temp.Count() - 1; i++)
            {
                if (temp[i].Contains("cm-token"))
                {
                    return temp[i + 1].Split("/")[0].Replace('"', ' ').Trim();
                }
            }
            return "";
        }

    }
}
