﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Protractor;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System.IO;
using System.Collections;
using AutomationFramework.PageElements;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Firefox;
//using AutoItX3Lib;


//using iTextSharp.text.pdf;
//using iTextSharp.text.pdf.parser;
//using PdfSharp.Pdf.IO;

namespace AutomationFramework
{
    public class UI_Driver
    {
        public const int _success = 9;
        public const int _failure = 7;
        public const int _process_err = 3;
        public const int _exception = -1;
        public static NgWebDriver ng_driver;
        public static string browser = ConfigurationManager.AppSettings["browserName"];
        public static IWebDriver driver;
        private static int longWait = 120;
        private static int mediumWait = 60;
        private static int shortWait = 30;
        public static string reportPath;
        public static string screenshotpath;

        #region Common Browser Setup
        public static string GetScreenshot(string fileName)
        {
            Console.WriteLine("inside screenshot");
            ITakesScreenshot ts = (ITakesScreenshot)UI_Driver.driver;
            Screenshot screenshot = ts.GetScreenshot();
            Directory.CreateDirectory(reportPath + @"Screenshots");
            string finalpth = reportPath + @"Screenshots/" + fileName + ".png";
            screenshot.SaveAsFile(finalpth, ScreenshotImageFormat.Png);
            return finalpth;
        }
        public static IWebDriver Setup()
        {
            //local setup//
            //ChromeOptions options = new ChromeOptions();
            //options.AddArguments("ignore-certificate-errors");
            //options.AddAdditionalCapability("useAutomationExtension", false);
            //string fileDownloadPath = Directory.GetCurrentDirectory().Split("FAPM_Features")[0] + "File_Downloads";
            //if (!Directory.Exists(fileDownloadPath))
            //{
            //    Directory.CreateDirectory(fileDownloadPath);
            //}
            //options.AddUserProfilePreference("download.default_directory", fileDownloadPath + "//");
            //driver = new ChromeDriver(@"../../../../AutomationFramework/Driver/Chrome", options, TimeSpan.FromMinutes(3));
            //driver.Manage().Window.Maximize();

            //container setup
            ChromeOptions options = new ChromeOptions();
            options.AddArguments(new List<string>()
            {
                "--silent-launch",
                "--no-startup-window",
                "no-sandbox",
                "headless",
                "--window-size=1366,768"
                });
            driver = new ChromeDriver("/opt/chrome", options, TimeSpan.FromMinutes(3));
            Console.WriteLine("Chrome launch triggered");
            return driver;

            //Healenium

            //var options = new FirefoxOptions();
            //driver = new RemoteWebDriver(new Uri("http://localhost:8085"), options);
            //return driver;
        }

        public static void LaunchBrowser(string browserName)
        {
            switch (browserName)
            {
                case "Chrome":
                    driver = UI_Driver.Setup();
                    break;

                case "IE":
                    if (driver == null)
                    {
                        var ieOptions = new InternetExplorerOptions { RequireWindowFocus = true, EnablePersistentHover = false, EnableNativeEvents = true, BrowserCommandLineArguments = "-private", EnsureCleanSession = true, IgnoreZoomLevel = true, IntroduceInstabilityByIgnoringProtectedModeSettings = true, PageLoadStrategy = PageLoadStrategy.Normal, UnhandledPromptBehavior = UnhandledPromptBehavior.Dismiss };
                        // ieOptions.addCommandSwitches("-private");
                        string str = Environment.CurrentDirectory;
                        driver = new InternetExplorerDriver((@"../../../../AutomationFramework/Driver/IE"), ieOptions);
                        driver.Manage().Timeouts().PageLoad.Add(System.TimeSpan.FromSeconds(30));
                        driver.Manage().Window.Maximize();
                    }
                    break;
            }
        }

        #endregion Common Setup

        #region Refresh
        public static void refreshMethod()
        {
            driver.Navigate().Refresh();
            UI_Driver.Wait(5000);
        }

        #endregion

        #region Enter Value
        public static void EnterURL(string URL)
        {
            Console.WriteLine("Entering URL");
            driver.Navigate().GoToUrl(URL);
        }
        public static void EnterText(string inputValue, By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                WaitForPageLoad(driver, mediumWait);
                Assert.IsTrue(element.Displayed);
                element.Clear();
                element.SendKeys(inputValue);
            }
            catch (Exception ex)
            {
            screenshotpath = GetScreenshot("EnterText" + DateTime.Now.ToString("yyyyMMddHHmmss"));
               
            }
        }
        public static void EnterTextwithoutClear(string inputValue, By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            WaitForPageLoad(driver, mediumWait);
            //Assert.IsTrue(element.Displayed);
            element.SendKeys(inputValue);
        }

        public static void EnterTextUsingJS(string text, By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            element.Clear();
            IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
            jse.ExecuteScript("arguments[0].scrollIntoView()", element);
            jse.ExecuteScript("arguments[0].setAttribute('value', arguments[1])", element, text);
        }
        public static void EnterTextByChar(string text, By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            element.Clear();
            for (int i = 0; i < text.Length; i++)
            {
                string c = text[i].ToString();
                element.SendKeys(c);
            }
        }

        #endregion Enter Value

        #region Simulation
        // Function to perform Tab action
        public static void TabSimulate(int i)
        {
            for (int j = 1; j <= i; j++)
            {
                Actions actions = new Actions(driver);
                actions.SendKeys(Keys.Tab).Perform();
            }
        }

        // Function to perform arrowup key
        public static void ArrowUpSimulate(int i)
        {
            for (int j = 1; j <= i; j++)
            {
                Actions actions = new Actions(driver);
                actions.SendKeys(Keys.ArrowUp).Perform();
            }
        }

        // Function to perform Enter action
        public static void EnterSimulate(int i)
        {
            for (int j = 1; j <= i; j++)
            {
                Actions actions = new Actions(driver);
                actions.SendKeys(Keys.Enter).Perform();
            }
        }

        // Function to perform arrowdown key
        public static void ArrowDownSimulate(int i)
        {
            for (int j = 1; j <= i; j++)
            {
                Actions actions = new Actions(driver);
                actions.SendKeys(Keys.ArrowDown).Perform();
            }
        }
        #endregion Simulation

        #region Scroll Action
        public static void ScrollClick(int i, int count)
        {
            if (count > 8)
            {
                Wait(1000);
                for (int j = 1; j <= i; j++)
                {
                    Click(By.XPath("//*[@id='mCSB_2']/div[2]/a[2]"));
                }
            }
        }

        public static void ScrollBottom()
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("window.scrollBy(0,document.body.scrollHeight)");
        }

        public static void ScrollToElemenWithJavaScript(By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].scrollIntoView();", element);
        }

        public static void PageScrollDown(By locatorElement)
        {
            var element = driver.FindElement(locatorElement);
            Actions actions = new Actions(driver);
            actions.MoveToElement(element);
            actions.Perform();
        }
        public static void ScrollToElementUsingJavaScript(By locatorElement)
        {
            WaitForPageLoad(driver, 500);
            IWebElement element = driver.FindElement(locatorElement);
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("arguments[0].scrollIntoView(true);", element);
        }

        #endregion Scroll Action

        #region UI Action
        public static void Click(By locatorElement)
        {
            try { 
            WaitForPageLoad(driver, 120);
            WaitUntilElementExists(locatorElement, 60);
            IWebElement element = driver.FindElement(locatorElement);
            WaitUntilElementClickable(locatorElement, 60);
            Assert.IsTrue(element.Displayed);
            element.Click();
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || Click: Exception {0} ", ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("Click " + DateTime.Now.ToString("yyyyMMddHHmmss"));
            }
        }
        public static void ClickForMultipleElement(string assetname)
        {
            try {
            WaitForPageLoad(driver, 120);
            driver.FindElement(By.XPath("//*[@class='visible menu transition']/div[text()='" + assetname + "']")).Click();
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || ClickForMultipleElement: Exception {0} ", ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("ClickForMultipleElement " + DateTime.Now.ToString("yyyyMMddHHmmss"));
            }
        }

        public static IWebElement selectDuration(String duration)
        {
            WaitForPageLoad(driver, longWait);
            WaitUntilElementExists(By.XPath("//*[contains(@class,'date ') and contains(text(), '" + duration + "')]"), shortWait);
            IWebElement durationSelction = driver.FindElement(By.XPath("//*[contains(@class,'date ') and contains(text(), '" + duration + "')]"));
            return durationSelction;
        }

        public static IWebElement selectDurationUnderAssetDetails(String duration)
        {
            
                WaitForPageLoad(driver, longWait);
                WaitUntilElementExists(By.XPath("//*[contains(@class,'item') and contains(text(), '" + duration + "')]"), shortWait);
                IWebElement durationSelction = driver.FindElement(By.XPath("//*[contains(@class,'item') and contains(text(), '" + duration + "')]"));
                return durationSelction;
            
    
        }

        public static IWebElement assetDetailsRedirectLink(String assetDisplayName)
        {
            WaitForPageLoad(driver, longWait);
            IWebElement assetDisplayNameLink = driver.FindElement(By.XPath("//span[@class='redirect-link' and contains(text(),'" + assetDisplayName + "')]"));
            return assetDisplayNameLink;
        }

        public static IWebElement selectAsset(String assetName)
        {
            WaitForPageLoad(driver, longWait);
            WaitUntilElementExists(By.XPath("//*[@class='title' and contains(text(),'" + assetName + "')]/parent::div/div[@root='common']"), shortWait);
            IWebElement assetSelction = driver.FindElement(By.XPath("//*[@class='title' and contains(text(),'" + assetName + "')]/parent::div/div[@root='common']"));
            return assetSelction;
        }

        public static IWebElement expandAssetSelection(String assetName)
        {
            WaitForPageLoad(driver, longWait);
            WaitUntilElementExists(By.XPath("//span[text()='" + assetName + "']/parent::div/span/i"), shortWait);
            IWebElement expandAssetSelction = driver.FindElement(By.XPath("//span[text()='" + assetName + "']/parent::div/span/i"));
            return expandAssetSelction;
        }

        public static int TotalCount(By locator)
        {
            int count = driver.FindElements(locator).Count();
            return count;
        }

        public static void ClickUsingJavaScript(By locatorElement)
        {
            try
            {
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                IWebElement elementToClick = driver.FindElement(locatorElement);
                js.ExecuteScript("arguments[0].scrollIntoView()", elementToClick);
                js.ExecuteScript("arguments[0].click();", elementToClick);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }




        public static void CheckBoxOrRadioButtonIsSelected(By locatorElement)
        {
            try
            {
                WaitForPageLoad(driver, mediumWait);
                IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
                foreach (IWebElement element in elements)
                {
                    element.Click();
                    //Assert.True(element.Selected);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                screenshotpath = GetScreenshot("CheckBoxorRadioButtonIsSelected" + DateTime.Now.ToString("yyyyMMddHHmmss"));
            }
        }

        public static IList<string> GetText(By locatorElement)
        {
            string actualText;
            IList<string> list = new List<string>();
            try
            {
                WaitForPageLoad(driver, mediumWait);
                IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
                foreach (IWebElement element in elements)
                {
                    actualText = element.Text;
                    list.Add(actualText);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                screenshotpath = GetScreenshot("GetText" + DateTime.Now.ToString("yyyyMMddHHmmss"));
            }
            return list;


        }


        public static string GetElementAttribute(string attributeType, By locator)
        {
            IWebElement locatorElement = driver.FindElement(locator);
            string attributeValue = locatorElement.GetAttribute(attributeType);
            return attributeValue;
        }

        public static void Select_Checkbox(By locator)
        {
            UI_Driver.Wait(200);
            if (!UI_Driver.ElementIsselected(locator))
            {
                UI_Driver.Click(locator);
            }
        }

        public static void Deselect_Checkbox(By locator)
        {
            UI_Driver.Wait(200);
            if (UI_Driver.ElementIsselected(locator))
            {
                UI_Driver.Click(locator);
            }
        }

        public static bool ElementIsselected(By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                if (element.Selected)
                {
                    return true;
                }
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.Message);
            }
            return false;
        }
        public static void ElementIsDisable(By locatorElement)
        {
            try
            {
                WaitForPageLoad(driver, mediumWait);
                IWebElement element = driver.FindElement(locatorElement);
                Assert.IsFalse(element.Enabled);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void ElementIsEnable(By locatorElement)
        {
            try
            {
                WaitForPageLoad(driver, mediumWait);
                IWebElement element = driver.FindElement(locatorElement);
                Assert.True(element.Enabled);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void ElementIsDisplayed(By locatorElement)
        {
            try
            {
                WaitForPageLoad(driver, mediumWait);
                IWebElement element = driver.FindElement(locatorElement);
                Assert.IsTrue(element.Displayed);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static bool ElementIsNotDisplayed(By locatorElement)
        {
            try
            {
                WaitForPageLoad(driver, mediumWait);
                driver.FindElement(locatorElement);
                return false;
            }
            catch (NoSuchElementException)
            {
                return true;
            }
        }
        public static bool ElementIsExists(By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                if (element.Displayed)
                {
                    return true;
                }
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
            return false;
        }
        public static bool AttributeIsDisplayed(By elementLocator, string attribute, string attributevalue)
        {
            try
            {
                string str = UI_Driver.GetElementAttribute(attribute, elementLocator);
                if (str == attributevalue) { return false; }
                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

        public static int Combo_Select_Item(string list_ref, string item_ref, string click_ref, string element)
        {
            var combo = driver.FindElement(By.XPath(list_ref));
            combo.FindElement(By.ClassName(click_ref)).Click();
            var combo_items = combo.FindElements(By.ClassName(item_ref));

            for (int j = 0; j < combo_items.Count; j++)
            {

                if (combo_items[j].Text.Contains(element.TrimStart()))
                {
                    combo_items[j].Click(); return _success;
                }
            }

            return _failure;
        }

        public static int Clk_Btn(string Btn_ref, string element)
        {
            var load_next = driver.FindElement(By.ClassName(Btn_ref));
            if (load_next.Text.Contains(element)) { load_next.Click(); return _success; }
            return _failure;
        }



        #endregion UI Action

        #region Action Class
        public static void DragAndDropbyOffset(By sourceLocator, int offset_x, int offset_y)
        {
            try
            {
                IWebElement sourceElement = driver.FindElement(sourceLocator);
                WaitforElementToBeClick(driver, sourceLocator);
                var builder = new Actions(driver);
                var dragAndDrop = builder.DragAndDropToOffset(sourceElement, offset_x, offset_y);
                UI_Driver.Wait(3000);
                dragAndDrop.Build().Perform();
                UI_Driver.Wait(5000);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DragAndDrop(By sourceLocator, By targetLocator)
        {
            try
            {
                IWebElement sourceElement = driver.FindElement(sourceLocator);
                IWebElement targetElement = driver.FindElement(targetLocator);
                WaitforElementToBeClick(driver, sourceLocator);
                WaitforElementToBeClick(driver, targetLocator);

                //Method1
                var builder = new Actions(driver);
                var dragAndDrop = builder.DragAndDrop(sourceElement, targetElement);
                UI_Driver.Wait(500);
                dragAndDrop.Build().Perform();


                //Method2
                /*Actions actionProvider = new Actions(driver);
                actionProvider.ClickAndHold(sourceElement).MoveToElement(targetElement).Build().Perform();
                actionProvider.Release().Build().Perform();
                UI_Driver.Click(targetLocator);*/

                //Method3
                /*((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView();", sourceElement);
                Thread.Sleep(500);
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView();", targetElement);
                Thread.Sleep(200);
                IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
                js.ExecuteScript(js + "$('#" + sourceElement + "').simulateDragDrop({ dropTarget: '#" + targetElement + "'});");*/

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DragAndDropUI(By sourceLocator, By targetLocator)
        {
            try
            {
                IWebElement sourceElement = driver.FindElement(sourceLocator);
                IWebElement targetElement = driver.FindElement(targetLocator);
                WaitforElementToBeClick(driver, sourceLocator);
                WaitforElementToBeClick(driver, targetLocator);

                String java_script = "var src=arguments[0],tgt=arguments[1];var dataTransfer={dropEffe" +
                "ct:'',effectAllowed:'all',files:[],items:{},types:[],setData:fun" +
                "ction(format,data){this.items[format]=data;this.types.append(for" +
                "mat);},getData:function(format){return this.items[format];},clea" +
                "rData:function(format){}};var emit=function(event,target){var ev" +
                "t=document.createEvent('Event');evt.initEvent(event,true,false);" +
                "evt.dataTransfer=dataTransfer;target.dispatchEvent(evt);};emit('" +
                "dragstart',src);emit('dragenter',tgt);emit('dragover',tgt);emit(" +
                "'drop',tgt);emit('dragend',src);";
                ((IJavaScriptExecutor)driver).ExecuteScript(java_script, sourceElement, targetElement);
                Thread.Sleep(2000);
                Click(sourceLocator);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void MouseHover(By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            WaitforElementToBeClick(driver, locatorElement);
            Assert.IsTrue(element.Displayed);
            Actions action = new Actions(driver);
            action.MoveToElement(element).Build().Perform();
        }

        public static void RightClick(By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            WaitforElementToBeClick(driver, locatorElement);
            Assert.IsTrue(element.Displayed);
            Actions action = new Actions(driver);
            action.ContextClick(element).Build().Perform();
        }

        // Function to doubleclick and enter the text
        public static void DoubleclickAndEnterText(By locatorElement, By textlocator, string inputtext)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                WaitforElementToBeClick(driver, locatorElement);
                var builder = new Actions(driver);
                IWebElement element1 = driver.FindElement(textlocator);
                builder.DoubleClick(element).KeyDown(Keys.Control).SendKeys("a").KeyUp(Keys.Control).SendKeys(Keys.Delete).SendKeys(element1, inputtext).Build().Perform();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public static void ClickAndEnterText(By locatorElement, By textlocator, string inputtext)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                WaitforElementToBeClick(driver, locatorElement);
                var builder = new Actions(driver);
                builder.Click(element).Build().Perform();
                IWebElement element1 = driver.FindElement(textlocator);
                builder.KeyDown(Keys.Control).SendKeys("a").KeyUp(Keys.Control).SendKeys(Keys.Delete).SendKeys(element1, inputtext).Build().Perform();
            }
            catch (Exception)
            {
                throw;
            }
        }


        #endregion Action

        #region Verification
        public static void VerifyURL(string expectedURL)
        {
            var actualURL = driver.Url;
            if (!actualURL.Contains(expectedURL))
            {
                Assert.Fail("URL verification failed");
            }
        }

        // Function to verify text
        public static void VerifyText(string expectedText, By locatorElement)
        {
            try
            {
                WaitUntilElementExists(locatorElement, 60);
                IWebElement element = driver.FindElement(locatorElement);
                string actualText = element.Text;
                Assert.AreEqual(expectedText, actualText, $"The expected string: '{expectedText}' is not matched with actual string: '{actualText}'");
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyText" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        // Function to verify text using element attribute value
        public static void VerifyTextwithAttribute(string expectedText, By locatorElement, string attributeValue)
        {
            try
            {
                string actualText = GetElementAttribute(attributeValue, locatorElement);
                Assert.AreEqual(true, actualText.Contains(expectedText), $"The expected string: '{expectedText}' is not matched with actual string: '{actualText}'");
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyTextwithAttribute" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        // Function to verify two integer number
        public static bool verifyTwoIntNumber(int n1, int n2)
        {

            bool n = n1 == n2 ? true : false;
            if (!n)
            {
                Assert.AreEqual(true, n1.Equals(n2), $"The expected string: '{n1}' is not matched with actual string: '{n2}'");
            }
            return n;
        }

        public static void VerifyTextwithAttribute(By locatorElement, By locatorElementExpected, string attributeValue)
        {
            try
            {
                string expectedprecision = driver.FindElement(locatorElementExpected).Text;
                string actualDescription_IsContainsExpectedPrecision = GetElementAttribute(attributeValue, locatorElement);
                Assert.IsTrue(actualDescription_IsContainsExpectedPrecision.Contains(expectedprecision), $"The expected string: '{expectedprecision}' is not matched with actual string: '{actualDescription_IsContainsExpectedPrecision}'");
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyTextwithAttribute" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        public static void VerifyTimeWithAttribute(By locatorElement, string attributeValue)
        {
            try
            {
                //1st way
                string time = DateTime.Now.ToString("hh:mm tt");

                //2nd way
                string zoneId = "India Standard Time";
                TimeZoneInfo tzi = TimeZoneInfo.FindSystemTimeZoneById(zoneId);
                DateTime result = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tzi);
                DateTime cu = result.ToUniversalTime();
                string TimeOn_System = cu.ToLocalTime().ToString("hh : mm tt");

                string TimeOn_UI = GetElementAttribute(attributeValue, locatorElement);
                Assert.IsTrue(TimeOn_UI.Contains(TimeOn_System), $"The expected string: '{TimeOn_System}' is not exactly matching with actual string: '{TimeOn_UI}'");
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyTimeWithAttribute" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        public static void VerifyToolTipByAttribute(string expectedToolTipText, string attributeValue, By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                string actualTooltipTxt = element.GetAttribute(attributeValue);
                Assert.AreEqual(expectedToolTipText, actualTooltipTxt);
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyToolTipByAttribute"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        public static void VerifyToolTipText(string expectedToolTipText, By locatorElement1ToClickOnText, By locatorElement2ForTooltipCapture)
        {
            try
            {
                IWebElement element1 = driver.FindElement(locatorElement1ToClickOnText);
                Actions action = new Actions(driver);
                action.ClickAndHold(element1).Build().Perform();
                Thread.Sleep(3000);
                IWebElement element2 = driver.FindElement(locatorElement2ForTooltipCapture);
                string actualTooltipTxt = element2.Text;
                Assert.IsTrue(expectedToolTipText.Equals(actualTooltipTxt), $"The expected string: '{expectedToolTipText}' is not matched with actual string: '{actualTooltipTxt}'");
                //Assert.AreEqual(expectedToolTipText, actualTooltipTxt);
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("VerifyToolTipText" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }

        }

        public static void ToolTipTextForMultipleElement(By locatorElement, string tooltip1 = null, string tooltip2 = null, string tooltip3 = null)
        {
            IList<string> listOfToolTip = new List<string>() { tooltip1, tooltip2, tooltip3 };
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
            try
            {
                foreach (IWebElement element in elements)
                {
                    Actions action = new Actions(driver);
                    action.ClickAndHold(element).Build().Perform();
                    Thread.Sleep(1000);
                    string tooltip = element.Text;
                    Assert.IsTrue(listOfToolTip.Contains(tooltip));
                }
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("ToolTipTextForMultipleElement"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }

        }

        #endregion Verification

        #region Wait
        public static void ClickAndWaitForPageToLoad(By elementLocator, int timeout = 10)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                var element = driver.FindElement(elementLocator);
                element.Click();
                wait.Until(ExpectedConditions.StalenessOf(element));
            }
            catch (NoSuchElementException)
            {
                screenshotpath = UI_Driver.GetScreenshot("ClickAndWaitForPageToLoad"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine("Element with locator: '" + elementLocator + "' was not found in current context page.");
                throw;
            }
        }

        public static IWebElement WaitUntilElementExisting(By elementLocator, int timeout)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                return wait.Until(ExpectedConditions.ElementExists(elementLocator));
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("Element with locator: '" + elementLocator + "' was not found in current context page.");
                //logger.Error("Driver_UI || WaitUntilElementExisting: Exception {0} ", ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("WaitUntilElementExisting " + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw;
            }
        }

        public static IWebElement WaitUntilElementExists(By elementLocator, int timeout)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                return wait.Until(ExpectedConditions.ElementExists(elementLocator));
            }
            catch (NoSuchElementException)
            {
                Console.WriteLine("Element with locator: '" + elementLocator + "' was not found in current context page.");
                screenshotpath = UI_Driver.GetScreenshot("WaitUntilElementExists " + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw;
            }
        }

        public static void WaitUntilElementClickable(By elementLocator, int timeout)
        {
            try
            {
                var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(timeout));
                wait.Until(ExpectedConditions.ElementToBeClickable(elementLocator));
            }
            catch (NoSuchElementException)
            {
                screenshotpath = UI_Driver.GetScreenshot("WaitUntilElementClickable " + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Console.WriteLine("Element with locator: '" + elementLocator + "' was not found in current context page.");
                throw;
            }
        }
        public static void WaitForPageLoad(IWebDriver driver, int maxWaitTimeInSeconds)
        {
            string state = string.Empty;
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(maxWaitTimeInSeconds));

                wait.Until(d =>
                {
                    state = ((IJavaScriptExecutor)driver).ExecuteScript(@"return document.readyState").ToString();
                    return (state.Equals("complete", StringComparison.InvariantCultureIgnoreCase) || state.Equals("loaded", StringComparison.InvariantCultureIgnoreCase));
                });
            }
            catch (Exception e)
            {
                screenshotpath = UI_Driver.GetScreenshot("WaitForPageLoad " + DateTime.Now.ToString("yyyyMMddHHmmss"));

                Console.WriteLine(e.Message);
            }
        }


        public static void Wait(int miliseconds)
        {
            Thread.Sleep(miliseconds);
        }

        public static void WaitforElementToBeClick(IWebDriver driver, By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
                wait.Until(ExpectedConditions.ElementToBeClickable(element));
            }
            catch (ElementNotVisibleException e)
            {
                screenshotpath = UI_Driver.GetScreenshot("WaitforElementToBeClick " + DateTime.Now.ToString("yyyyMMddHHmmss"));

                Console.WriteLine(e.Message);
            }

        }
        #endregion Wait

        #region Browser Action
        public static void CloseBrowser()
        {
            driver.Close();
        }
        public static void Zoom(int p0)
        {
            string zoomlevel = "" + p0 + "%";
            IJavaScriptExecutor js = (IJavaScriptExecutor)driver;
            js.ExecuteScript("document.body.style.zoom='" + zoomlevel + "'");
            UI_Driver.Wait(5000);
        }

        public static void Fullscreen()
        {
            driver.Manage().Window.FullScreen();
        }


        // This will close all processes by process name.
        public static void CloseAllProcessesByName(string processName)
        {
            Process[] allProcesses = Process.GetProcesses();
            var result = from process in allProcesses
                         where process.ProcessName.Equals(processName)
                         select process;
            foreach (Process process in result)
            {
                if (!process.ProcessName.Equals(processName))
                {
                    process.Kill();
                }
            }
        }

        public static void RefreshPage()
        {
            driver.Navigate().Refresh();
        }

        public static void QuitBrowser()
        {
            driver.Quit();
        }

        public static int Close()
        {
            try
            {
                if (driver != null)
                {
                    driver.Close();
                    QuitBrowser();
                    driver.Dispose();
                }

                return _success;
            }
            catch (Exception e)
            {
                return _exception;
            }

        }

        #endregion Browser Action

        #region Frames
        public static void SwitchToFrame(By locatorElement)
        {
            Wait(500);
            IWebElement element = driver.FindElement(locatorElement);
            driver.SwitchTo().Frame(element);
        }

        public static void NavigateFrame(By locatorElement)
        {
            Wait(500);
            driver.SwitchTo().Frame(driver.FindElement(locatorElement));
        }

        public static void FrameSwitchDefault()
        {
            driver.SwitchTo().DefaultContent();
            Wait(500);
        }

        public static void FrameSwitchToParent()
        {
            driver.SwitchTo().ParentFrame();
            Wait(500);
        }

        #endregion Frames

        #region Table Action

        public static Dictionary<string, string> TableRowAndColumnForCommonType(By locatorElement_row, By locatorElement_count)
        {
            Dictionary<string, string> keyValueDictionary = new Dictionary<string, string>();
            int row_count = driver.FindElements(locatorElement_row).Count;
            int col_count = driver.FindElements(locatorElement_count).Count;
            for (int i = 1; i <= row_count; i++)
            {
                for (int j = 1; j <= col_count; j++)
                {
                    string column_headers = driver.FindElement(By.XPath("//table/thead/tr[" + i + "]/th[" + j + "]")).Text;
                    column_headers = i.ToString() + column_headers;
                    string table_data = driver.FindElement(By.XPath("//table/tbody/tr[" + i + "]/td[" + j + "]")).Text;
                    keyValueDictionary.Add(column_headers, table_data);

                }
                Console.WriteLine();
            }
            return keyValueDictionary;
        }

        public static int TotalTableRow(By locatorElement)
        {
            IWebElement TogetRows = driver.FindElement(locatorElement);
            IList<IWebElement> TotalRowsList = TogetRows.FindElements(By.TagName("tr"));
            int count = TotalRowsList.Count;
            return count;
        }
        public static int GetRowCount(By locatorElement)
        {
            int row = driver.FindElements(locatorElement).Count;
            return row;
        }

        public static void TableRowAndColumn(By locatorElement_row, By locatorElement_count, string number)
        {
            int row_count = driver.FindElements(locatorElement_row).Count;
            int col_count = driver.FindElements(locatorElement_count).Count;
            for (int i = 2; i <= row_count; i++)
            {
                for (int j = 1; j <= col_count; j++)
                {
                    string column_data = driver.FindElement(By.XPath("html/body/table/tbody/tr[" + i + "]/td[" + j + "]")).Text;
                    if (column_data == number)
                    {
                        driver.FindElement(By.XPath("html/body/table/tbody/tr[" + i + "]/td[" + j + "]")).Click();
                    }
                }
                Console.WriteLine();
            }
        }

        #endregion Table Action

        #region Time Action
        // Function to add Days or Hours or Minutes to current time
        public static string AddDayHoursMinutesToCurrent(int value, string p0)
        {
            DateTime currentdate = DateTime.Now;
            switch (p0)
            {
                case "Hours":
                    p0 = currentdate.AddHours(value).ToString("MM/dd/yyyy hh:mm tt");
                    break;
                case "Days":
                    p0 = currentdate.AddDays(value).ToString("MM/dd/yyyy hh:mm tt");
                    break;
                case "Minutes":
                    p0 = currentdate.AddMinutes(value).ToString("MM/dd/yyyy hh:mm tt");
                    break;
                default:
                    break;
            }
            return p0;
        }

        #endregion Time Action

        #region PDF

        // Validate the string in pdf
        /*public static bool PDFTextReader(string expectedText, string filePath)
        {
            try
            {
                string currentText = string.Empty;
                StringBuilder pdfText = new StringBuilder();
                using (PdfReader pdfReader = new PdfReader(filePath))
                {
                    for (int page = 1; page <= pdfReader.NumberOfPages; page++)
                    {
                        ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                        currentText = PdfTextExtractor.GetTextFromPage(pdfReader, page, strategy);
                        currentText = Encoding.UTF8.GetString(Encoding.Convert
                            (Encoding.Default, Encoding.UTF8, Encoding.UTF8.GetBytes(currentText)));
                        pdfText.Append(currentText);
                        if (pdfText.ToString().Contains(expectedText)) { return true; }
                    }
                    return false;
                }
            }
            catch
            {
                throw;
            }
        }*/

        #endregion PDF

        #region Specific Method

        public static void textDisplayed(By locatorElement)
        {
            IReadOnlyCollection<IWebElement> element = driver.FindElements(locatorElement);
            try
            {
                foreach (IWebElement actualValue in element)
                {
                    Assert.IsTrue(actualValue.Displayed);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                screenshotpath = UI_Driver.GetScreenshot("textDisplayed"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }


        public static void ActualValueIsDisplayed(By locatorElement, string value1 = null, string value2 = null, string value3 = null, string value4 = null, string value5 = null, string value6 = null, string value7 = null) //RW opional parameter
        {
            try
            {
                IList<string> expectedValue = new List<string>() { value1, value2, value3, value4, value5, value6, value7 };
                IReadOnlyCollection<IWebElement> element = driver.FindElements(locatorElement);
                foreach (IWebElement actualValue in element)
                {
                    string actualText = actualValue.Text;
                    if (actualText.Equals("PICKED"))
                    {
                        //Ignore("PICKED");
                    }
                    else if (actualText.TrimEnd().Contains("K"))
                    {
                        Assert.IsTrue(expectedValue.Contains(actualText));
                    }
                    else if (actualText.Contains("%"))
                    {
                        Assert.IsTrue(expectedValue.Contains(actualText));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("ActualValueIsDisplayed"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }
        public static string FetchDynamicValue(By locatorElement)
        {
            try
            {
                IWebElement element = driver.FindElement(locatorElement);
                string UI_Value = element.Text;
                return UI_Value;
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("FetchDynamicValue" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                throw new Exception(ex.Message);
            }
        }


        #endregion

        #region DropDown

        public static void SelectDropDownByText(string inputValue, By locatorElement)
        {
            WaitForPageLoad(driver, mediumWait);
            SelectElement element = new SelectElement(driver.FindElement(locatorElement));
            WaitforElementToBeClick(driver, locatorElement);
            element.SelectByText(inputValue);
        }
        public static void DeselectAll(By locatorElement)
        {
            WaitForPageLoad(driver, mediumWait);
            SelectElement element = new SelectElement(driver.FindElement(locatorElement));
            WaitforElementToBeClick(driver, locatorElement);
            element.DeselectAll();
        }
        public static void SelectDropDownByIndex(int index, By locatorElement)
        {
            WaitForPageLoad(driver, mediumWait);
            SelectElement element = new SelectElement(driver.FindElement(locatorElement));
            WaitforElementToBeClick(driver, locatorElement);
            element.SelectByIndex(index);
        }
        public static void SelectDropDownByValue(string inputValue, By locatorElement)
        {
            WaitForPageLoad(driver, mediumWait);
            SelectElement element = new SelectElement(driver.FindElement(locatorElement));
            WaitforElementToBeClick(driver, locatorElement);
            element.SelectByValue(inputValue);
        }
        public static void DropDownOrderForSelectTag(By locatorElement)
        {
            SelectElement selement = new SelectElement(driver.FindElement(locatorElement));
            IList<IWebElement> allDropdownOption = selement.AllSelectedOptions;
            IList originalDDOrder = new ArrayList();
            foreach (IWebElement eachoption in allDropdownOption)
            {
                string eachoption_Text = eachoption.Text;
                originalDDOrder.Add(eachoption_Text);
            }
            ArrayList ascendingDDOrder = new ArrayList();
            ascendingDDOrder.Add(originalDDOrder);
            ascendingDDOrder.Sort();
            Assert.Equals(ascendingDDOrder, originalDDOrder);
        }
        public static void DropDownOrderForOtherTag(By locatorElement)
        {
            IReadOnlyCollection<IWebElement> alloptions = driver.FindElements(locatorElement);
            IList emptyList = new ArrayList();
            foreach (IWebElement eachoption in alloptions)
            {
                string val = eachoption.Text;
                emptyList.Add(val);
            }
            ArrayList templist = new ArrayList(emptyList);
            templist.Sort();
            //CompareObjects<string>.CompareTwoObjects(templist.ToArray().ToString(), emptyList.ToArray().ToString());
            Assert.Equals(templist, emptyList);
        }

        #endregion

        #region Alert

        public static void Accept_ifAlertPresent(string altmessage)
        {
            if (AcceptTheAlert())
            {
                string alerttext = driver.SwitchTo().Alert().Text;
                Assert.IsTrue(altmessage.Contains(alerttext), $"The expected string: '{altmessage}' is not matched with actual string: '{alerttext}'");
                driver.SwitchTo().Alert().Accept();
            }
            else
            {
                Assert.IsTrue(false, "There is no Alert");
            }
        }

        public static void Dismiss_ifAlertPresent(string altmessage)
        {
            if (AcceptTheAlert())
            {
                string alerttext = driver.SwitchTo().Alert().Text;
                Assert.IsTrue(altmessage.Contains(alerttext), $"The expected string: '{altmessage}' is not matched with actual string: '{alerttext}'");
                driver.SwitchTo().Alert().Dismiss();
            }
            else
            {
                Assert.IsTrue(false, "There is no Alert");
            }
        }

        public static bool AcceptTheAlert()
        {
            IAlert alert = driver.SwitchTo().Alert();
            return true;
        }

        public static void ReadTheTextOnAlert(string expected_text)
        {
            IAlert alert = driver.SwitchTo().Alert();
            WaitForPageLoad(driver, mediumWait);
            string readTextOnAlert = alert.Text;
            Assert.AreEqual(expected_text, readTextOnAlert);
        }
        public static void SendTheTextOnAlertTextbox(string expected_text, By locatorElement)
        {
            IAlert alert = driver.SwitchTo().Alert();
            WaitForPageLoad(driver, mediumWait);
            driver.FindElement(locatorElement).SendKeys(expected_text);
            alert.Accept();
        }

        #endregion Alert

        #region Window Handles

        /* create More method for switch window*/
        public static void SwitchToWindowMethod1(string expectednewwindowtitle)
        {
            string newWindowHandle = driver.WindowHandles.Last();
            var newWindow = driver.SwitchTo().Window(newWindowHandle);
            Assert.AreEqual(expectednewwindowtitle, newWindow.Title);
        }
        public static void SwitchToDefaultWindow()
        {
            string newWindowHandle = driver.WindowHandles.FirstOrDefault();
            var newWindow = driver.SwitchTo().Window(newWindowHandle);
        }

        public static void SwitchToWindowMethod2()
        {
            string parentWindow = driver.CurrentWindowHandle;
            string popupWindow = string.Empty;
            IReadOnlyCollection<string> windowHandles = driver.WindowHandles;
            foreach (string childWindow in windowHandles)
            {
                if (childWindow != parentWindow)
                {
                    popupWindow = childWindow;
                    break;
                }
            }
            driver.SwitchTo().Window(popupWindow);
            WaitForPageLoad(driver, mediumWait);
        }

        #endregion

        #region color verification
        public static void ColorVerificationWithExpected(By locatorElement, string expectedColor)
        {
            IWebElement element = driver.FindElement(locatorElement);
            string color = element.GetCssValue("color");
            String[] hexValue = color.Replace("rgba(", "").Replace(")", "").Split(",");
            int hexValue1 = int.Parse(hexValue[0]);
            hexValue[1] = hexValue[1].Trim();
            int hexValue2 = int.Parse(hexValue[1]);
            hexValue[2] = hexValue[2].Trim();
            int hexValue3 = int.Parse(hexValue[2]);
            String actualColor = string.Format("#{0:X2}{1:X2}{2:X2}", hexValue1, hexValue2, hexValue3);
            //Assert.AreEqual(expectedColor, actualColor);
        }

        public static string GetColor(By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            string color = element.GetCssValue("color");
            String[] hexValue = color.Replace("rgba(", "").Replace(")", "").Split(",");
            int hexValue1 = int.Parse(hexValue[0]);
            hexValue[1] = hexValue[1].Trim();
            int hexValue2 = int.Parse(hexValue[1]);
            hexValue[2] = hexValue[2].Trim();
            int hexValue3 = int.Parse(hexValue[2]);
            String actualColor = string.Format("#{0:X2}{1:X2}{2:X2}", hexValue1, hexValue2, hexValue3);
            return actualColor;
        }

        public static void BackgroundColor(By locatorElement, string expectedColor)
        {
            IWebElement element = driver.FindElement(locatorElement);
            string background_color = element.GetCssValue("background-color");
            String[] hexValue = background_color.Replace("rgba(", "").Replace(")", "").Split(",");
            int hexValue1 = int.Parse(hexValue[0]);
            hexValue[1] = hexValue[1].Trim();
            int hexValue2 = int.Parse(hexValue[1]);
            hexValue[2] = hexValue[2].Trim();
            int hexValue3 = int.Parse(hexValue[2]);
            String actualColor = string.Format("#{0:X2}{1:X2}{2:X2}", hexValue1, hexValue2, hexValue3);
            Assert.AreEqual(expectedColor, actualColor);
        }

        public static void BackgroundColorForMultiElement(By locatorElement, string expectedColor)
        {
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
            foreach (IWebElement element in elements)
            {
                string background_color = element.GetCssValue("background-color");
                String[] hexValue = background_color.Replace("rgba(", "").Replace(")", "").Split(",");
                int hexValue1 = int.Parse(hexValue[0]);
                hexValue[1] = hexValue[1].Trim();
                int hexValue2 = int.Parse(hexValue[1]);
                hexValue[2] = hexValue[2].Trim();
                int hexValue3 = int.Parse(hexValue[2]);
                String actualColor = string.Format("#{0:X2}{1:X2}{2:X2}", hexValue1, hexValue2, hexValue3);
                Assert.AreEqual(expectedColor, actualColor);
            }

        }
        #endregion

        #region Excel


        #endregion

        #region Notification
        public static List<string> FaultDescription(By locatorElement)
        {
            var list = new List<string>();
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);

            foreach (IWebElement element in elements)
            {
                string actualText = element.Text;
                list.Add(actualText);
            }
            return list;
        }

        public static void CommonLogicForAscendingDescending(By locatorElement, string Ascending_Descending = null)
        {
            var list1 = new List<int>();

            try
            {
                UI_Driver.WaitForPageLoad(driver, mediumWait);
                IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
                foreach (IWebElement element in elements)
                {
                    string actualText = element.Text;
                    string[] ele = actualText.Split(" ");
                    if (ele[1] == "days")
                    {
                        var number = int.Parse(ele[0]);
                        list1.Add(number);
                    }
                    else
                    {
                        var number = int.Parse(ele[0]);
                        double day = number * (0.041);
                        day = Math.Round(day, 1, MidpointRounding.ToZero);
                        int res = Convert.ToInt32(day);
                        list1.Add(res);
                    }

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            var list2 = new List<int>(list1);
            list2.Sort();

            CompareObject<List<int>> compareObject = new CompareObject<List<int>>();

            if (Ascending_Descending.ToLower().Equals("ascending"))
            {
                list2.Reverse();
                Assert.IsTrue(compareObject.CompareTwoListObjects(list1, list2), $"The expected string: '{list2}' is not matched with actual string: '{list1}'");
            }
            else
            {

                //Assert.IsTrue(compareObject.CompareTwoListObjects(list1, list2), $"The expected string: '{list2}' is not matched with actual string: '{list1}'");
            }

        }


        #endregion

        #region Asset Health

        public static void keyWidget()
        {
            IList<string> list = new List<string>() { "Overall Equipment Efficiency", "Availability", "Performance", "Quality" };




        }

        #endregion

        #region Generate Random

        public static Random _random = new Random();
        public static int RandomNumber(int min, int max)
        {
            return _random.Next(min, max);
        }

        public int RandomAlphaNumeric(int min, int max)
        {
            return _random.Next(min, max);
        }

        #endregion




    }
}