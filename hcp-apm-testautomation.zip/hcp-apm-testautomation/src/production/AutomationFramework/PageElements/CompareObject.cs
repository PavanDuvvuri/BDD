﻿using ObjectsComparer;
using RestSharp;
using System;
using System.Collections.Generic;

namespace AutomationFramework.PageElements
{
    public class CompareObject<T>
    {
        /// <summary>
        /// Compare two collection objects and returning bool value
        /// </summary>
        /// <param name="expected"></param>
        /// <param name="actual"></param>
        /// <returns></returns>
        public bool CompareTwoListObjects(T expected, T actual)
        {
            var comparer = new ObjectsComparer.Comparer<T>();
            bool check = comparer.Compare(expected, actual, out IEnumerable<Difference> differences);
            List<string> diffValues = new List<string>();
            if (!check)
            {
                foreach (Difference value in differences)
                {
                    diffValues.Add(value.ToString());

                }
                diffValues.ForEach(i => Console.Write("{0}\t", i));
            }
            return check;

        }
    }
}
