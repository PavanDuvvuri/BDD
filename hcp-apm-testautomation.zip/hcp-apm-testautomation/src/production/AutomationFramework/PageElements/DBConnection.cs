﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace AutomationFramework.PageElements
{
    public class DBConnection
    {

        #region SQL Connection code

        static string dbConnection;
        static SqlConnection conn;

        public static SqlConnection SQLConnection(string env)
        {
            switch (env.ToLower())
            {
                case "stage":
                    dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit2;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";
                    conn = new SqlConnection(dbConnection);
                    conn.Open();
                    return conn;
                case "qa":
                    dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-content1;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";
                    conn = new SqlConnection(dbConnection);
                    conn.Open();
                    return conn;
                default:
                    return null;
                    break;
            }
        }

        #endregion

        #region conditional Statment

        public static string conditionalStatment(double number2)
        {
            string number;
            if (number2 > 0 && number2 < 1)
            {
                number = number2.ToString();
            }
            else
            {
                number = number2.ToString("0.0");
            }
            return number;
        }
        public static string conditionalStatment1(double number2)
        {
            string number;
            if (number2 == 0)
            {
                number = number2.ToString();
            }
            else
            {
                number = number2.ToString();
            }
            return number;
        }
        public static string returnAppropirateString(double number)
        {
            switch (number)
            {
                case 1:
                    return ("Running".ToUpper());
                case 8:
                    return ("100% Full".ToUpper());
                case 9:
                    return ("Offtime".ToUpper());
                case 2:
                    return ("Idletime".ToUpper());
                case 4:
                    return ("Downtime".ToUpper());
                case 6:
                    return "Offline".ToUpper();
                case 5:
                    return ("Maintenance".ToUpper());
                case 0:
                    return "";
                default:
                    return "No matching number";
                    break;
            }
        }

        #endregion

        #region Daily Time

        public static string todaydate;
        public static string todaydate1;
        public static string tomorrowdate;
        public static string todaydateWithTime = DateTime.Now.AddHours(-5.5).ToString("yyyy-MM-dd HH:mm:ss.000");

        //Daily tym
        public static string tym()
        {
            string time = DateTime.Now.AddHours(-5.5).ToString("HH.mm");
            var timeInInteger = double.Parse(time);
            if (timeInInteger >= 6.0 && timeInInteger <= 23.59)
            {
                //todaydate = DateTime.Now.ToString("yyyy-MM-dd");
                todaydate = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
            }
            else if (timeInInteger >= 00.0 && timeInInteger < 06.0)
            {
                todaydate = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd");
            }
            return todaydate;
        }

        public static string DailytymEnd()
        {
            tomorrowdate = DateTime.Now.ToString("yyyy-MM-dd");
            string time = DateTime.Now.AddHours(-5.5).ToString("HH.mm");
            var timeInInteger = double.Parse(time);
            if (timeInInteger >= 6.0 && timeInInteger <= 23.59)
            {
                tomorrowdate = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd");
            }
            else if (timeInInteger >= 00.0 && timeInInteger < 06.0)
            {
                tomorrowdate = DateTime.Now.ToString("yyyy-MM-dd");
            }
            return tomorrowdate;
        }

        #endregion

        #region Shift 1,2,3

        //Shift tym start
        public static string ShiftWiseStartTym()
        {
            todaydate = DateTime.Now.ToString("yyyy-MM-dd");
            string time = DateTime.UtcNow.ToString("HH.mm");
            //string time = DateTime.Now.AddHours(-5.5).ToString("HH.mm");
            var timeInInteger = double.Parse(time);
            if (timeInInteger > 6.0 && timeInInteger <= 14.0)
            {
                //Shift1
                todaydate = todaydate + " 07:00:00.000";
            }
            else if (timeInInteger > 14.0 && timeInInteger <= 22.0)
            {
                //Shift2
                todaydate = todaydate + " 15:00:00.000";
            }
            else if (timeInInteger > 22.0 && timeInInteger <= 23.59)
            {
                //Shift3
                todaydate = todaydate + " 23:00:00.000";
            }
            else if (timeInInteger >= 00.0 && timeInInteger <= 6.0)
            {
                //Shift3
                todaydate = DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd") + " 23:00:00.000";
            }
            return todaydate;
        }
        //Shift tym end
        public static string ShiftWiseEndTym()
        {
            todaydate1 = DateTime.Now.ToString("yyyy-MM-dd");
            string time = DateTime.Now.AddHours(-5.5).ToString("HH.mm");
            var timeInInteger = double.Parse(time);
            if (timeInInteger > 6.0 && timeInInteger <= 14.0)
            {
                //Shift1
                todaydate1 = todaydate1 + " 14:00:00.000";
            }
            else if (timeInInteger > 14.0 && timeInInteger <= 22.0)
            {
                //Shift2
                todaydate1 = todaydate1 + " 22:00:00.000";
            }
            else if (timeInInteger > 22.0 && timeInInteger <= 23.59)
            {
                //Shift3
                todaydate1 = DateTime.Now.AddDays(1).ToString("yyyy-MM-dd") + " 06:00:00.000";
            }
            else if (timeInInteger >= 00.0 && timeInInteger <= 6.0)
            {
                //Shift3
                todaydate1 = todaydate1 + " 06:00:00.000";
            }
            return todaydate1;
        }

        #endregion

        #region Order Quota

        public static string GetOrderQuota_KPI(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select Top(1) TargetOverride as DailyShippedCartonsKPITarget from KpiTargetConfigurations where AssetKPIConfigurationId in (Select AssetKPIConfigurationId from AssetKPIConfigurations where KPI in ('ShippedCartons') and ReportingPeriod = '" + shift_daily + "') order by EffectiveDate desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("DailyShippedCartonsKPITarget"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            return number;
        }
        public static string GetOrderQuota(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as DailyOrderQuota from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("DailyOrderQuota"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            return number;
        }
        public static string GetVerifyOrderQuota(string assetName, string shift_daily, string env)
        {
            string OrderQuotaKPI = GetOrderQuota_KPI(assetName, shift_daily, env);
            string OrderQuota = GetOrderQuota(assetName, shift_daily, env);
            if (shift_daily == "Daily")
            {
                Assert.IsTrue(OrderQuotaKPI.Equals(OrderQuota), $"The expected string: '{OrderQuota}' is not matched with actual string: '{OrderQuotaKPI}'");
            }
            return OrderQuota;
        }

        #endregion

        #region Current/Plan

        public static double GetShippedcartons_target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartons_Target = @"select top(1) Value as ShippedCartonsTarget from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartons_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("ShippedCartonsTarget"));
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetShippedcartons_Actual(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Shipping";
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartons_Actual = @"select top(1) Value as ShippedCartonsActual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartons_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("ShippedCartonsActual"));
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static string GetCurrentPlan(string assetName, string shift_daily, string env)
        {
            string number;
            double number3 = GetShippedcartons_Actual(assetName, shift_daily, env) / GetShippedcartons_target(assetName, shift_daily, env);
            number3 = number3 * 100;
            double value2 = Math.Round(number3, 0, MidpointRounding.AwayFromZero);
            number = value2.ToString();
            number = number + ("%");
            number = number.Trim();
            return number;
        }

        #endregion

        #region PickededOrderQuota
        public static string GetPickededOrderQuota(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Picking";
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as Pickedvalue from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Pickedvalue"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }

        #endregion

        #region Picked Progress Bar

        public static string PickedProgressBar(string assetName, string shift_daily, string env)
        {
            double result_target;
            double pickedProgressActual = GetPickedcartons_Actual(assetName, shift_daily, env);
            double pickedProgressRateTarget = GetPickedcartonsRateForEfficiency_target(assetName, shift_daily, env);
            var time_elapsed = ElapsedTime(env);

            if (shift_daily == "Daily")
            {
                result_target = (pickedProgressRateTarget * time_elapsed);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (pickedProgressRateTarget * time_elapsed);
            }
            double number3 = +(pickedProgressActual - result_target);
            number3 = number3 * (.001);
            number3 = Math.Round(number3, 1, MidpointRounding.AwayFromZero);
            string PickedProgressBar_string = number3.ToString("0.0");
            PickedProgressBar_string = PickedProgressBar_string + ("K");
            return PickedProgressBar_string;
        }

        #endregion

        #region ShippedOrderQuota
        public static string GetShippedOrderQuota(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Shipping";
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as Shippedvalue from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Shippedvalue"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }

        #endregion

        #region Shipped Progress Bar

        public static string ShippedProgressBar(string assetName, string shift_daily, string env)
        {
            double result_target;
            double pickedProgressActual = GetShippedcartons_Actual(assetName, shift_daily, env);
            double pickedProgressRateTarget = GetShippedcartonsRateForEfficiency_target(assetName, shift_daily, env);

            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (pickedProgressRateTarget * time_elapsed);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (pickedProgressRateTarget * time_elapsed);
            }


            double number3 = (pickedProgressActual - result_target);
            number3 = number3 * (.001);
            number3 = Math.Round(number3, 1, MidpointRounding.AwayFromZero);
            string PickedProgressBar_string = number3.ToString("0.0");
            PickedProgressBar_string = PickedProgressBar_string + ("K");
            return PickedProgressBar_string;
        }

        #endregion

        #region AssetDownTime Quota

        public static string GetAssetDowntime(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as AssetDownTimevalue from MetricHistoryValues where Assetname= '" + assetName + "' and MetricName = 'Downtime' and ReportingPeriod = '" + shift_daily + "' order by Timestamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("AssetDownTimevalue"));
                            number1 = number1 * 60;
                        }
                        reader.Close();
                    }
                }
            }

            number1 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
            if (number1 > 60)
            {
                var hours = Math.Floor(number1 / 60);
                var minutes = number1 % 60;

                return hours.ToString() + " H" + " : " + minutes.ToString() + " M";
            }
            else
            {
                return number1.ToString() + " M";
            }

        }

        public static string GetAssetDowntimeOrderQuota(string assetName, string shift_daily, string env)
        {
            string _assetDownTime;
            _assetDownTime = GetAssetDowntime(assetName, shift_daily, env);
            return _assetDownTime;
        }

        #endregion

        #region Current/Plan_Shipping

        public static string GetShippedcartonsRate_KPItarget(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Target = @"select Top(1) TargetOverride as DailyShippedCartonRateKPITarget from KpiTargetConfigurations where AssetKPIConfigurationId in (Select AssetKPIConfigurationId from AssetKPIConfigurations where KPI in ('ShippedCartonRate') and ReportingPeriod = '" + shift_daily + "') order by EffectiveDate desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("DailyShippedCartonRateKPITarget"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }
        public static string GetShippedcartonsRate_target(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Target = @"select top(1) Value as CurrentPlanValue_Target from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartonRate' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("CurrentPlanValue_Target"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }
        public static string GetShippedcartonsRate_Actual(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Shipping";
            string number = "";
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Actual = @"select top(1) Value as CurrentPlanValue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartonRate' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number2 = reader.GetDouble(reader.GetOrdinal("CurrentPlanValue_Actual"));
                            number2 = number2 * (.001);
                            number2 = Math.Round(number2, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }
        public static string GetCurrentPlanShippingPanel(string assetName, string shift_daily, string env)
        {
            string ShippedCartonsRate_Target = GetShippedcartonsRate_target(assetName, shift_daily, env);
            if (shift_daily == "Daily")
            {
                string ShippedCartonsRateKPI_Target = GetShippedcartonsRate_KPItarget(assetName, shift_daily, env);
                Assert.IsTrue(ShippedCartonsRateKPI_Target.Equals(ShippedCartonsRate_Target), $"The expected string: '{ShippedCartonsRate_Target}' is not matched with actual string: '{ShippedCartonsRateKPI_Target}'");
            }
            string number3 = GetShippedcartonsRate_Actual(assetName, shift_daily, env) + " /" + ShippedCartonsRate_Target;
            number3 = number3.Trim();
            return number3;
        }

        #endregion

        #region Time Elapsed

        public static double ElapsedTime(string env)
        {
            string utc_time = null;
            if (env.ToLower() == "stage")
                utc_time = DateTime.Now.ToUniversalTime().AddHours(-6).ToString("HH.mm");
            else if (env.ToLower() == "qa")
                utc_time = DateTime.Now.ToUniversalTime().AddHours(-8).ToString("HH.mm");

            string[] tym = utc_time.Split(".");
            var tymHourFirstPart = double.Parse(tym[0]);
            var tymMinuteFirstPart = tymHourFirstPart * 60;
            var tymMinuteSecondPart = double.Parse(tym[1]);
            var totaltym = tymMinuteFirstPart + tymMinuteSecondPart;
            var totaltymInHour = totaltym / 60;
            totaltymInHour = Math.Round(totaltymInHour, 2, MidpointRounding.AwayFromZero);
            return totaltymInHour;
        }

        #endregion

        #region Expected Shipping Panel

        public static string GetExpectedShippingPanel(string assetName, string shift_daily, string env)
        {
            double ExpectedInShippingCartons;
            string ExpectedInShippingCartons_string;
            double target = GetShippedcartons_target(assetName, shift_daily, env);
            double actual = GetShippedcartons_Actual(assetName, shift_daily, env);
            var time_elapsed = ElapsedTime(env);

            if (shift_daily == "Daily")
            {
                var timeRemainingForDay = 24 - time_elapsed;
                ExpectedInShippingCartons = (target - actual) / timeRemainingForDay;
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                var timeRemainingForShift = 8 - time_elapsed;
                ExpectedInShippingCartons = (target - actual) / timeRemainingForShift;
            }
            if (ExpectedInShippingCartons < 0.0)
            {
                ExpectedInShippingCartons_string = "0.0K";
            }
            else
            {
                ExpectedInShippingCartons = ExpectedInShippingCartons * (.001);
                ExpectedInShippingCartons = Math.Round(ExpectedInShippingCartons, 1, MidpointRounding.AwayFromZero);//change this
                ExpectedInShippingCartons_string = ExpectedInShippingCartons.ToString("0.0");
                ExpectedInShippingCartons_string = ExpectedInShippingCartons_string + ("K");
            }
            return ExpectedInShippingCartons_string;
        }

        #endregion

        #region Efficincy_Shipped

        public static double GetShippedcartonsRateForEfficiency_target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Target = @"select top(1) Value as CurrentPlanDenominatorValue from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartonRate' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("CurrentPlanDenominatorValue"));
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetShippedcartonsRateForEfficiency_Actual(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Shipping";
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Actual = @"select top(1) Value as CurrentPlanNumeratorValue from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("CurrentPlanNumeratorValue"));
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static string GetEfficiencyShippingPanel(string assetName, string shift_daily, string env)
        {
            double result_target;
            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (GetShippedcartonsRateForEfficiency_target(assetName, shift_daily, env) * time_elapsed);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (GetShippedcartonsRateForEfficiency_target(assetName, shift_daily, env) * time_elapsed);
            }
            double result_actual = GetShippedcartonsRateForEfficiency_Actual(assetName, shift_daily, env);
            double number3 = (result_actual / result_target) * 100;
            number3 = Math.Round(number3, 0, MidpointRounding.AwayFromZero);
            string number4 = number3.ToString();
            number4 = number4 + ("%");
            return number4;
        }

        #endregion

        #region Current/Plan_Picking Widget

        public static string GetPickedcartonsRate_KPItarget(string assetName, string shift_daily, string env)
        {
            string number11 = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Target = @"select Top(1) TargetOverride as CurrentPlanValue_Target from KpiTargetConfigurations where AssetKPIConfigurationId in (Select AssetKPIConfigurationId from AssetKPIConfigurations where KPI in ('PickedCartonRate') and ReportingPeriod = '" + shift_daily + "') order by EffectiveDate desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("CurrentPlanValue_Target"));
                            number1 = number1 * (.001);
                            number1 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number11 = conditionalStatment(number1);
                        }
                        reader.Close();
                    }
                }
            }
            number11 = number11 + ("K");
            number11 = number11.Trim();
            return number11;
        }
        public static string GetPickedcartonsRate_target(string assetName, string shift_daily, string env)
        {
            string number11 = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Target = @"select top(1) Value as CurrentPlanValue_Target from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartonRate' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("CurrentPlanValue_Target"));
                            number1 = number1 * (.001);
                            number1 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number11 = conditionalStatment(number1);
                        }
                        reader.Close();
                    }
                }
            }
            number11 = number11 + ("K");
            number11 = number11.Trim();
            return number11;
        }
        public static string GetPickedcartonsRate_Actual(string assetName, string shift_daily, string env)
        {
            string number21 = "";
            var conn = SQLConnection(env);
            string ShippedCartonsRate_Actual = @"select top(1) Value as CurrentPlanValue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartonRate' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(ShippedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number2 = reader.GetDouble(reader.GetOrdinal("CurrentPlanValue_Actual"));
                            number2 = number2 * (.001);
                            number2 = Math.Round(number2, 1, MidpointRounding.AwayFromZero);
                            number21 = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number21 = number21 + ("K");
            number21 = number21.Trim();
            return number21;
        }
        public static string GetCurrentPlanPickingPanel(string assetName, string shift_daily, string env)
        {
            string PickedCartonsRate_Target = GetPickedcartonsRate_target(assetName, shift_daily, env);
            if (shift_daily == "Daily")
            {
                string PickedCartonsRateKPI_Target = GetPickedcartonsRate_KPItarget(assetName, shift_daily, env);
                Assert.IsTrue(PickedCartonsRateKPI_Target.Equals(PickedCartonsRate_Target), $"The expected string: '{PickedCartonsRate_Target}' is not matched with actual string: '{PickedCartonsRateKPI_Target}'");
            }
            string number3 = GetPickedcartonsRate_Actual(assetName, shift_daily, env) + " /" + PickedCartonsRate_Target;
            number3 = number3.Trim();
            return number3;
        }

        #endregion

        #region Actual/Target_Picking Widget

        public static double GetPickedcartons_target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartons_Target = @"select top(1) Value as ExpectedValue_Target from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartons_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("ExpectedValue_Target"));

                        }

                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetPickedcartons_Actual(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Picking";
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartons_Actual = @"select top(1) Value as ExpectedValue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartons_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("ExpectedValue_Actual"));

                        }

                        reader.Close();
                    }
                }
            }
            return number2;
        }

        #endregion

        #region Expected Picking Widget

        public static string GetExpectedPickingPanel(string assetName, string shift_daily, string env)
        {
            double ExpectedInPickingCartons;
            string ExpectedInShippingCartons_string;
            double target = GetPickedcartons_target(assetName, shift_daily, env);
            double actual = GetPickedcartons_Actual(assetName, shift_daily, env);
            var time_elapsed = ElapsedTime(env);

            if (shift_daily == "Daily")
            {
                var timeRemainingForDay = 24 - time_elapsed;
                ExpectedInPickingCartons = (target - actual) / timeRemainingForDay;
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                var timeRemainingForShift = 8 - time_elapsed;
                ExpectedInPickingCartons = (target - actual) / timeRemainingForShift;
            }
            if (ExpectedInPickingCartons < 0.0)
            {
                ExpectedInShippingCartons_string = "0.0K";
            }
            else
            {
                ExpectedInPickingCartons = ExpectedInPickingCartons * (.001);
                ExpectedInPickingCartons = Math.Round(ExpectedInPickingCartons, 1, MidpointRounding.AwayFromZero);
                ExpectedInShippingCartons_string = ExpectedInPickingCartons.ToString("0.0");
                ExpectedInShippingCartons_string = ExpectedInShippingCartons_string + ("K");
            }
            return ExpectedInShippingCartons_string;
        }

        #endregion

        #region Released/Picked_Picking Widget

        public static string GetPickededPicking_Actual(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as Releasedvalue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Releasedvalue_Actual"));
                            number1 = number1 * (.001);
                            number1 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number1);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }
        public static string ReleasedPickedPickingData(string assetName, string shift_daily, string env)
        {
            string number3 = GetPickededPicking_Actual(assetName, shift_daily, env) + "/" + GetPickededPicking_Actual(assetName, shift_daily, env);
            number3 = number3.Trim();
            return number3;
        }

        #endregion

        #region Efficiency_Picking Widget

        public static double GetPickedcartonsRateForEfficiency_target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartonsRate_Target = @"select top(1) Value as EfficiencyValue_Target from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartonRate' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("EfficiencyValue_Target"));
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetPickedcartonsRateForEfficiency_Actual(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Picking";
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as EfficiencyValue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("EfficiencyValue_Actual"));
                        }
                        reader.Close();
                    }
                }
            }

            return number2;
        }
        public static string GetEfficiencyPickingPanel(string assetName, string shift_daily, string env)
        {
            double result_target;
            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (GetPickedcartonsRateForEfficiency_target(assetName, shift_daily, env) * time_elapsed);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (GetPickedcartonsRateForEfficiency_target(assetName, shift_daily, env) * time_elapsed);
            }

            double result_actual = GetPickedcartonsRateForEfficiency_Actual(assetName, shift_daily, env);
            double number3 = (result_actual / result_target) * 100;
            number3 = Math.Round(number3, 0, MidpointRounding.AwayFromZero);
            string number4 = number3.ToString();
            number4 = number4 + ("%");
            return number4;
        }

        #endregion

        #region Notification

        public static string first_faultDescription(string assetName)
        {
            string number = "";

            string dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit2;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";

            SqlConnection conn = new SqlConnection(dbConnection);
            conn.Open();

            string strQuery = @"SELECT TOP (1) Description FROM [dbo].[ActiveFaultHistoriesV2] where EquipmentName_EOM = '" + assetName + "' order by StartTime desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number = reader.GetString(reader.GetOrdinal("Description"));
                        }

                        reader.Close();
                    }
                }
            }
            return number.Trim();
        }
        public static string last_faultDescription(string assetName)
        {
            string number = "";
            string dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit1;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";

            SqlConnection conn = new SqlConnection(dbConnection);
            conn.Open();

            string strQuery = @"SELECT TOP (1) Description FROM [dbo].[ActiveFaultHistoriesV2] where EquipmentName_EOM = '" + assetName + "' order by StartTime asc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number = reader.GetString(reader.GetOrdinal("Description"));
                        }

                        reader.Close();
                    }
                }
            }
            return number;
        }
        public static int TotalCount_faultDescription(string assetName)
        {
            int number = 0;
            string dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit1;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";

            SqlConnection conn = new SqlConnection(dbConnection);
            conn.Open();

            string strQuery = @"SELECT  COUNT(*) as TotalFault FROM [dbo].[ActiveFaultHistoriesV2] where EquipmentName_EOM = '" + assetName + "'";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number = reader.GetInt32(reader.GetOrdinal("TotalFault"));
                        }

                        reader.Close();
                    }
                }
            }
            return number;
        }

        #endregion

        #region Utilization, Avg prod loss, All

        public static Dictionary<string, string> Getkpivalues(string assetName, string assetcollection, string shift_daily, string env)
        {
            assetName = assetName + assetcollection;
            var todaydate = tym();
            var conn = SQLConnection(env);
            double remainingValue1 = 0.0;

            Dictionary<string, string> all_utilization_AvgProdLoss = new Dictionary<string, string>();
            all_utilization_AvgProdLoss.Clear();
            IList<double> totalTime = new List<double>();

            string abort_value = @"select top(1) Value as Aborts from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'AbortLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string badgap_value = @"select top(1) Value as Badgap from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'BadGapLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string mistrack_value = @"select top(1) Value as Mistracks from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'MistrackLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string readerror_value = @"select top(1) Value as ReadErrors from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ReadErrorLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string downtimeCPM_value = @"select top(1) Value as DowntimeCPM from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'DowntimeLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string idletimeCPM_value = @"select top(1) Value as IdleTimeCPM from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'IdletimeLossCPM' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            string downtime_value = @"select top(1) Value as Downtime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Downtime' and ReportingPeriod = '" + shift_daily + "' and TimeStamp >'" + todaydate + "T08:00:00' order by TimeStamp desc";
            string idletime_value = @"select top(1) Value as Idletime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Idletime' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string energyoff_value = @"select top(1) Value as EnergyOff from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'EnergyOff' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string fulltime_value = @"select top(1) Value as FullTime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'FullTime' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string uptime_value = @"select top(1) Value as Uptime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Uptime' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";




            SqlCommand downTime = new SqlCommand(downtime_value, conn);
            SqlCommand idleTime = new SqlCommand(idletime_value, conn);
            SqlCommand energyOff = new SqlCommand(energyoff_value, conn);
            SqlCommand fullTime = new SqlCommand(fulltime_value, conn);
            SqlCommand upTime = new SqlCommand(uptime_value, conn);
            SqlCommand abort = new SqlCommand(abort_value, conn);
            SqlCommand badgap = new SqlCommand(badgap_value, conn);
            SqlCommand mistrack = new SqlCommand(mistrack_value, conn);
            SqlCommand readerror = new SqlCommand(readerror_value, conn);
            SqlCommand downTimeCPM = new SqlCommand(downtimeCPM_value, conn);
            SqlCommand idletimeCPM = new SqlCommand(idletimeCPM_value, conn);

            downTime.ExecuteNonQuery();
            idleTime.ExecuteNonQuery();
            energyOff.ExecuteNonQuery();
            fullTime.ExecuteNonQuery();
            upTime.ExecuteNonQuery();
            abort.ExecuteNonQuery();
            badgap.ExecuteNonQuery();
            mistrack.ExecuteNonQuery();
            readerror.ExecuteNonQuery();
            downTimeCPM.ExecuteNonQuery();
            idletimeCPM.ExecuteNonQuery();

            using (SqlDataReader reader1 = downTime.ExecuteReader())
            {
                while (reader1.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double downtime2 = reader1.GetDouble(reader1.GetOrdinal("Downtime"));
                    string downtime1 = downtime2.ToString();
                    string[] downtimeValue = downtime1.Split(".");
                    var hourValue = int.Parse(downtimeValue[0]);
                    string hour = hourValue + "h";

                    if (downtime2 != 0)
                    {
                        var minvalue = (downtime2 - hourValue) * 60;
                        var downtime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = downtime;
                        minutes = downtime + "m";
                    }

                    string DownTime = hour + " " + minutes;
                    var hrMinValue1 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    all_utilization_AvgProdLoss.Add("Downtime", DownTime);
                    reader1.Close();
                    break;
                }
            }

            using (SqlDataReader reader2 = idleTime.ExecuteReader())
            {
                while (reader2.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double idletime2 = reader2.GetDouble(reader2.GetOrdinal("Idletime"));
                    string idletime1 = idletime2.ToString();
                    string[] idletimeValue = idletime1.Split(".");
                    var hourValue = int.Parse(idletimeValue[0]);
                    string hour = hourValue + "h";

                    if (idletime2 != 0)
                    {
                        var minvalue = (idletime2 - hourValue) * 60;
                        var idletime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = idletime;
                        minutes = idletime + "m";
                    }

                    string IdleTime = hour + " " + minutes;
                    var hrMinValue2 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    all_utilization_AvgProdLoss.Add("Idletime", IdleTime);
                    reader2.Close();
                    break;
                }
            }

            using (SqlDataReader reader3 = energyOff.ExecuteReader())
            {
                while (reader3.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double energyoff2 = reader3.GetDouble(reader3.GetOrdinal("EnergyOff"));
                    string energyoff1 = energyoff2.ToString();
                    string[] energyoffValue = energyoff1.Split(".");
                    var hourValue = int.Parse(energyoffValue[0]);
                    string hour = hourValue + "h";

                    if (energyoff2 != 0)
                    {
                        var minvalue = (energyoff2 - hourValue) * 60;
                        var energyoff = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = energyoff;
                        minutes = energyoff + "m";
                    }

                    string EnergyOff = hour + " " + minutes;
                    var hrMinValue3 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    all_utilization_AvgProdLoss.Add("EnergyOff", EnergyOff);
                    reader3.Close();
                    break;
                }
            }

            using (SqlDataReader reader4 = fullTime.ExecuteReader())
            {
                while (reader4.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double fulltime2 = reader4.GetDouble(reader4.GetOrdinal("FullTime"));
                    string fulltime1 = fulltime2.ToString();
                    string[] fulltimeValue = fulltime1.Split(".");
                    var hourValue = int.Parse(fulltimeValue[0]);
                    string hour = hourValue + "h";

                    if (fulltime2 != 0)
                    {
                        var minvalue = (fulltime2 - hourValue) * 60;
                        var fulltime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = fulltime;
                        minutes = fulltime + "m";
                    }

                    string FullTime = hour + " " + minutes;
                    var hrMinValue4 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    all_utilization_AvgProdLoss.Add("FullTime", FullTime);
                    reader4.Close();
                    break;
                }
            }

            using (SqlDataReader reader5 = upTime.ExecuteReader())
            {
                while (reader5.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double uptime2 = reader5.GetDouble(reader5.GetOrdinal("Uptime"));
                    string uptime1 = uptime2.ToString();
                    string[] uptimeValue = uptime1.Split(".");
                    var hourValue = int.Parse(uptimeValue[0]);
                    string hour = hourValue + "h";

                    if (uptime2 != 0)
                    {
                        var minvalue = (uptime2 - hourValue) * 60;
                        var uptime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = uptime;
                        if (minValue == 60)
                        {
                            minvalue = 1;
                            hourValue = (int)(hourValue + minvalue);
                            hour = hourValue + "h";
                            uptime = 0;
                        }
                        minutes = uptime + "m";
                    }

                    string UpTime = hour + " " + minutes;
                    var hrMinValue5 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    all_utilization_AvgProdLoss.Add("Uptime", UpTime);
                    reader5.Close();
                    break;
                }
            }

            using (SqlDataReader reader6 = abort.ExecuteReader())
            {
                while (reader6.Read())
                {
                    double aborts = reader6.GetDouble(reader6.GetOrdinal("Aborts"));
                    aborts = Math.Ceiling(aborts);
                    string aborts1 = aborts.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Aborts", aborts1);
                    reader6.Close();
                    break;
                }
            }

            using (SqlDataReader reader7 = badgap.ExecuteReader())
            {
                while (reader7.Read())
                {
                    double badgaps = reader7.GetDouble(reader7.GetOrdinal("Badgap"));
                    badgaps = Math.Ceiling(badgaps);
                    string badgaps1 = badgaps.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Bad Gaps", badgaps1);
                    reader7.Close();
                    break;
                }
            }

            using (SqlDataReader reader8 = mistrack.ExecuteReader())
            {
                while (reader8.Read())
                {
                    double mistracks = reader8.GetDouble(reader8.GetOrdinal("Mistracks"));
                    mistracks = Math.Ceiling(mistracks);
                    string mistracks1 = mistracks.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Mistracks", mistracks1);
                    reader8.Close();
                    break;
                }
            }

            using (SqlDataReader reader9 = readerror.ExecuteReader())
            {
                while (reader9.Read())
                {
                    double readerrors = reader9.GetDouble(reader9.GetOrdinal("ReadErrors"));
                    readerrors = Math.Ceiling(readerrors);
                    string readerrors1 = readerrors.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Read Errors", readerrors1);
                    reader9.Close();
                    break;
                }
            }

            using (SqlDataReader reader10 = downTimeCPM.ExecuteReader())
            {
                while (reader10.Read())
                {
                    double downtimecpm = reader10.GetDouble(reader10.GetOrdinal("DowntimeCPM"));
                    downtimecpm = Math.Ceiling(downtimecpm);
                    string downtimecpm1 = downtimecpm.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Downtime1", downtimecpm1);
                    reader10.Close();
                    break;
                }
            }

            using (SqlDataReader reader11 = idletimeCPM.ExecuteReader())
            {
                while (reader11.Read())
                {
                    double idletimecpm = reader11.GetDouble(reader11.GetOrdinal("IdleTimeCPM"));
                    idletimecpm = Math.Ceiling(idletimecpm);
                    string idletimecpm1 = idletimecpm.ToString() + "cpm";
                    all_utilization_AvgProdLoss.Add("Idletime1", idletimecpm1);
                    reader11.Close();
                    break;
                }
            }

            var totalHM1 = (totalTime[0] + totalTime[2] + totalTime[4] + totalTime[6] + totalTime[8]);//hour addition after split hr,min
            var totalHM32 = (totalTime[1] + totalTime[3] + totalTime[5] + totalTime[7] + totalTime[9]);//min addition


            //when min value will be more then 60 then we need to use below condition
            if (totalHM32 >= 60 && totalHM32 < 120)
            {
                var min = totalHM32 - 60;
                var hour = (totalHM32 - min) / 60;
                var hour2 = hour.ToString();
                var value1 = hour2 + "." + min;//1.101
                totalHM32 = double.Parse(value1);//1.101
            }
            else if (totalHM32 >= 120 && totalHM32 < 240)
            {
                var min = totalHM32 - 120;
                var hour = (totalHM32 - min) / 60;
                var hour2 = hour.ToString();
                var value1 = hour2 + "." + min;
                totalHM32 = double.Parse(value1);
            }
            else
            {
                var value2 = "." + totalHM32;
                totalHM32 = double.Parse(value2);
            }

            var total_final = totalHM1 + totalHM32;
            total_final = Math.Round(total_final, 2, MidpointRounding.AwayFromZero);

            if (shift_daily == "Daily")
            {
                remainingValue1 = (23.60) - (total_final);
                remainingValue1 = Math.Round(remainingValue1, 2, MidpointRounding.AwayFromZero);
            }
            else if (shift_daily == "Shift")
            {
                remainingValue1 = (7.60) - (total_final);
                remainingValue1 = Math.Round(remainingValue1, 2, MidpointRounding.AwayFromZero);
            }
            string remainingValue2 = remainingValue1.ToString();
            string[] remainingValue = remainingValue2.Split(".");
            var hourValue1 = int.Parse(remainingValue[0]);
            string hour1 = hourValue1 + "h";
            var minValue1 = double.Parse(remainingValue[1]);
            minValue1 = Math.Round(minValue1, 0, MidpointRounding.AwayFromZero);
            var minute = minValue1 + "m";
            string remaining = hour1 + " " + minute;
            all_utilization_AvgProdLoss.Add("Remaining", remaining);

            return all_utilization_AvgProdLoss;
        }

        #endregion

        #region Error Kpi

        public static string GetNoRead(string errorKpi, string assetName, string asset, string env)
        {
            assetName = asset + assetName;
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) value as NoReadPercent from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName='" + errorKpi + "' and MetricField='Actual' and ReportingPeriod='Hourly' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("NoReadPercent"));
                            double number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                            number = number2.ToString("0.00");
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            if (number == "0.00%")
            {
                number = "0%";
            }
            return number;
        }
        public static string GetRecirculationRate(string errorKpi, string assetName, string asset, string env)
        {
            assetName = asset + assetName;
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) value as RecirculationPercent from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName='" + errorKpi + "' and MetricField='Actual' and ReportingPeriod='Hourly' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("RecirculationPercent"));
                            double number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                            number = number2.ToString("0.00");
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            if (number == "0.00%")
            {
                number = "0%";
            }
            return number;
        }
        public static string GetGappingError(string errorKpi, string assetName, string asset, string env)
        {
            assetName = asset + assetName;
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) value as GappingError from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName='" + errorKpi + "' and MetricField='Actual' and ReportingPeriod='Hourly' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("GappingError"));
                            double number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                            number = number2.ToString("0.00");
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            if (number == "0.00%")
            {
                number = "0%";
            }
            return number;
        }
        public static string GetTrackingError(string errorKpi, string assetName, string asset, string env)
        {
            assetName = asset + assetName;
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) value as trackingError from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName='" + errorKpi + "' and MetricField='Actual' and ReportingPeriod='Hourly' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("trackingError"));
                            double number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                            number = number2.ToString("0.00");
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            if (number == "0.00%")
            {
                number = "0%";
            }
            return number;
        }
        public static string GetFullLane(string errorKpi, string assetName, string asset, string env)
        {
            assetName = asset + assetName;
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) value as LaneAvailablePercent from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName='" + errorKpi + "' and MetricField='Actual' and ReportingPeriod='Hourly' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("LaneAvailablePercent"));
                            double number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                            number = number2.ToString("0.00");
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            if (number == "0.00%")
            {
                number = "0%";
            }
            return number;
        }

        #endregion

        #region AssetDownTime Shipping Dashboard

        public static string GetAssetDowntime_ShippingDAshboard(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Shipping";
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as AssetDownTimevalue from MetricHistoryValues where Assetname= '" + assetName + "' and MetricName = 'Downtime' and ReportingPeriod = '" + shift_daily + "' order by Timestamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("AssetDownTimevalue"));
                            number1 = number1 * 60;
                        }
                        reader.Close();
                    }
                }
            }

            number1 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
            if (number1 > 60)
            {
                var hours = Math.Floor(number1 / 60);
                var minutes = number1 % 60;

                return hours.ToString() + " H" + " : " + minutes.ToString() + " M";
            }
            else
            {
                return number1.ToString() + " M";
            }

        }
        public static string GetAssetDowntime_ShiipingDashboard(string assetName, string shift_daily, string env)
        {
            string _assetDownTime;
            _assetDownTime = GetAssetDowntime_ShippingDAshboard(assetName, shift_daily, env);
            return _assetDownTime;
        }

        #endregion

        #region Avg Throughput

        public static string GetAvgThroughput(string shipping, string assetName, string shift_daily, string env)
        {
            shipping = assetName + shipping;
            string number = "";
            var conn = SQLConnection(env);
            string AvgThroughput_Actual = @"select top(1) Value as AvgThroughput_value from MetricHistoryValues where AssetName = '" + shipping + "' and MetricName = 'ShippingThroughput' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(AvgThroughput_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("AvgThroughput_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = number2.ToString();
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            return number;
        }
        public static string GetCartonsPerMinPeakValue(string shipping, string assetName, string shift_daily, string env)
        {
            shipping = assetName + shipping;
            string number = "";
            var conn = SQLConnection(env);
            string CPM_Actual = @"select top(1) Value as CPM_value from MetricHistoryValues where AssetName = '" + shipping + "' and MetricName = 'RatedCPM' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(CPM_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("CPM_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = number2.ToString();
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }
        #endregion

        #region Shipping Lanes

        public static Dictionary<string, string> GetkpivaluesForSorter(string assetname, string shift_daily, string env)
        {
            Dictionary<string, string> all_sorterline = new Dictionary<string, string>();
            all_sorterline.Clear();
            List<double> list = new List<double>();

            var conn = SQLConnection(env);

            if (assetname.Contains(","))
            {
                var assetNames = assetname.Split(",");
                for (int i = 0; i < assetNames.Length; i++)
                {
                    list.Clear();
                    string assetName = assetNames[i];
                    string totalabort_val2;

                    string status_value = @"select top(1) value as Status from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'AssetStatus' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by timestamp desc";
                    string totalabort_val1 = @"select top(1) value as Val1 from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'TotalDiverts' and MetricField = 'Actual' and  ReportingPeriod = '" + shift_daily + "' order by timestamp desc";
                    if (assetName.Contains("DC3UpperSortLane"))
                        totalabort_val2 = @"select top(1) value as Val2 from MetricHistoryValues where AssetName = 'DC3UpperShipping' and MetricName = 'TotalDiverts' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by timestamp desc";
                    else
                        totalabort_val2 = @"select top(1) value as Val2 from MetricHistoryValues where AssetName = 'DC3LowerShipping' and MetricName = 'TotalDiverts' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by timestamp desc";
                    string abort_value = @"select top(1) Value as Aborts from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'TotalAborts' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
                    string throughput_value = @"select top(1) Value as Throughput from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ShippedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

                    SqlCommand status = new SqlCommand(status_value, conn);
                    SqlCommand totalabort1 = new SqlCommand(totalabort_val1, conn);
                    SqlCommand totalabort2 = new SqlCommand(totalabort_val2, conn);
                    SqlCommand abort = new SqlCommand(abort_value, conn);
                    SqlCommand throughput = new SqlCommand(throughput_value, conn);

                    status.ExecuteNonQuery();
                    totalabort1.ExecuteNonQuery();
                    totalabort2.ExecuteNonQuery();
                    abort.ExecuteNonQuery();
                    throughput.ExecuteNonQuery();

                    using (SqlDataReader reader1 = status.ExecuteReader())
                    {
                        while (reader1.Read())
                        {
                            double status1 = reader1.GetDouble(reader1.GetOrdinal("Status"));
                            status1 = Math.Round(status1, 0, MidpointRounding.AwayFromZero);
                            string status2 = returnAppropirateString(status1);
                            all_sorterline.Add(++i + "STATUS", status2);
                            reader1.Close();
                            break;
                        }
                    }

                    using (SqlDataReader reader21 = totalabort1.ExecuteReader())
                    {
                        while (reader21.Read())
                        {
                            double val1 = reader21.GetDouble(reader21.GetOrdinal("Val1"));
                            val1 = Math.Round(val1, 0, MidpointRounding.AwayFromZero);
                            list.Add(val1);
                            reader21.Close();
                            break;
                        }
                    }

                    using (SqlDataReader reader22 = totalabort2.ExecuteReader())
                    {
                        while (reader22.Read())
                        {
                            double val2 = reader22.GetDouble(reader22.GetOrdinal("Val2"));
                            val2 = Math.Round(val2, 0, MidpointRounding.AwayFromZero);
                            double val = (list[0] / val2) * 100;
                            val = Math.Round(val, 0, MidpointRounding.AwayFromZero);
                            string volume = val + "";
                            if (volume.Contains("NaN"))
                            {
                                volume = volume.Replace("NaN", "--");
                            }
                            volume = volume + "%";
                            all_sorterline.Add(i + "VOLUME", volume);
                            reader22.Close();
                            break;
                        }
                    }

                    using (SqlDataReader reader3 = abort.ExecuteReader())
                    {
                        while (reader3.Read())
                        {
                            double abort1 = reader3.GetDouble(reader3.GetOrdinal("Aborts"));
                            abort1 = Math.Round(abort1, 0, MidpointRounding.AwayFromZero);
                            string abort2 = abort1.ToString();
                            all_sorterline.Add(i + "ABORTS", abort2);
                            reader3.Close();
                            break;
                        }
                    }

                    using (SqlDataReader reader2 = throughput.ExecuteReader())
                    {
                        while (reader2.Read())
                        {
                            double throughput1 = reader2.GetDouble(reader2.GetOrdinal("Throughput"));
                            throughput1 = Math.Round(throughput1, 0, MidpointRounding.AwayFromZero);
                            string throughput2 = throughput1.ToString();
                            all_sorterline.Add(i-- + "THROUGHPUT", throughput2);
                            reader2.Close();
                            break;
                        }
                    }
                }
            }
            return all_sorterline;
        }

        #endregion

        #region Delete Data
        public int DeleteDataForEventDataAPI()
        {
            string dbConnection = "server=;user=;password=";

            int numOfRows = 0;

            SqlConnection conn = new SqlConnection(dbConnection);
            conn.Open();

            string strQuery = @"Delete from ActiveFaultHistoriesV2 where Description like '%SIT_TESTDATA%'";
            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            numOfRows = sqlCmd.ExecuteNonQuery();
            int originalRowsDeleted = numOfRows - 1;
            Console.WriteLine("No of rows deleted is : " + originalRowsDeleted);
            conn.Close();

            return numOfRows;

        }

        #endregion

        #region AssetDashboard

        public static Dictionary<string, string> AssetDahboardvalues(string assetName, string duration, string env)
        {
            //string dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit1;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";
            //SqlConnection conn = new SqlConnection(dbConnection);
            //conn.Open();

            var conn = SQLConnection(env);

            Dictionary<string, string> AssetHealthScore = new Dictionary<string, string>();

            /*string strAssetQuery = @"select value from MetricHistoryValues

                                    where AssetName = 'FCC101' and MetricName = 'OEE' and MetricField = 'Actual' and ReportingPeriod = 'Daily'

                                    order by TimeStamp desc";*/
            if (duration == "Current  Shift")
            {
                duration = "Shift";
            }
            else if (duration == "Current Day")
            {
                duration = "Daily";
            }
            else if (duration == "Current Month")
            {
                duration = "Monthly";
            }


            string OEEQry = @"select top(1) Value as OEE from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'OEE' and MetricField = 'Actual' and ReportingPeriod = '" + duration + "' order by TimeStamp desc";

            string avlabtyqry = @"select top(1) Value as Availability from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Availability' and MetricField = 'Actual' and ReportingPeriod = '" + duration + "' order by TimeStamp desc";

            string qltyquery = @"select top(1) Value as Quality from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Quality' and MetricField = 'Actual' and ReportingPeriod = '" + duration + "'  order by TimeStamp desc";

            string perfqry = @"select top(1) Value as Performance from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Performance' and MetricField = 'Actual' and ReportingPeriod = '" + duration + "' order by TimeStamp desc";

            //SqlCommand cmdAsset = new SqlCommand(strAssetQuery, conn);

            SqlCommand cmdOEE = new SqlCommand(OEEQry, conn);
            SqlCommand cmdavailability = new SqlCommand(avlabtyqry, conn);
            SqlCommand cmdqlty = new SqlCommand(qltyquery, conn);
            SqlCommand cmdperf = new SqlCommand(perfqry, conn);
            //cmdAsset.ExecuteNonQuery();

            cmdOEE.ExecuteNonQuery();
            cmdavailability.ExecuteNonQuery();
            cmdqlty.ExecuteNonQuery();
            cmdperf.ExecuteNonQuery();

            /* using (SqlDataReader reader = cmdAsset.ExecuteReader())
             {
                 while (reader.Read())

                 {
                     Console.WriteLine("{0}", reader.GetDouble(0));
                     AssetHealthScore.Add("Asset Header Values", reader.GetDouble(0).ToString());
                     reader.Close();
                     break;
                 }

             }*/
            //using (SqlDataReader reader2 = cmdAsset.ExecuteReader())
            //{
            /*{
                while (reader2.Read())

                {
                    Console.WriteLine("{0}", reader2.GetDouble(0));
                    AssetHealthScore.Add("Assetoverall", reader2.GetDouble(0).ToString());
                    reader2.Close();

                    break;
                }

            }*/
            using (SqlDataReader reader3 = cmdOEE.ExecuteReader())
            {
                while (reader3.Read())
                {
                    Console.WriteLine("{0}", reader3.GetDouble(0));
                    //AssetHealthScore.Add("OEE", reader3.GetDouble(0).ToString());
                    double oee = reader3.GetDouble(reader3.GetOrdinal("OEE"));
                    oee = Math.Round(oee, 0, MidpointRounding.AwayFromZero);
                    string oee1 = oee.ToString();
                    oee1 = oee1 + "%";
                    AssetHealthScore.Add("OEE", oee1);
                    reader3.Close();
                    break;
                }
            }

            using (SqlDataReader reader4 = cmdavailability.ExecuteReader())
            {
                while (reader4.Read())
                {
                    /*Console.WriteLine("{0}", reader4.GetDouble(0));
                    AssetHealthScore.Add("Availability", reader4.GetDouble(0).ToString());
                    reader4.Close();
                    break;*/
                    double availability = reader4.GetDouble(reader4.GetOrdinal("Availability"));
                    availability = Math.Round(availability, 0, MidpointRounding.AwayFromZero);
                    string availability1 = availability.ToString();
                    availability1 = availability1 + "%";
                    AssetHealthScore.Add("Availability", availability1);
                    reader4.Close();
                    break;
                }
            }

            using (SqlDataReader reader5 = cmdqlty.ExecuteReader())
            {
                while (reader5.Read())
                {
                    /* Console.WriteLine("{0}", reader5.GetDouble(0));
                     AssetHealthScore.Add("Quality", reader5.GetDouble(0).ToString());
                     reader5.Close();
                     break;*/
                    double quality = reader5.GetDouble(reader5.GetOrdinal("Quality"));
                    quality = Math.Round(quality, 0, MidpointRounding.AwayFromZero);
                    string quality1 = quality.ToString();
                    quality1 = quality1 + "%";
                    AssetHealthScore.Add("Quality", quality1);
                    reader5.Close();
                    break;
                }
            }

            using (SqlDataReader reader6 = cmdperf.ExecuteReader())
            {
                while (reader6.Read())
                {
                    /*Console.WriteLine("{0}", reader6.GetDouble(0));
                    AssetHealthScore.Add("Performance", reader6.GetDouble(0).ToString());
                    reader6.Close();
                    break;*/
                    double performance = reader6.GetDouble(reader6.GetOrdinal("Performance"));
                    performance = Math.Round(performance, 0, MidpointRounding.AwayFromZero);
                    string performance1 = performance.ToString();
                    performance1 = performance1 + "%";
                    AssetHealthScore.Add("Performance", performance1);
                    reader6.Close();
                    break;
                }

            }
            return AssetHealthScore;
        }

        public static double GetUtilizationValue(string assetName, string ReportingPeriod, string KPIName, string env)
        {
            double number2 = 0.0; ;
            var conn = SQLConnection(env);
            string strQuery = @"select TOP(1) value as UtilizationValue from MetricHistoryValues
                                where AssetName = '" + assetName + "' and MetricName = '" + KPIName + "' and ReportingPeriod = '" + ReportingPeriod + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("UtilizationValue"));
                            number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static double GetEnergyValue(string assetName, string ReportingPeriod, string KPIName, string env)
        {
            double number2 = 0.0; ;
            var conn = SQLConnection(env);
            string strQuery = @"select TOP(1) value as EnergyValue from MetricHistoryValues
                                where AssetName = '" + assetName + "' and MetricName = '" + KPIName + "' and ReportingPeriod = '" + ReportingPeriod + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("EnergyValue"));
                            number2 = Math.Round(number1, 2, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static double GetUptimeValue(string assetName, string ReportingPeriod, string KPIName, string env)
        {
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string strQuery = @"select TOP(1) value as UptimeValue from MetricHistoryValues
                                where AssetName = '" + assetName + "' and MetricName = '" + KPIName + "' and ReportingPeriod = '" + ReportingPeriod + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("UptimeValue"));
                            number2 = Math.Round(number1, 4, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static double GetKeyKPIValues(string assetName, string ReportingPeriod, string KPIName, string env)
        {
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string strQuery = @"select TOP(1) AssetName, MetricName, Value from MetricHistoryValues
                                where AssetName = '" + assetName + "' and MetricName = '" + KPIName + "' and ReportingPeriod = '" + ReportingPeriod + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Value"));
                            number2 = Math.Round(number1, 4, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }

        #endregion

        #region Picking Dashboard

        #region Order Quota Picking Dashboard

        /*public static string GetOrderQuota_KPI(string assetName, string shift_daily)
        {
            string number = "";
            var conn = SQLConnection();
            string strQuery = @"select Top(1) TargetOverride as DailyShippedCartonsKPITarget from KpiTargetConfigurations where AssetKPIConfigurationId in (Select AssetKPIConfigurationId from AssetKPIConfigurations where KPI in ('ShippedCartons') and ReportingPeriod = '" + shift_daily + "') order by EffectiveDate desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("DailyShippedCartonsKPITarget"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            return number;
        }*/

        public static string GetOrderQuota_PickingDAshboard(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as DailyOrderQuota from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("DailyOrderQuota"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            return number;
        }
        /* public static string GetVerifyOrderQuota_PickingDashboard(string assetName, string shift_daily)
         {
             string OrderQuotaKPI = GetOrderQuota_KPI(assetName, shift_daily);
             string OrderQuota = GetOrderQuota(assetName, shift_daily);
             if (shift_daily == "Daily")
             {
                 Assert.IsTrue(OrderQuotaKPI.Equals(OrderQuota), $"The expected string: '{OrderQuota}' is not matched with actual string: '{OrderQuotaKPI}'");
             }
             return OrderQuota;
         }*/

        #endregion

        #region Current/Plan Picking Dashboard

        public static double GetShippedcartons_target_PickingDashboard(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartons_Target = @"select top(1) Value as ShippedCartonsTarget from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartons_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("ShippedCartonsTarget"));
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetShippedcartons_Actual_PickingDashboard(string assetName, string shift_daily, string env)
        {
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string ShippedCartons_Actual = @"select top(1) Value as ShippedCartonsActual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(ShippedCartons_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("ShippedCartonsActual"));
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static string GetCurrentPlan_PickingDashboard(string assetName, string shift_daily, string env)
        {
            string number;
            double number3 = GetShippedcartons_Actual_PickingDashboard(assetName, shift_daily, env) / GetShippedcartons_target_PickingDashboard(assetName, shift_daily, env);
            number3 = number3 * 100;
            double value2 = Math.Round(number3, 0, MidpointRounding.AwayFromZero);
            number = value2.ToString();
            number = number + ("%");
            number = number.Trim();
            return number;
        }

        #endregion

        #region Picked Picking Dashboard
        public static string GetPickededOrderQuota_PickingDashboard(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Picking";
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as Pickedvalue from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Pickedvalue"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("K");
            number = number.Trim();
            return number;
        }

        #endregion

        #region AssetDownTime Quota Picking Dashboard

        public static string GetAssetDowntime_PickingDashboard(string assetName, string shift_daily, string env)
        {
            assetName = "DC3Picking";
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as AssetDownTimevalue from MetricHistoryValues where Assetname= '" + assetName + "' and MetricName = 'Downtime' and ReportingPeriod = '" + shift_daily + "' order by Timestamp desc";
            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("AssetDownTimevalue"));
                            number1 = number1 * 60;
                        }
                        reader.Close();
                    }
                }
            }

            number1 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
            if (number1 > 60)
            {
                var hours = Math.Floor(number1 / 60);
                var minutes = number1 % 60;

                return hours.ToString() + " H" + " : " + minutes.ToString() + " M";
            }
            else
            {
                return number1.ToString() + " M";
            }
        }
        public static string GetAssetDowntimeOrderQuota_PickingDashboard(string assetName, string shift_daily, string env)
        {
            string _assetDownTime;
            _assetDownTime = GetAssetDowntime_PickingDashboard(assetName, shift_daily, env);
            return _assetDownTime;
        }

        #endregion

        #region Status

        public static double GetPickedcartonRateForStatus_target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartonsStatus_Target = @"select top(1) Value as ExpectedValue_Target from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartonRate' and MetricField = 'Target' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsStatus_Target, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("ExpectedValue_Target"));

                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double GetPickedcartonsForStatus_Actual(string assetName, string shift_daily, string env)
        {
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartons_Actual = @"select top(1) Value as ExpectedValue_Actual from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'PickedCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartons_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("ExpectedValue_Actual"));

                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static string GetStatusForPickModule(string assetName, string shift_daily, string env)
        {
            double result_target;
            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (GetPickedcartonRateForStatus_target(assetName, shift_daily, env) * time_elapsed);
                result_target = Math.Round(result_target, 1, MidpointRounding.AwayFromZero);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (GetPickedcartonRateForStatus_target(assetName, shift_daily, env) * time_elapsed);
                result_target = Math.Round(result_target, 1, MidpointRounding.AwayFromZero);
            }
            double result_actual = GetPickedcartonsForStatus_Actual(assetName, shift_daily, env);
            result_actual = Math.Round(result_actual, 1, MidpointRounding.AwayFromZero);

            double numerator = (result_actual - result_target);
            double denomenator = result_target;

            var difference = (numerator / denomenator) * 100;
            if (difference >= -5 && difference <= 5)
            {
                return "ON TIME";
            }
            else if (difference > 5)
            {
                return "AHEAD";
            }
            else if (difference < 5)
            {
                return "BEHIND";
            }
            else
            {
                return "difference value is not existing in this condition";
            }
        }

        #endregion

        #region Efficiency

        public static double PickedCartonsRateForEfficiency_Target(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartonRate_TargetValue = @"select top(1) value as PickedCartonRate_Target from MetricHistoryValues where AssetName like '" + assetName + "' and MetricName = 'PickedCartonRate' and ReportingPeriod = '" + shift_daily + "' and MetricField = 'Target' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(PickedCartonRate_TargetValue, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("PickedCartonRate_Target"));
                            number1 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static double PickedCartonsForEfficiency_Actual(string assetName, string shift_daily, string env)
        {
            double number2 = 0.0;
            var conn = SQLConnection(env);
            string pickedCartons_ActualValue = @"select top(1) value as PickedCartons from MetricHistoryValues where AssetName like '" + assetName + "' and MetricName = 'PickedCartons' and ReportingPeriod = '" + shift_daily + "' and MetricField = 'Actual' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(pickedCartons_ActualValue, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number2 = reader.GetDouble(reader.GetOrdinal("PickedCartons"));
                        }
                        reader.Close();
                    }
                }
            }
            return number2;
        }
        public static string GetEfficiencyForPickingDashboard(string assetName, string shift_daily, string env)
        {
            double result_target;
            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (PickedCartonsRateForEfficiency_Target(assetName, shift_daily, env) * time_elapsed);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (PickedCartonsRateForEfficiency_Target(assetName, shift_daily, env) * time_elapsed);
            }
            double result_actual = PickedCartonsForEfficiency_Actual(assetName, shift_daily, env);
            double number3 = (result_actual / result_target) * 100;
            number3 = Math.Round(number3, 0, MidpointRounding.AwayFromZero);
            string number4 = number3.ToString();
            number4 = number4 + ("%");
            return number4;
        }

        #endregion

        #region Throughput

        public static string GetThroughputForPickingDashboard(string assetName, string shift_daily, string env)//here assetName = DC3PickMod1 just change it
        {
            double result_target;
            var time_elapsed = ElapsedTime(env);
            if (shift_daily == "Daily")
            {
                result_target = (PickedCartonsRateForEfficiency_Target(assetName, shift_daily, env) * time_elapsed) / 1000;
                result_target = Math.Round(result_target, 1, MidpointRounding.AwayFromZero);
            }
            else
            {
                if (time_elapsed > 0 && time_elapsed <= 8)
                {
                    time_elapsed = time_elapsed - 0;
                }
                else if (time_elapsed > 8 && time_elapsed <= 16)
                {
                    time_elapsed = time_elapsed - 8;
                }
                else
                {
                    time_elapsed = time_elapsed - 16;
                }
                result_target = (PickedCartonsRateForEfficiency_Target(assetName, shift_daily, env) * time_elapsed) / 1000;
                result_target = Math.Round(result_target, 1, MidpointRounding.AwayFromZero);
            }
            double result_actual = PickedCartonsForEfficiency_Actual(assetName, shift_daily, env) / 1000;
            result_actual = Math.Round(result_actual, 1, MidpointRounding.AwayFromZero);
            string actual_result = result_actual.ToString("0.0");
            string target_result = result_target.ToString("0.0");
            string throughput = (actual_result + " / " + target_result) + " K";
            return throughput;
        }

        #endregion

        #region RATE/HR

        public static double PickedCartonsRateForEfficiency_Actual(string assetName, string shift_daily, string env)
        {
            double number1 = 0.0;
            var conn = SQLConnection(env);
            string PickedCartonRate_ActualValue = @"select top(1) value as PickedCartonRate_Actual from MetricHistoryValues where AssetName like '" + assetName + "' and MetricName = 'PickedCartonRate' and ReportingPeriod = '" + shift_daily + "' and MetricField = 'Actual' order by TimeStamp desc";
            using (SqlCommand cmd = new SqlCommand(PickedCartonRate_ActualValue, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            number1 = reader.GetDouble(reader.GetOrdinal("PickedCartonRate_Actual"));
                            number1 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                        }
                        reader.Close();
                    }
                }
            }
            return number1;
        }
        public static string GetRate_HrForPickingDashboard(string assetName, string shift_daily, string env)
        {
            var actual = PickedCartonsRateForEfficiency_Actual(assetName, shift_daily, env) / 1000;
            actual = Math.Round(actual, 1, MidpointRounding.AwayFromZero);
            string actual_stringFormat = actual.ToString("0.0");
            var target = PickedCartonsRateForEfficiency_Target(assetName, shift_daily, env) / 1000;
            string target_stringFormat = target.ToString("0.0");
            string rate_hr = (actual_stringFormat + " / " + target_stringFormat) + "  K";
            return rate_hr;
        }

        #endregion

        #region Asset Utilization

        public static Dictionary<string, string> AssetUtilizationValue(string assetName, string shift_daily, string env)
        {
            var todaydate = tym();
            var conn = SQLConnection(env);
            double remainingValue1 = 0.0;

            Dictionary<string, string> assetUtilize = new Dictionary<string, string>();
            assetUtilize.Clear();
            IList<double> totalTime = new List<double>();

            string downtime_value = @"select top(1) Value as Downtime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Downtime' and ReportingPeriod = '" + shift_daily + "' and TimeStamp >'" + todaydate + "T08:00:00' order by TimeStamp desc";
            string energyoff_value = @"select top(1) Value as EnergyOff from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'EnergyOff' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string hundreadfull_value = @"select top(1) Value as FullTime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Uptime' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";
            string uptime_value = @"select top(1) Value as Uptime from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Uptime' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            SqlCommand downTime = new SqlCommand(downtime_value, conn);
            SqlCommand energyOff = new SqlCommand(energyoff_value, conn);
            SqlCommand fullTime = new SqlCommand(hundreadfull_value, conn);
            SqlCommand upTime = new SqlCommand(uptime_value, conn);

            downTime.ExecuteNonQuery();
            energyOff.ExecuteNonQuery();
            fullTime.ExecuteNonQuery();
            upTime.ExecuteNonQuery();

            using (SqlDataReader reader1 = downTime.ExecuteReader())
            {
                while (reader1.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double downtime2 = reader1.GetDouble(reader1.GetOrdinal("Downtime"));
                    string downtime1 = downtime2.ToString();
                    string[] downtimeValue = downtime1.Split(".");
                    var hourValue = int.Parse(downtimeValue[0]);
                    string hour = hourValue + "h";

                    if (downtime2 != 0)
                    {
                        var minvalue = (downtime2 - hourValue) * 60;
                        var downtime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = downtime;
                        minutes = downtime + "m";
                    }

                    string DownTime = hour + " " + minutes;
                    var hrMinValue1 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    assetUtilize.Add("Downtime", DownTime);
                    reader1.Close();
                    break;
                }
            }

            using (SqlDataReader reader3 = energyOff.ExecuteReader())
            {
                while (reader3.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double energyoff2 = reader3.GetDouble(reader3.GetOrdinal("EnergyOff"));
                    string energyoff1 = energyoff2.ToString();
                    string[] energyoffValue = energyoff1.Split(".");
                    var hourValue = int.Parse(energyoffValue[0]);
                    string hour = hourValue + "h";

                    if (energyoff2 != 0)
                    {
                        var minvalue = (energyoff2 - hourValue) * 60;
                        var energyoff = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = energyoff;
                        minutes = energyoff + "m";
                    }

                    string EnergyOff = hour + " " + minutes;
                    var hrMinValue3 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    assetUtilize.Add("Energy Off", EnergyOff);
                    reader3.Close();
                    break;
                }
            }

            using (SqlDataReader reader4 = fullTime.ExecuteReader())
            {
                while (reader4.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double fulltime2 = reader4.GetDouble(reader4.GetOrdinal("FullTime"));
                    string fulltime1 = fulltime2.ToString();
                    string[] fulltimeValue = fulltime1.Split(".");
                    var hourValue = int.Parse(fulltimeValue[0]);
                    string hour = hourValue + "h";

                    if (fulltime2 != 0)
                    {
                        var minvalue = (fulltime2 - hourValue) * 60;
                        var fulltime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = fulltime;
                        minutes = fulltime + "m";
                    }

                    string FullTime = hour + " " + minutes;
                    var hrMinValue4 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    assetUtilize.Add("100% Full", FullTime);
                    reader4.Close();
                    break;
                }
            }

            using (SqlDataReader reader5 = upTime.ExecuteReader())
            {
                while (reader5.Read())
                {
                    string minutes = "0m";
                    double minValue = 0.0;
                    double uptime2 = reader5.GetDouble(reader5.GetOrdinal("Uptime"));
                    string uptime1 = uptime2.ToString();
                    string[] uptimeValue = uptime1.Split(".");
                    var hourValue = int.Parse(uptimeValue[0]);
                    string hour = hourValue + "h";

                    if (uptime2 != 0)
                    {
                        var minvalue = (uptime2 - hourValue) * 60;
                        var uptime = Math.Round(minvalue, 0, MidpointRounding.AwayFromZero);
                        minValue = uptime;
                        if (minValue == 60)
                        {
                            minvalue = 1;
                            hourValue = (int)(hourValue + minvalue);
                            hour = hourValue + "h";
                            uptime = 0;
                        }
                        minutes = uptime + "m";
                    }

                    string UpTime = hour + " " + minutes;
                    var hrMinValue5 = hourValue + minValue;
                    totalTime.Add(hourValue);
                    totalTime.Add(minValue);
                    assetUtilize.Add("Uptime", UpTime);
                    reader5.Close();
                    break;
                }
            }



            var totalHM1 = (totalTime[0] + totalTime[2] + totalTime[4] + totalTime[6]);//hour addition after split hr,min
            var totalHM32 = (totalTime[1] + totalTime[3] + totalTime[5] + totalTime[7]);//min addition


            //when min value will be more then 60 then we need to use below condition
            if (totalHM32 >= 60 && totalHM32 < 120)
            {
                var min = totalHM32 - 60;
                var hour = (totalHM32 - min) / 60;
                var hour2 = hour.ToString();
                var value1 = hour2 + "." + min;//1.101
                totalHM32 = double.Parse(value1);//1.101
            }
            else if (totalHM32 >= 120 && totalHM32 < 240)
            {
                var min = totalHM32 - 120;
                var hour = (totalHM32 - min) / 60;
                var hour2 = hour.ToString();
                var value1 = hour2 + "." + min;
                totalHM32 = double.Parse(value1);
            }
            else
            {
                var value2 = "." + totalHM32;
                totalHM32 = double.Parse(value2);
            }

            var total_final = totalHM1 + totalHM32;
            total_final = Math.Round(total_final, 2, MidpointRounding.AwayFromZero);

            //DecimalFormat Numformat = new DecimalFormat("##.##");
            //string num = Numformat.Format(total_final);
            //total_final = Double.Parse(num);

            if (shift_daily == "Daily")
            {
                remainingValue1 = (23.60) - (total_final);
                remainingValue1 = Math.Round(remainingValue1, 2, MidpointRounding.AwayFromZero);
            }
            else if (shift_daily == "Shift")
            {
                remainingValue1 = (7.60) - (total_final);
                remainingValue1 = Math.Round(remainingValue1, 2, MidpointRounding.AwayFromZero);
            }
            string remainingValue2 = remainingValue1.ToString();
            string[] remainingValue = remainingValue2.Split(".");
            var hourValue1 = int.Parse(remainingValue[0]);
            string hour1 = hourValue1 + "h";
            var minValue1 = double.Parse(remainingValue[1]);
            minValue1 = Math.Round(minValue1, 0, MidpointRounding.AwayFromZero);
            var minute = minValue1 + "m";
            string remaining = hour1 + " " + minute;
            assetUtilize.Add("Time Remaining", remaining);

            return assetUtilize;
        }

        #endregion

        #endregion

        #region Panda Dashboard

        #region Error Kpi's
        public static string GetMislabeledError_ErrorKpi(string assetName, string shift_daily, string env)
        {
            shift_daily = "Hourly";
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as MislabeledErrors_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'MislabeledErrors' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("MislabeledErrors_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            return number;
        }
        public static string GetTrackingError_ErrorKpi(string assetName, string shift_daily, string env)
        {
            shift_daily = "Hourly";
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as MistrackPercent_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'MistrackPercent' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("MistrackPercent_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            return number;
        }
        public static string GetScannerError_ErrorKpi(string assetName, string shift_daily, string env)
        {
            shift_daily = "Hourly";
            string number = "";
            var conn = SQLConnection(env);

            string PickedCartonsRate_Actual = @"select top(1) Value as ScannerErrorPercent_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ScannerErrorPercent' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("ScannerErrorPercent_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            number = number + ("%");
            return number;
        }

        #endregion

        #region Productivity Kpi's

        public static string GetTotalCartons_ProductivityKpi(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as TotalCartons_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'TotalCartons' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("TotalCartons_value"));
                            number1 = number1 * (.001);
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }
            if (number != "0.0")
            {
                number = number + ("K");
            }
            else
            {
                number = number;
            }

            return number;
        }
        public static string GetTotalRejects_ProductivityKpi(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as Rejects_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Rejects' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Rejects_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }

            return number;
        }
        public static string GetAverageCartonLength_ProductivityKpi(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as AvgCartonLength_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'AvgCartonLength' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("AvgCartonLength_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }

            return number;
        }
        public static string GetActiveLabelers_ProductivityKpi(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string strQuery = @"select top(1) Value as ActiveLabelers_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'ActiveLabelers' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(strQuery, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("ActiveLabelers_value"));
                            double number2 = Math.Round(number1, 1, MidpointRounding.AwayFromZero);
                            number = conditionalStatment(number2);
                        }
                        reader.Close();
                    }
                }
            }

            return number;
        }

        #endregion

        #region Panda Lanes
        public static string GetThroughput_PandaLane(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as Throughput_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Throughput' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Throughput_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }
        public static string GetReject_PandaLane(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as Rejects_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Rejects' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("Rejects_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }
        public static string GetScannerErrors_PandaLane(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as ScannerErrors_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'TotalScannerErrors' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("ScannerErrors_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }
        public static string GetTrackingErrors_PandaLane(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as TrackingError_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'Mistracks' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("TrackingError_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }
        public static string GetLabelsPrinted_PandaLane(string assetName, string shift_daily, string env)
        {
            string number = "";
            var conn = SQLConnection(env);
            string PickedCartonsRate_Actual = @"select top(1) Value as LabelsPrinted_value from MetricHistoryValues where AssetName = '" + assetName + "' and MetricName = 'LabelsPrinted' and MetricField = 'Actual' and ReportingPeriod = '" + shift_daily + "' order by TimeStamp desc";

            using (SqlCommand cmd = new SqlCommand(PickedCartonsRate_Actual, conn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            double number1 = reader.GetDouble(reader.GetOrdinal("LabelsPrinted_value"));
                            double number2 = Math.Round(number1, 0, MidpointRounding.AwayFromZero);
                            number = conditionalStatment1(number2);
                        }
                        reader.Close();
                    }
                }
            }
            return number;
        }

        #endregion

        #endregion

    }
}



