﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace AutomationFramework
{
    public class TokenDetail
    {
        [JsonProperty("access_token")]
        public string AccessToken { get; set; }

        [JsonProperty("expires_in")]
        public long ExpiresIn { get; set; }

        [JsonProperty("expires_on")]
        public long ExpiresOn { get; set; }

        public DateTimeOffset? ExpiresAt
        {
            get
            {
                if (ExpiresOn != default(long))
                {
                    return DateTimeOffset.FromUnixTimeSeconds(ExpiresOn);
                }

                return null;
            }
        }

        public DateTimeOffset tokenTime = DateTimeOffset.UtcNow;
        public DateTimeOffset? ExpiresInTime
        {
            get
            {
                if (ExpiresIn != default(long))
                {
                    return tokenTime.AddSeconds(ExpiresIn);
                }

                return null;
            }
        }

        [JsonProperty("token_type")]
        public string Scope { get; set; }
    }

    public static class TokenHelper
    {
        public static async Task<TokenDetail> GenerateToken(string authUri, string clientId, string clientSecret, List<KeyValuePair<string, string>> additionalParams = null)
        {
            TokenDetail tokenDetail = null;
            using (var client = new HttpClient())
            {
                var baseUri = new Uri(authUri);
                var encodedConsumerKey = HttpUtility.UrlEncode(clientId);
                var encodedConsumerKeySecret = HttpUtility.UrlEncode(clientSecret);
                var encodedPair = Base64Encode(string.Format("{0}:{1}", encodedConsumerKey, encodedConsumerKeySecret));

                var formData = new List<KeyValuePair<string, string>>();
                formData.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));
                formData.Add(new KeyValuePair<string, string>("scope", "forge.access openid"));
                if (additionalParams != null && additionalParams.Any())
                {
                    formData.AddRange(additionalParams);
                }

                var requestToken = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(baseUri, "oauth2/token"),
                    Content = new FormUrlEncodedContent(formData)
                };

                requestToken.Content.Headers.ContentType = new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded") { CharSet = "UTF-8" };
                requestToken.Headers.TryAddWithoutValidation("Authorization", string.Format("Basic {0}", encodedPair));

                var bearerResponse = await client.SendAsync(requestToken).ConfigureAwait(false);
                await bearerResponse.Content.ReadAsStringAsync().ContinueWith((Task<string> x) =>
                {
                    if (x.IsFaulted)
                        throw x.Exception;

                    if (bearerResponse.IsSuccessStatusCode)
                    {
                        tokenDetail = JsonConvert.DeserializeObject<TokenDetail>(x.Result);
                    }
                    else
                    {
                        throw new HttpRequestException(bearerResponse.ReasonPhrase); 
                    }
                });
            }

            return tokenDetail;
        }

        private static string Base64Encode(string plainText)
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }

        private static bool TryParseJson<T>(string message, out T result)
        {
            bool success = true;
            var settings = new JsonSerializerSettings
            {
                Error = (sender, args) => { success = false; args.ErrorContext.Handled = true; },
            };
            result = JsonConvert.DeserializeObject<T>(message, settings);
            return success;
        }
    }
}
