﻿using AventStack.ExtentReports.Reporter;
using System;
using System.Collections.Generic;
using System.Text;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter.Configuration;
using System.IO;

namespace AutomationFramework
{
    public class Report
    {
        private static AventStack.ExtentReports.ExtentReports _extent;
        private static ExtentTest _feature;
        private static ExtentTest _scenario;
        public static int Reporter(string path)
        {
            try
            {
                var reporter = new ExtentHtmlReporter(path);
                _extent = new AventStack.ExtentReports.ExtentReports();
                _extent.AttachReporter(reporter);
                _extent.AddSystemInfo("OS", "");
                _extent.AddSystemInfo("Browser", "");

                reporter.Config.Theme = Theme.Standard;
                _extent.CreateTest<Feature>("Create_Batch");
                _extent.Flush();
            }

            catch (Exception ex)
            {
                return -1;
            }

            return 9;
        }


    }
}
