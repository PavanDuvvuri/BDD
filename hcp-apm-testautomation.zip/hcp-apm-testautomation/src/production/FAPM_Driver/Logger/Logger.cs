﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace Logging
{
    public class Logger : ILogger
    {
        private readonly NLog.Logger _nLogger;
  
        public Logger(Type type)
        {
            if (type != null)
            {
                this._nLogger = LogManager.GetLogger(type.FullName);
           }
        }

        public void Fatal(string message, params object[] values)
        {
            this._nLogger.Fatal(GetFormattedMessage(message, values));
        }

        public void Fatal(Exception exception, string message, params object[] values)
        {
            _nLogger.Fatal(GetFormattedMessage(message, values), exception);
        }

        public void Error(string message, params object[] values)
        {
            this._nLogger.Error(GetFormattedMessage(message, values));
        }

        public void Error(Exception exception, string message, params object[] values)
        {
            _nLogger.ErrorException(GetFormattedMessage(message, values), exception);
        }

        public void Warn(string message, params object[] values)
        {
            this._nLogger.Warn(GetFormattedMessage(message, values));
        }

        public void Warn(System.Exception exception, string message, params object[] values)
        {
            _nLogger.WarnException(GetFormattedMessage(message, values), exception);
        }

        public void Debug(string message, params object[] values)
        {
            this._nLogger.Debug(CultureInfo.InvariantCulture, message, values);
        }

        public void Info(string message, params object[] values)
        {
            this._nLogger.Info(CultureInfo.InvariantCulture, message, values);
        }

        public bool IsDebugEnabled
        {
            get { return this._nLogger.IsDebugEnabled; }
        }

        public bool IsInfoEnabled
        {
            get { return this._nLogger.IsInfoEnabled; }
        }

        private static string GetFormattedMessage(string message, object[] values)
        {
            if (values != null)
            {
                return string.Format(CultureInfo.InvariantCulture, message, values);
            }

            return string.Empty;
        }
    }
}
