﻿using System;
using System.Collections.Generic;
using System.Text;
using JetBrains.Annotations;

namespace Logging
{
    public interface ILogger
    {
        [StringFormatMethod("message")]
        void Fatal(string message, params object[] values);

        [StringFormatMethod("message")]
        void Fatal(Exception exception, string message, params object[] values);

        [StringFormatMethod("message")]
        void Error(string message, params object[] values);

        [StringFormatMethod("message")]
        void Error(Exception exception, string message, params object[] values);

        [StringFormatMethod("message")]
        void Warn(string message, params object[] values);

        [StringFormatMethod("message")]
        void Warn(Exception exception, string message, params object[] values);

        [StringFormatMethod("message")]
        void Debug(string message, params object[] values);

        [StringFormatMethod("message")]
        void Info(string message, params object[] values);

        bool IsDebugEnabled { get; }
        bool IsInfoEnabled { get; }


    }
}
