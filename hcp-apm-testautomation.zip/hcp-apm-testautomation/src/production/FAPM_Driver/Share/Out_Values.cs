﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FAPM_Driver.Share
{
    public static class Out_Values
    {
        public const string dbConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit2;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";
        public const string tokenGeneratorApiUrl = "https://login.microsoftonline.com/honidentitydev.onmicrosoft.com/oauth2/token";
        public const string tokenCategory = "Bearer ";
        public const string token = "";
        public const string filePath = "D:\\MyProjects\\FAPM_Automation\\FAPM_Features\\ImportFiles\\";
        public static List<dynamic> ApiJsonOutput = new List<dynamic>();
        public static dynamic KPIApi_json;
        public static List<string> emptyList = new List<string>();
        public static dynamic KPIDataAPI_json;
        public static string ResponseCode;
        public static List<string> DataAPI_json = new List<string>();
        public static List<string> HelperList = new List<string>();
        public static Dictionary<string, object> filterOptions = new Dictionary<string, object>();


        public static List<string> matrix_values = new List<string>();
        public static Dictionary<string, string> Risk_Matrix_Values = new Dictionary<string, string>();

        public static Dictionary<string, int> matrix_order = new Dictionary<string, int>(){ {"Cell_1", 2_2},{"Cell_2", 2_77}, {"Cell_3", 2_152}, { "Cell_4", 31_2 }, { "Cell_5", 31_77 }, { "Cell_6", 31_152 },
        { "Cell_7", 60_2 }, { "Cell_8", 60_77 }, { "Cell_9", 60_152 }, { "Cell_10", 89_2 }, { "Cell_11", 89_77 }, { "Cell_12", 89_152 }, { "Cell_13", 118_2 }, { "Cell_14", 118_77 }, { "Cell_15", 118_152 } };

    }
}
 