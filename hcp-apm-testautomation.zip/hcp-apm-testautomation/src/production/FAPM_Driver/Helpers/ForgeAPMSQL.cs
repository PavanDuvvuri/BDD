﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Infrastructure;
using System.Configuration;
using FAPM_Driver.Share;
using FAPM_Driver.Drivers;

namespace FAPM_Driver.Helpers
{
    public class ForgeAPMSQL
    {

        public int InsertDataForAllCriticalities(string criticality, int faultCount, string priority)
        {
            int numOfRowsInserted = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();
            DateTime localTime = DateTime.Now.AddHours(-1);
            string currentUTC = localTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");

            if (criticality == "None")
            {

                for (int i = 0; i < faultCount; i++)
                {
                    string strQuery1 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (1, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K110_SuctionStream_High', N'Sunoco\Malibu\EthyneCracker\K110\K110_SuctionStream', 0, N'SIT_TESTDATA', 0, N'K110_SuctionStream', N'8ff0ca5e-6284-49c9-97cb-e9dba41e685c', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K110_SuctionStream_High', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K110_SuctionStream_High', NULL, NULL, NULL, N'E682EC70-B8E5-400D-8B30-A115F0D53252', NULL)";
                    string strQuery2 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (3, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K110_SuctionStream_Medium', N'Sunoco\Malibu\EthyneCracker\K110\K110_SuctionStream', 0, N'SIT_TESTDATA', 0, N'K110_SuctionStream', N'8ff0ca5e-6284-49c9-97cb-e9dba41e685c', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K110_SuctionStream_Medium', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K110_SuctionStream_Medium', NULL, NULL, NULL, N'E682EC70-B8E5-400D-8B30-A115F0D53252', NULL)";
                    string strQuery3 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (6, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K110_SuctionStream_Low', N'Sunoco\Malibu\EthyneCracker\K110\K110_SuctionStream', 0, N'SIT_TESTDATA', 0, N'K110_SuctionStream', N'8ff0ca5e-6284-49c9-97cb-e9dba41e685c', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K110_SuctionStream_Low', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K110_SuctionStream_Low', NULL, NULL, NULL, N'E682EC70-B8E5-400D-8B30-A115F0D53252', NULL)";

                    SqlCommand sqlCmd1 = new SqlCommand(strQuery1, conn);
                    SqlCommand sqlCmd2 = new SqlCommand(strQuery2, conn);
                    SqlCommand sqlCmd3 = new SqlCommand(strQuery3, conn);

                    sqlCmd1.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd1.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd2.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd2.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd3.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd3.Parameters["@StartTime"].Value = currentUTC;

                    sqlCmd1.ExecuteNonQuery();
                    sqlCmd2.ExecuteNonQuery();
                    sqlCmd3.ExecuteNonQuery();

                }
            }

            else if (criticality == "Major")
            {
                for (int i = 0; i < faultCount; i++)
                {
                    string strQuery4 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (6, 1, 1, CAST(@StartTime AS DateTime), NULL, N'0740-C-201AResidueGasComp_High', N'Sunoco\Alaska\0740-C-201\0740-C-201AResidueGasComp', 0, N'SIT_TESTDATA', 0, N'0740-C-201AResidueGasComp', N'17e9b5f8-44cf-4966-889b-f1f26d2404b7', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'0740-C-201AResidueGasComp_High', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'0740-C-201AResidueGasComp_High', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery5 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (3, 1, 1, CAST(@StartTime AS DateTime), NULL, N'0740-C-201AResidueGasComp_Medium', N'Sunoco\Alaska\0740-C-201\0740-C-201AResidueGasComp', 0, N'SIT_TESTDATA', 0, N'0740-C-201AResidueGasComp', N'17e9b5f8-44cf-4966-889b-f1f26d2404b7', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'0740-C-201AResidueGasComp_Medium', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'0740-C-201AResidueGasComp_Medium', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery6 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (2, 1, 1, CAST(@StartTime AS DateTime), NULL, N'0740-C-201AResidueGasComp_Low', N'Sunoco\Alaska\0740-C-201\0740-C-201AResidueGasComp', 0, N'SIT_TESTDATA', 0, N'0740-C-201AResidueGasComp', N'17e9b5f8-44cf-4966-889b-f1f26d2404b7', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'0740-C-201AResidueGasComp_Low', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'0740-C-201AResidueGasComp_Low', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";

                    SqlCommand sqlCmd4 = new SqlCommand(strQuery4, conn);
                    SqlCommand sqlCmd5 = new SqlCommand(strQuery5, conn);
                    SqlCommand sqlCmd6 = new SqlCommand(strQuery6, conn);

                    sqlCmd4.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd4.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd5.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd5.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd6.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd6.Parameters["@StartTime"].Value = currentUTC;


                    sqlCmd4.ExecuteNonQuery();
                    sqlCmd5.ExecuteNonQuery();
                    sqlCmd6.ExecuteNonQuery();
                }
            }
            else if (criticality == "Minor")
            {
                for (int i = 0; i < faultCount; i++)
                {
                    string strQuery7 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (5, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K101_DSF1', N'Dinoco\Malibu\FCC101\K101\K101_DischargeStream', 0, N'SIT_TESTDATA', 0, N'K101_DischargeStream', N'10c4a2f1-31a5-4861-8615-2bb330135baa', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K101_DSF1', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K101_DSF1', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery8 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (3, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K101_SSF1', N'Dinoco\Malibu\FCC101\K101\K101_SuctionStream', 0, N'SIT_TESTDATA', 0, N'K101_SuctionStream', N'65dc2e91-b814-479c-8289-d8d505346494', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K101_SSF1', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K101_SSF1', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery9 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (1, 1, 1, CAST(@StartTime AS DateTime), NULL, N'K101_DSF1', N'Dinoco\Malibu\FCC101\K102\K102_DischargeStream', 0, N'SIT_TESTDATA', 0, N'K102_DischargeStream', N'a33af669-94c6-4836-a43f-35d9f2c4db8c', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'K101_DSF1', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'K101_DSF1', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";

                    SqlCommand sqlCmd7 = new SqlCommand(strQuery7, conn);
                    SqlCommand sqlCmd8 = new SqlCommand(strQuery8, conn);
                    SqlCommand sqlCmd9 = new SqlCommand(strQuery9, conn);

                    sqlCmd7.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd7.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd8.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd8.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd9.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd9.Parameters["@StartTime"].Value = currentUTC;

                    sqlCmd7.ExecuteNonQuery();
                    sqlCmd8.ExecuteNonQuery();
                    sqlCmd9.ExecuteNonQuery();
                }
            }
            else if (criticality == "Safety")
            {
                for (int i = 0; i < faultCount; i++)
                {
                    string strQuery10 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (6, 1, 1, CAST(@StartTime AS DateTime), NULL, N'601-G-13_High', N'Sunoco\Malibu\CDU4\601-C01_Part\601-G-13', 0, N'SIT_TESTDATA', 0, N'601-G-13', N'8d10574a-4d3d-4f0c-a3e4-c218c1c097d8', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'601-G-13_High', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'601-G-13_High', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery11 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (3, 1, 1, CAST(@StartTime AS DateTime), NULL, N'601-G-13_Medium', N'Sunoco\Malibu\CDU4\601-C01_Part\601-G-13', 0, N'SIT_TESTDATA', 0, N'601-G-13', N'8d10574a-4d3d-4f0c-a3e4-c218c1c097d8', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'601-G-13_Medium', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'601-G-13_Medium', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";
                    string strQuery12 = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], [CreatedUser_PK_ID], [FaultDisplayName],  [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID], [CloseOutV2_PK_ID], [EventCategory_PK_ID], [ReasonCode]) VALUES (2, 1, 1, CAST(@StartTime AS DateTime), NULL, N'601-G-13_Low', N'Sunoco\Malibu\CDU4\601-C01_Part\601-G-13', 0, N'SIT_TESTDATA', 0, N'601-G-13', N'8d10574a-4d3d-4f0c-a3e4-c218c1c097d8', N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'601-G-13_Low', 0, NULL, NULL, NULL, NULL, N'', 5, NULL, NULL, N'601-G-13_Low', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1', NULL)";

                    SqlCommand sqlCmd10 = new SqlCommand(strQuery10, conn);
                    SqlCommand sqlCmd11 = new SqlCommand(strQuery11, conn);
                    SqlCommand sqlCmd12 = new SqlCommand(strQuery12, conn);

                    sqlCmd10.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd10.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd11.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd11.Parameters["@StartTime"].Value = currentUTC;
                    sqlCmd12.Parameters.Add("@StartTime", SqlDbType.VarChar);
                    sqlCmd12.Parameters["@StartTime"].Value = currentUTC;

                    sqlCmd10.ExecuteNonQuery();
                    sqlCmd11.ExecuteNonQuery();
                    sqlCmd12.ExecuteNonQuery();
                }
            }
            conn.Close();
            return numOfRowsInserted;
        }


        public int InsertDataForEventDataAPI(string assetName, int faultState, int eventStatus, int priority, string startDate)
        {
            var assetId = Driver.GetAssetIds(assetName);
            int numOfRowsInserted = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], 
                                [CreatedUser_PK_ID], [FaultDisplayName], [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID],
                                [CloseOutV2_PK_ID], [EventCategory_PK_ID]) VALUES (@FaultSeverity, @EventStatus, 1, CAST(@StartTime AS DateTime), NULL, N'RadialBearingMalfunctionNDERH5', @FaultVisualisationData,
                                0, N'TESTFAULT123', @FaultState, @EquipmentName_EOM, @EquipmentId_EOM, N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'RadialBearingMalfunctionNDERH', 0, NULL, NULL, NULL, CAST(N'2020-12-16T06:12:30.143' AS DateTime),
                                N'', 5, NULL, NULL, N'RadialBearingMalfunctionNDERH', NULL, NULL, NULL, N'29211281-6449-4B75-9B61-F8A9CD2A2BF1')";

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.Parameters.Add("@FaultSeverity", SqlDbType.Int);
            sqlCmd.Parameters["@FaultSeverity"].Value = priority;
            sqlCmd.Parameters.Add("@EventStatus", SqlDbType.Int);
            sqlCmd.Parameters["@EventStatus"].Value = eventStatus;
            sqlCmd.Parameters.Add("@FaultState", SqlDbType.Int);
            sqlCmd.Parameters["@FaultState"].Value = faultState;
            sqlCmd.Parameters.Add("@EquipmentName_EOM", SqlDbType.VarChar);
            sqlCmd.Parameters["@EquipmentName_EOM"].Value = assetName;

            if (assetName == "DC3LowerSortLane8")
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\DC3LowerShipping\" + assetName;
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = assetId;
            }

            else if (assetName == "DC3RoutingSorter")
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\DC3Routing\DC3RoutingSortation\" + assetName;
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = assetId;
            }

            else
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\DC3Routing\DC3RoutingSortation\DC3RoutingSorter\" + assetName;
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = assetId;
            }

            if (startDate == "TODAY")
            {
                DateTime currentTime = DateTime.Now.AddHours(-5);
                string currentUTC = currentTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
                sqlCmd.Parameters.Add("@StartTime", SqlDbType.VarChar);
                sqlCmd.Parameters["@StartTime"].Value = currentUTC;
            }
            else
            {
                sqlCmd.Parameters.Add("@StartTime", SqlDbType.VarChar);
                sqlCmd.Parameters["@StartTime"].Value = startDate;
            }
            numOfRowsInserted = sqlCmd.ExecuteNonQuery();
            int originalRows = numOfRowsInserted - 1;
            Console.WriteLine("No of rows affected is : " + originalRows);
            conn.Close();

            return numOfRowsInserted;

        }

        public int InsertEventCategoryDataForEventDataAPI(string eventCategory, string assetName, int faultState, int eventStatus, int priority, string startDate)
        {
            string HealthCategory = "29211281-6449-4B75-9B61-F8A9CD2A2BF1";
            string SafetyCategory = "E682EC70-B8E5-400D-8B30-A115F0D53252";
            string PerformanceCategory = "42E1701D-ADD0-4BBE-B552-EF50B7619DB9";
            string DC3LowerShipping_asset_Id = "65b0d300-742a-48d0-b1ae-c8848fc2eda1";
            string DC3LowerSortLane8_asset_Id = "6c2506f3-a802-4269-b714-7b15cc63acdd";
            string TTCBSorter_asset_Id = "41da7f3d-3f6a-4ad0-a875-03e232d309dd";

            int numOfRowsInserted = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"INSERT into ActiveFaultHistoriesV2 ([FaultSeverity], [EventStatus], [Autoreset], [StartTime], [EndTime], [FaultName], [FaultVisualisationData], [DestinationType], [Description], [FaultState], [EquipmentName_EOM], [EquipmentId_EOM], 
                                [CreatedUser_PK_ID], [FaultDisplayName], [FaultMode], [CloseTime], [InputData], [Expression], [ModeTime], [Recommendation], [MessageType], [Causes], [Consequences], [EventName_EOM], [TrendDetailJSon], [AcceptedUser_PK_ID],
                                [CloseOutV2_PK_ID], [EventCategory_PK_ID]) VALUES (@FaultSeverity, @EventStatus, 1, CAST(@StartTime AS DateTime), NULL, N'RadialBearingMalfunctionNDERH5', @FaultVisualisationData,
                                0, N'TESTFAULT123', @FaultState, @EquipmentName_EOM, @EquipmentId_EOM, N'd7a91e0f-8e1a-497d-a63c-f274a9ff6d33', N'SIT_FAULT_1', 0, NULL, NULL, NULL, CAST(N'2020-12-16T06:12:30.143' AS DateTime),
                                N'', 5, NULL, NULL, N'RadialBearingMalfunctionNDERH', NULL, NULL, NULL, @EventCategory_PK_ID)";

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.Parameters.Add("@FaultSeverity", SqlDbType.Int);
            sqlCmd.Parameters["@FaultSeverity"].Value = priority;
            sqlCmd.Parameters.Add("@EventStatus", SqlDbType.Int);
            sqlCmd.Parameters["@EventStatus"].Value = eventStatus;
            sqlCmd.Parameters.Add("@FaultState", SqlDbType.Int);
            sqlCmd.Parameters["@FaultState"].Value = faultState;
            sqlCmd.Parameters.Add("@EquipmentName_EOM", SqlDbType.VarChar);
            sqlCmd.Parameters["@EquipmentName_EOM"].Value = assetName;

            if (assetName == "DC3LowerShipping")
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\DC3Shipping\DC3LowerShipping";
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = DC3LowerShipping_asset_Id;
            }

            else if (assetName == "TTCBSorter")
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\TTCBSortation\TTCBSorter";
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = TTCBSorter_asset_Id;
            }

            else
            {
                sqlCmd.Parameters.Add("@FaultVisualisationData", SqlDbType.VarChar);
                sqlCmd.Parameters["@FaultVisualisationData"].Value = @"Enterprise\DC3\DC3Shipping\DC3LowerShipping\" + assetName;
                sqlCmd.Parameters.Add("@EquipmentId_EOM", SqlDbType.VarChar);
                sqlCmd.Parameters["@EquipmentId_EOM"].Value = DC3LowerSortLane8_asset_Id;
            }

            if (startDate == "TODAY")
            {
                DateTime currentTime = DateTime.Now.AddDays(1);
                string currentUTC = currentTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss");
                sqlCmd.Parameters.Add("@StartTime", SqlDbType.VarChar);
                sqlCmd.Parameters["@StartTime"].Value = currentUTC;
            }
            else
            {
                sqlCmd.Parameters.Add("@StartTime", SqlDbType.VarChar);
                sqlCmd.Parameters["@StartTime"].Value = startDate;
            }

            switch (eventCategory)
            {
                case "Health":
                    sqlCmd.Parameters.Add("@EventCategory_PK_ID", SqlDbType.VarChar);
                    sqlCmd.Parameters["@EventCategory_PK_ID"].Value = HealthCategory;
                    break;

                case "Safety":
                    sqlCmd.Parameters.Add("@EventCategory_PK_ID", SqlDbType.VarChar);
                    sqlCmd.Parameters["@EventCategory_PK_ID"].Value = SafetyCategory;
                    break;
                case "Performance":
                    sqlCmd.Parameters.Add("@EventCategory_PK_ID", SqlDbType.VarChar);
                    sqlCmd.Parameters["@EventCategory_PK_ID"].Value = PerformanceCategory;
                    break;
                default:
                    sqlCmd.Parameters.Add("@EventCategory_PK_ID", SqlDbType.VarChar);
                    sqlCmd.Parameters["@EventCategory_PK_ID"].Value = HealthCategory;
                    break;
            }



            numOfRowsInserted = sqlCmd.ExecuteNonQuery();
            int originalRows = numOfRowsInserted - 1;
            Console.WriteLine("No of rows affected is : " + originalRows);
            conn.Close();

            return numOfRowsInserted;

        }

        public int DeleteDataForEventDataAPI()
        {
            int numOfRows = 0;

            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"Delete from ActiveFaultHistoriesV2 where Description like '%TESTFAULT123%'";
            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            numOfRows = sqlCmd.ExecuteNonQuery();
            int originalRowsDeleted = numOfRows;
            Console.WriteLine("No of rows deleted is : " + originalRowsDeleted);
            conn.Close();

            return numOfRows;

        }
        public static int InsertKPIDataAPI(string assetName, string metricname, string metricfield, string reportingperiod, string startdate, string reportingtime, int value)
        {
            int numOfRows = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"INSERT into MetricHistoryValues ([AssetName], [MetricName], [MetricField], [ReportingPeriod], [TimeStamp],[ReportingTime], [Value]) VALUES (@AssetName, @MetricName, @MetricField, @ReportingPeriod, CAST(@TimeStamp AS DateTime), CAST(@ReportingTime AS DateTime), @Value)";

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.Parameters.Add("@Assetname", SqlDbType.VarChar);
            sqlCmd.Parameters["@Assetname"].Value = assetName;
            sqlCmd.Parameters.Add("@MetricName", SqlDbType.VarChar);
            sqlCmd.Parameters["@MetricName"].Value = metricname;
            sqlCmd.Parameters.Add("@MetricField", SqlDbType.VarChar);
            sqlCmd.Parameters["@MetricField"].Value = metricfield;
            sqlCmd.Parameters.Add("@ReportingPeriod", SqlDbType.VarChar);
            sqlCmd.Parameters["@ReportingPeriod"].Value = reportingperiod;
            sqlCmd.Parameters.Add("@Value", SqlDbType.Int);
            sqlCmd.Parameters["@Value"].Value = value;
            sqlCmd.Parameters.Add("@TimeStamp", SqlDbType.VarChar);
            sqlCmd.Parameters["@TimeStamp"].Value = startdate;
            sqlCmd.Parameters.Add("@ReportingTime", SqlDbType.VarChar);
            sqlCmd.Parameters["@ReportingTime"].Value = reportingtime;
            numOfRows = sqlCmd.ExecuteNonQuery();
            //int originalRows = numOfRows - 1;
            Console.WriteLine("No of rows affected is : " + numOfRows);
            conn.Close();
            return numOfRows;
        }
        public static int DeleteKPIData(string assetName)
        {
            int numOfRowsdeleted = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"DELETE from MetricHistoryValues where AssetName = @AssetName";

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.Parameters.Add("@Assetname", SqlDbType.VarChar);
            sqlCmd.Parameters["@Assetname"].Value = assetName;
            numOfRowsdeleted = sqlCmd.ExecuteNonQuery();
            //int originalRows = numOfRows - 1;
            Console.WriteLine("No of rows deleted is : " + numOfRowsdeleted);
            conn.Close();
            return numOfRowsdeleted;
        }
        public static int DeleteReportConfigData(string name)
        {
            int numOfRowsdeleted = 0;
            SqlConnection conn = new SqlConnection(Environment_Values.DBConnection);
            conn.Open();

            string strQuery = @"DELETE from ReportPeriodConfiguration where Name = @name";

            SqlCommand sqlCmd = new SqlCommand(strQuery, conn);
            sqlCmd.Parameters.Add("@name", SqlDbType.VarChar);
            sqlCmd.Parameters["@name"].Value = name;
            numOfRowsdeleted = sqlCmd.ExecuteNonQuery();
            //int originalRows = numOfRows - 1;
            Console.WriteLine("No of rows deleted is : " + numOfRowsdeleted);
            conn.Close();
            return numOfRowsdeleted;
        }
    }
}