﻿using System;
using System.Collections.Generic;
using System.Text;
using FAPM_Driver.KpiService;
using AutomationFramework;
using FAPM_Driver.Excel;
using FAPM_Driver;
using FAPM_Driver.EventManagementService;
using FAPM_Driver.ModelConfigService;

namespace FAPM_Driver.Helpers
{
    class JsonHelper
    {
        public AssetFailureNotificationRequest EventsRequestBody(string startDate, string endDate, string faultStatus, string assetName, string assetId, int criticality, string rootNode)
        {
            List<string> fault_status = new List<string>();
            fault_status.Add(faultStatus);
            //List<string> fault_state = new List<string>();
            //fault_state.Add(faultState);
            //List<string> fault_priority = new List<string>();
            //fault_priority.Add(faultPriority);
            //List<string> fault_category = new List<string>();
            //fault_category.Add(faultCategory);
            //List<string> asset_type_name = new List<string>();
            //asset_type_name.Add("");

            DateTimeOffset start_date = DateTimeOffset.Parse(startDate);
            DateTimeOffset end_date = DateTimeOffset.Parse(endDate);


            var eventsJson = new AssetFailureNotificationRequest();
            {
                eventsJson.HierarchyName = "";
                eventsJson.RootNode = rootNode;
                eventsJson.StartDate = start_date;
                eventsJson.EndDate = end_date;
                eventsJson.FaultStatus = fault_status;
                //eventsJson.FaultState = fault_state;
                //eventsJson.FaultPriority = fault_priority;
                //eventsJson.FaultCategory = fault_category;
                //eventsJson.AssetTypeName = asset_type_name;
                eventsJson.AssetData = Asset_Data(assetName, assetId, criticality);
                ////eventsJson.AssetData = null;
                //eventsJson.FromHeatMapSummary = 0;
                //eventsJson.FromHeatMapStatus = 0;
                //eventsJson.FromHeatMapPrioritySummary = 0;
            }
            return eventsJson;
        }

        public GetFaultCountDataRequest FaultCountDataRequestBody(string startDate, string endDate, string faultCategory, string assetName, string assetId)
        {
            List<string> fault_category = new List<string>();
            fault_category.Add(faultCategory);


            var faultCountJson = new GetFaultCountDataRequest();
            {
                faultCountJson.HierarchyName = "";
                faultCountJson.RootNode = assetName;
                faultCountJson.StartDate = startDate;
                faultCountJson.EndDate = endDate;
                faultCountJson.FaultCategory = fault_category;
                faultCountJson.AssetData = AssetData(assetName, assetId);
            }
            return faultCountJson;
        }

        public GetHeatmapMatrixDataRequest HeatmapMatrixDataRequest(string startTime, string endTime, string hiearachyName, string rootNode, string heatMap_for)
        {
            var heatMapMatrixDataJson = new GetHeatmapMatrixDataRequest();
            {
                heatMapMatrixDataJson.HierarchyName = hiearachyName;
                heatMapMatrixDataJson.RootNode = rootNode;
                heatMapMatrixDataJson.StartTimeInUTC = startTime;
                heatMapMatrixDataJson.EndTimeInUTC = endTime;
                heatMapMatrixDataJson.HeatmapFor = heatMap_for;
            }
            return heatMapMatrixDataJson;
        }

        public UpdateNotificationRequest updateNotificationRequest(string timeStamp, string assetId, string faultDisplayName, string eventcategoryId, string comments, string reasonCode, string firstName, string lastName)
        {
            var updateNotificationJson = new UpdateNotificationRequest();
            {
                updateNotificationJson.AssetId = assetId;
                updateNotificationJson.FaultDisplayName = faultDisplayName;
                updateNotificationJson.TimeStamp = timeStamp;
                updateNotificationJson.Comments = comments;
                updateNotificationJson.EventCategoryPK_Id = eventcategoryId;
                updateNotificationJson.ReasonCode = reasonCode;
                updateNotificationJson.FirstName = firstName;
                updateNotificationJson.LastName = lastName;
            }
            return updateNotificationJson;
        }

        public AssetAttributeRequest AssetAttributeBody(string assetNames, string assetTypes, int pageNumber, int pageSize)
        {
            List<string> asset_names = new List<string>();
            asset_names.Add(assetNames);
            List<string> asset_types = new List<string>();
            asset_types.Add(assetTypes);

            var assetAttributeJson = new AssetAttributeRequest();
            {
                assetAttributeJson.AssetNames = asset_names;
                assetAttributeJson.AssetTypes = asset_types;
                assetAttributeJson.PageNumber = pageNumber;
                assetAttributeJson.PageSize = pageSize;
            }
            return assetAttributeJson;
        }



        public List<AssetDataList> Asset_Data(string asset_name, string asset_id, int criticality)
        {

            List<AssetDataList> Asset_Data = new List<AssetDataList>();
            AssetDataList Asset_Data_Mapping = new AssetDataList();

            Asset_Data_Mapping.AssetName = asset_name;
            Asset_Data_Mapping.AssetId = asset_id;
            Asset_Data_Mapping.Criticality = criticality;
            Asset_Data.Add(Asset_Data_Mapping);

            return Asset_Data;
        }

        public List<AssetDataElement> AssetData(string asset_name, string asset_id)
        {

            List<AssetDataElement> AssetData = new List<AssetDataElement>();
            AssetDataElement Asset_Data_Mapping = new AssetDataElement();

            Asset_Data_Mapping.AssetName = asset_name;
            Asset_Data_Mapping.AssetId = asset_id;
            AssetData.Add(Asset_Data_Mapping);

            return AssetData;
        }

        public ReportPeriodConfigurationModel ReportConfigurationResponsebody(Dictionary<string, string> param)
        {
            var json = new ReportPeriodConfigurationModel();

            json.Name = param["Name"];
            json.DisplayName = param["DisplayName"];
            json.AnchorTime = param["AnchorTime"];
            json.Duration = param["Duration"];
            json.Interval = param["Interval"];

            return json;
        }
    }
}
