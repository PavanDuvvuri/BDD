﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace FAPM_Features.Utilities
{
    public static class AssetDashoard
    {


        #region Login Details

        //public static readonly By AssetHealthHeader = By.XPath("//*[text()='Asset Health']");
        //public static readonly By asset_Dropdown_click = By.XPath("(//div[@class='dropdown-button'])[1]/div/span");
        //public static readonly By AlaskaDDSelction = By.XPath("//span[text()='Alaska' and @class='title']");
        //public static readonly By duration_Dropdown_click= By.XPath("(//div[@class='dropdown-button'])[2]");
        //public static readonly By OEE_Name = By.XPath("//*[text()='Overall Equipment Efficiency']");
        //public static readonly By OEE_score = By.XPath("//div[@class='assetOverallSummaryCard pointer hover1 ']/div[2]");


        public static readonly By AssetHealthHeader = By.XPath("//*[text()='Asset Health']");
        public static readonly By asset_Dropdown_click = By.XPath("(//div[@class='dropdown-button'])[1]/div/span[2]");
        //public static readonly By AlaskaDDSelction = By.XPath("//span[text()='Alaska' and @class='title']");
        public static readonly By duration_Dropdown_click = By.XPath("//div[@class='dropdown-button']/div[@class='button ']/span[2]");
        public static readonly By OEE_title = By.XPath("//*[text()='Overall Equipment Efficiency']");
        public static readonly By Availability_title = By.XPath("//*[text()='Availability']");
        public static readonly By Performance_title = By.XPath("//*[text()='Performance']");
        public static readonly By Quality_title = By.XPath("//*[text()='Quality']");
        public static readonly By OEE_score = By.XPath("//div[text()='Overall Equipment Efficiency']/following-sibling::div[@class='assetOverallSummaryCardRight']");
        public static readonly By Availability_score = By.XPath("//div[text()='Availability']/following-sibling::div[@class='assetOverallSummaryCardRight']");
        public static readonly By Performance_score = By.XPath("//div[text()='Performance']/following-sibling::div[@class='assetOverallSummaryCardRight']");
        public static readonly By Quality_score = By.XPath("//div[text()='Quality']/following-sibling::div[@class='assetOverallSummaryCardRight']");
        public static readonly By ExpandDropDownCarrot = By.XPath("//span[text()='Malibu']/parent::div/span/i");
        public static readonly By AssetDetails_OEE_score = By.XPath("//div[text()='Overall Equipment Efficiency']/following-sibling::div[@class='assetOverallSummary-card-right']");
        public static readonly By AssetDetails_Availability_score = By.XPath("//div[text()='Availability']/following-sibling::div[@class='assetOverallSummary-card-right']");
        public static readonly By AssetDetails_Performance_score = By.XPath("//div[text()='Performance']/following-sibling::div[@class='assetOverallSummary-card-right']");
        public static readonly By AssetDetails_Quality_score = By.XPath("//div[text()='Quality']/following-sibling::div[@class='assetOverallSummary-card-right']");

        public static readonly By headerText = By.XPath("//*[text()='Top Faulted Assets']");
        //public static readonly By AssetButton = By.XPath("(//*[@class='ui buttons']/button)[3]/div[text()='Assets']");
        //public static readonly By FaultButton = By.XPath("(//*[@class='ui buttons']/button)[4]/div[text()='Faults']");
        public static readonly By RiskMatrixAssetButton = By.XPath("//div[@class='asset-failure-card-header-button']//div[@class='button-content' and text()='Assets']");
        public static readonly By Filter = By.XPath("//button[@class='filter-button']");
        public static readonly By FilterFreqFaults = By.XPath("//*[text()='Filter Frequent Faults ']");
        public static readonly By KeyKPI = By.XPath("//*[text()='KEY KPIs']");
        public static readonly By UptimeText = By.XPath("//span[text()='Uptime']");
        public static readonly By UptimeValue = By.XPath("(//span[@class='value'])[2]");
        public static readonly By UtilizationText = By.XPath("//span[text()='Utilization']");
        public static readonly By UtilizationValue = By.XPath("(//span[@class='value'])[3]");
        public static readonly By EnergyText = By.XPath("//span[text()='Energy']");
        public static readonly By EnergyValue = By.XPath("(//span[@class='value'])[1]");
        public static readonly By AssetSummaryHeader = By.XPath("//*[text()='Asset Summary']");
        public static readonly By NoFilterApplied = By.XPath("//*[text()='No filters applied']");
        public static readonly By AssetSummaryTableHeader = By.XPath("//table/thead/tr/th");
        public static readonly By AssetSummaryTableRow = By.XPath("//table/tbody/tr");

        public static readonly By riskMatrixFrame = By.XPath("(//*[contains(text(),'frame')])[2]");
        public static readonly By assetName_TopFaulted = By.XPath("//*[text()='Asset Name']");
        public static readonly By AssetButton_TopFaulted = By.XPath("(//*[@class='ui buttons']/button)[3]/div[text()='Assets']");
        public static readonly By FaultButton_TopFaulted = By.XPath("(//*[@class='ui buttons']/button)[4]/div[text()='Faults']");
        public static readonly By faultName_FreqFaults = By.XPath("//*[text()='Fault Name']");
        public static readonly By textNameFor_AssetAndFaults_TopFaulted = By.XPath("(//div[@dir='ltr'])[2]/div[@class='highcharts-axis-labels highcharts-xaxis-labels']/span");
        public static readonly By Header_FreqFaults = By.XPath("//*[text()='FREQUENT FAULTS']");

        public static readonly By AssetDetailsHeader = By.XPath("//span[text()='Asset Summary Dashboard /  Asset Details']");
        public static readonly By AssetDashboardTitle = By.XPath("//span[@class='dashboard-title']");
        public static readonly By AssetDetailsDurationDropDown = By.XPath("//div[@class='ui selection dropdown']");
        public static readonly By AssetDetails_FaultsButton_TopFaulted = By.XPath("//div[@class='button-content' and text()='Faults']");
        public static readonly By AssetDetails_AssetsButton_TopFaulted = By.XPath("//div[@class='button-content' and text()='Assets']");
        public static readonly By Assets_TitleText_TopFaulted = By.XPath("//div[@class='highcharts-axis-labels highcharts-xaxis-labels']/span");
        public static readonly By Faults_TitleText_TopFaulted = By.XPath("//div[@class='highcharts-axis-labels highcharts-xaxis-labels']/span/span");
        public static readonly By CapacityLoss_value = By.XPath("//span[text()='CapacityLoss']/parent::div//div/span[@class='value']");
        public static readonly By Energy_value = By.XPath("//span[text()='Energy']/parent::div//div/span[@class='value']");
        public static readonly By GasFlowRate_value = By.XPath("//span[text()='GasFlowRate']/parent::div//div/span[@class='value']");
        public static readonly By PolytropicEfficiency_value = By.XPath("//span[text()='PolytropicEfficiency']/parent::div//div/span[@class='value']");
        public static readonly By PolytropicHead_value = By.XPath("//span[text()='PolytropicHead']/parent::div//div/span[@class='value']");
        public static readonly By Energy_Text = By.XPath("//span[text()='Energy']");
        public static readonly By CapacityLoss_Text = By.XPath("//span[text()='CapacityLoss']");
        public static readonly By GasFlowRate_Text = By.XPath("//span[text()='GasFlowRate']");
        public static readonly By PolytropicEfficiency_Text = By.XPath("//span[text()='PolytropicEfficiency']");
        public static readonly By PolytropicHead_Text = By.XPath("//span[text()='PolytropicHead']");

        #endregion


        #region ForgeLogin

        public static readonly By user_name = By.XPath("//input[@name='username']");
        public static readonly By password = By.XPath("//input[@name='password']");
        public static readonly By sign_in = By.XPath("//span[text()='Sign IN']");
        public static readonly By username_header = By.XPath("//span[text()='Email or Username']");
        #endregion ForgeLogin

        #region Matrix page
        public static readonly By ddlsites = By.XPath("//div[@class='dropdown-button']");
        public static readonly By FaultMatrix = By.XPath("//div[@class='highcharts-axis-labels highcharts-xaxis-labels')]");
        public static readonly By Riskmatrix=By.XPath("//div[@class='highcharts-series highcharts-series-0 highcharts-heatmap-series highcharts-color-0 heatmap-plot-options highcharts-tracker')]");
        public static readonly By Matrixes = By.XPath("//*[@class='highcharts-series-group']");
        #endregion

        #region AssetSummary
        public static readonly By assetsummarylink = By.XPath("//span[@class='redirect-link']");
        #endregion


        public static readonly By asset_toggle_menu = By.XPath("//*[@title='Toggle Menu']");
        public static readonly By menu_button = By.XPath("//a[@class='item menu-btn-item']");

        public static readonly By next_button = By.XPath("//div[@class='button-content' and text()='Next']");
        public static readonly By forge_title = By.XPath("//div[text()='HONEYWELL FORGE']");

        public static readonly By asset_overall_summary_text1 = By.XPath(@"//div[contains(string(), 'Overall Equipment Effeciency')]");
        public static readonly By asset_overall_summary_text2 = By.XPath(@"//div[contains(string(), 'Overall Equipment Effeciency')]/following-sibling::div");

        public static readonly By asset_overall_pefr_text = By.XPath(@"//div[contains(string(), 'Performance')]");
        public static readonly By asset_overall_pefr_value = By.XPath(@"//div[contains(string(), 'Performance')]/following-sibling::div");


        public static readonly By assetcontainer = By.XPath(@"//*[@id='root']/div/div/div[2]/div/div/div/div/div[1]/div[2]/div[1]/div[1]/div[2]");
        public static readonly By assetcontainer2 = By.XPath(@"//*[@id='root']/div/div/div[2]/div/div/div/div/div[1]/div[2]/div[1]/div[3]");
        public static readonly By assetcontainer3 = By.XPath(@"//*[@id='root']/div/div/div[2]/div/div/div/div/div[1]/div[2]/div[2]/div[1]/div[2]");

        public static readonly By asset_overall_Sum_text = By.XPath(@"//*[@class='assetOverallSummaryCardRight'");

        public static readonly By asset_overall_availability_text = By.XPath(@"//div[contains(string(), 'Availability')]");
        public static readonly By asset_overall_availability_value = By.XPath(@"//div[contains(string(), 'Availability')]/following-sibling::div");

        public static readonly By asset_overall_eqmpteff = By.XPath(@"//div[contains(string(), 'Overall Equipment Effeciency')]");
        public static readonly By asset_overall_eqmpteffvalue_value = By.XPath(@"//div[contains(string(), 'Overall Equipment Effeciency')]/following-sibling::div");


        public static readonly By asset_overall_quality_text = By.XPath(@"//div[contains(string(), 'Quality')]");
        public static readonly By asset_overall_qaulity_value = By.XPath(@"//div[contains(string(), 'Quality')]/following-sibling::div");

        public static readonly By filtered_list  = By.XPath("//span[@class='text']");

        public static readonly By Fault_button = By.XPath("//div[@class='button-content' and contains(text(), 'Faults')]");
        public static readonly By Asset_button = By.XPath("//div[@class='button-content' and contains(text(), 'Assets')]");

        public static readonly By AssetHealth_button = By.XPath("//span[contains(text(), 'Asset Health')]");
        public static readonly By close_button = By.XPath("//div[@class='pin-and-close']//i");

        #region Outbondpage
        public static readonly By outbound_header = By.XPath("//span[text()='Outbound Opera-tions']");
        public static readonly By order_current_asset = By.XPath("//div[@class='order_metric_section_outbound_dashboard']/label");
        public static readonly By picked_shipped = By.XPath("//div[@class='progress_bar_metric_outbound_dashboard']//div/label");
        public static readonly By viewbyday_button = By.XPath("//div[@class='button-content' and contains(text(), 'View By Day')]");
        public static readonly By viewbyshift_button3 = By.XPath("//div[@class='button-content' and contains(text(), 'View By Shift')]");
        public static readonly By viewbyday_button3 = By.XPath("//div[@class='button-content' and contains(text(), 'View by Day')]");
        public static readonly By viewbyshift_button1 = By.XPath("//div[@class='button-content' and contains(text(), 'View by Shift')]");
        public static readonly By clickOnNotification_icon = By.XPath("(//div[@class='bell-icon']/a)[1]");
        public static readonly By clickOnViewDetails = By.XPath("//div[text()='View Details']");
        public static readonly By asset_Selection = By.XPath("//*[@class='ui scuf-dropdown-wrapper all-asset-dropdown']/div/div[@role='alert']");
        public static readonly By asset_DC3 = By.XPath("//*[@class='visible menu transition']/div[text()='DC3']");
        public static readonly By asset_DC15 = By.XPath("//*[@class='visible menu transition']/div[3][text()='DC15']");
        public static readonly By dynamicValue_orderQuota = By.XPath("(//div[@class='order_metric_section_outbound_dashboard']/label)[2]");
        public static readonly By dynamicValue_orderQuotaPicked = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[1]");
        public static readonly By dynamicValue_orderQuotaShipped = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[4]");
        public static readonly By dynamicValue_assetDowntime = By.XPath("(//div[@class='order_metric_section_outbound_dashboard']/label)[6]");
        public static readonly By dynamicValue_actvscurrent = (By.XPath("//*[@id='PickingCardKey']/div/div/div[1]/div[3]/div/div[1]/p/span"));
        public static readonly By dynamicValue_expectedvalue = By.XPath("//*[@class='outbound-dashboard-picking-card']/div/div[3]/div/div[3]/p");
        public static readonly By dynamicValue_releasedpicked = By.XPath("//*[@class='outbound-dashboard-picking-card']/div/div[3]/div/div[5]/p");
        public static readonly By dynamicValue_efficiency = By.XPath("//*[@class='outbound-dashboard-picking-card']/div/div[3]/div/div[7]/p");
        public static readonly By dynamicValue_optimalvalue = By.XPath("(//div[@class='picking_card_status_row']/label)[1]");
        public static readonly By topelement = By.XPath("//*[@class='outbound-dashboard-picking-card']");

        public static readonly By picking_values = By.XPath("//*[@class='current_plan']/div/p");
        public static readonly By picking_text = By.XPath("//*[@class='current_plan']/div/span");
        public static readonly By cartons = By.XPath("//*[text()='Cartons Current Rate/ hr']");
        public static readonly By picking_name = By.XPath("//*[text()='PICKING']");
        public static readonly By optimal_text = By.XPath("//*[text()='Optimal Performance']");
        public static readonly By optimal_desc = By.XPath("//*[text()='You have reached/exceeded the planned rate !']");
        public static readonly By totalcart = By.XPath("//*[text()='Total Cartons']");
        public static readonly By time = By.XPath("//*[text()='Time(hrs)']");
        public static readonly By throughput = By.XPath("//*[text()='Throughput']");
        public static readonly By cartons_value = By.XPath("//*[@class='cartoon_estimate']/div/p/span");
        public static readonly By cartons_text = By.XPath("//*[@class='cartoon_estimate']/div/p");
        public static readonly By picking_graph_values = By.XPath("//div[@class='outbound-dashboard-picking-card']/div[4]//span");

        public static readonly By shipping_values = By.XPath("//*[@class='current_plans']/div/p");
        public static readonly By shipping_text = By.XPath("//*[@class='current_plans']/div/span");
        public static readonly By shipping_name = By.XPath("//*[text()='SHIPPING']");
        public static readonly By asset_desc_error = By.XPath("//*[@class='outbound-dashboard-picking-card']/div[2]/div[2]/span");
        public static readonly By asset_text = By.XPath("//*[text()='Picking is Impacted'] | //*[text()='Optimal Performance']");
        public static readonly By asset_desc = By.XPath("//*[contains(text(),'You have reached/exceeded the planned rate !')]");
        public static readonly By shipping_graph_values = By.XPath("//div[@class='outbound-dashboard-shipping-card']/div[4]//span");
        public static readonly By order_current_asset_shipping = By.XPath("//div[@class='order_metric_section_shipping_dashboard']/label");
        public static readonly By shipped_shipping = By.XPath("//div[@class='progress_bar_metric_shipping_dashboard']//div/label");
        public static readonly By color_pickingImpacted = By.XPath("//*[contains(text(),'Picking is Impacted')]");
        public static readonly By color_optimalperformance = By.XPath("//*[contains(text(),'Optimal Performance')]");
        public static readonly By link_viewDetails = By.XPath("//*[@class='button-content' and text()='View Details']");
        public static readonly By link_eastSorter = By.XPath("//*[@class='text' and text()='East Sorter']");
        public static readonly By dd_eastSorter3 = By.XPath("//*[text()='East Sorter2']");
        public static readonly By dd_list = By.XPath("//*[@class='visible menu transition']/div");
        public static readonly By graph_cartoons = By.XPath("//*[contains(text(),'Cartons per minute')]");
        public static readonly By graph_induction = By.XPath("//*[text()='Induction']");
        public static readonly By graph_capacity = By.XPath("//*[text()='Capacity']");
        public static readonly By graph_batches = By.XPath("//*[text()='Batches/Waves']");
        public static readonly By avgProdLossPanel = By.XPath("//*[contains(text(),'Average Production Loss')]");
        public static readonly By allThreeErrorAlertOnShipPanel = By.XPath("//*[contains(@class,'ui red circular label badge notification-badge') and text()='3']");
        public static readonly By avgLoss_Cartoons = By.XPath("//*[contains(text(),'Cartons Per Minute')]");

        //outbound page tooltip details
        public static readonly By tooltip_orderQuota = By.XPath("//*[@class='content' and text()='Total number of orders planned for the day in DC']");
        public static readonly By tooltip_currentplan = By.XPath("//*[@class='content']");
        public static readonly By tooltip_picked = By.XPath("//*[@class='content' and text()='Number of order pick completed']");
        public static readonly By tooltip_shipped = By.XPath("//*[@class='content' and text()='Number of orders shipped completed']");
        public static readonly By tooltip_ship = By.XPath("//*[@class='content' and text()='Number of order ship completed']");
        public static readonly By tooltip_Asset = By.XPath("//*[@class='content' and text()='Total downtime of all assets in the warehouse']");
        public static readonly By tooltip_efficiency = By.XPath("//*[@class='content' and text()='Performance of DC based on actual throughput rate vs designed rate']");

        //outbound page text details
        public static readonly By text_orderQuota = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'ORDER')]");
        public static readonly By text_currentplan = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'CURRENT')]");
        public static readonly By text_picked = By.XPath("//*[contains(text(),'Picked')]");
        public static readonly By text_shipped = By.XPath("//*[contains(text(),'Shipped')]");
        public static readonly By text_asset = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'ASSET')]");
        public static readonly By text_efficiency = By.XPath("(//*[contains(text(),'EFFICIENCY')])[1]");

        //shipping page text details
        public static readonly By text_shipping_orderQuota = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'ORDER')]");
        public static readonly By text_shipping_currentplan = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'CURRENT/')]");
        public static readonly By text_shipping_asset = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'ASSET')]");
        public static readonly By tooltip_shipping_asset = By.XPath("//*[@class='content' and text()='Total number of orders planned for shipping in DC']");
        public static readonly By tooltip_shipping_currentplan = By.XPath("(//*[@class='content'])[2]");

        //Plant Health
        public static readonly By header_plantHealth1 = By.XPath("//div[@class='assert-overall-summary assertOverallSumary']/div/div/div");
        public static readonly By header_plantHealth2 = By.XPath("//div[@class='assertOverallSumary_card']/div");
        public static readonly By header_plantHealth_Name = By.XPath("//*[@class='dashboard-title' and contains(text(),'Plant Health')]");
        public static readonly By dd_allArea = By.XPath("//div[@class='ui multiple search selection dropdown']");
        public static readonly By dd_allArea_option = By.XPath("//div[@class='visible menu transition']/div[@role='option']");
        public static readonly By placeholder = By.XPath("//input[@placeholder='This Week']");
        public static readonly By riskMatrix = By.XPath("//div[@class='card-header-text' and text()='RISK MATRIX']");
        public static readonly By fault_asset = By.XPath("//button[@type='button']/div");
        public static readonly By AssetPriority = By.XPath("//div[@class='legend-Priority' and contains(text(),'Asset Priority')]");
        //public static readonly By AssetPriority = By.XPath("//div[@class='legend-Priority' and contains(text(),'Asset Priority')]");





        #endregion

        


    }
}
