﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace FAPM_Driver.AutomationModel
{
    public static class PODashboard
    {

        #region PO Dashboard Login
        public static readonly By user_name1 = By.XPath("//*[contains(@name,'username') and @class='input-box']");
        public static readonly By click_NextBtn = By.XPath("//*[@class='button-content' and text()='Next']");
        public static readonly By user_name2 = By.Id("username");
        public static readonly By password = By.Id("password");
        public static readonly By signin_btn = By.XPath("//button[@type='submit' and @id='btnregisteraccount']");
        public static readonly By menu_button = By.XPath("//a[@class='item menu-btn-item']");
        public static readonly By siteoperation_button = By.XPath("//span[contains(text(), 'Site Operation')]");
        public static readonly By outbound_button = By.XPath("//span[contains(text(), 'Outbound')]");
        public static readonly By outbound_arrow = By.XPath("//*[@class='link item']/i[2]");
        public static readonly By clickOn_OpsDashboard = By.XPath("//span[text()='Ops Dashboard']");
        public static readonly By close_button = By.XPath("//div[@class='pin-and-close']//i");
        public static readonly By getUserName = By.XPath("//div[@class='account-holder-name']/div");
        public static readonly By signinbtn1 = By.XPath("//span[text()='Sign In']");
        public static readonly By signinbtn = By.XPath("//button[@type='submit']/span[text()='Sign On']");
        public static readonly By timeOut = By.XPath("//h3[text()='TIMEOUT']");
        public static readonly By header_HoneywellForge = By.XPath("//*[text()='HONEYWELL FORGE']");
        public static readonly By click_ApprovBtn = By.XPath("//span[text()='Approve']");

        #endregion

        #region Outbondpage
        public static readonly By outbound_header = By.XPath("//span[text()='Outbound Operations']");
        public static readonly By order_current_asset = By.XPath("//div[@class='order_metric_section_outbound_dashboard']/label");
        public static readonly By picked_shipped = By.XPath("//div[@class='progress_bar_metric_outbound_dashboard']//div/label");
        public static readonly By viewbyday_button = By.XPath("//div[@class='button-content' and contains(text(), 'View By Day')]");
        public static readonly By viewbyshift_button = By.XPath("//div[@class='button-content' and contains(text(), 'View By Shift')]");
        public static readonly By viewbyday_button1 = By.XPath("//div[@class='button-content' and contains(text(), 'View by Day')]");
        public static readonly By viewbyshift_button1 = By.XPath("//div[@class='button-content' and contains(text(), 'View by Shift')]");
        public static readonly By clickOnViewDetails = By.XPath("//div[text()='View Details']");
        public static readonly By asset_Selection = By.XPath("//*[@class='ui scuf-dropdown-wrapper po-all-asset-dropdown']/div/div[@role='alert']");
        public static readonly By assetClick_OneByOne = By.XPath("//*[@class='visible menu transition']/div");

        //Outbound Dashboard
        public static readonly By dynamicValue_orderQuota = By.XPath("(//div[@class='order_metric_section_outbound_dashboard']/label)[2]");
        public static readonly By dynamicValue_currentPlan = By.XPath("(//div[@class='order_metric_section_outbound_dashboard']/label)[4]");
        public static readonly By dynamicValue_orderQuotaPicked = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[1]");
        public static readonly By dynamicValue_PickedProgressBar = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[3]");
        public static readonly By dynamicValue_orderQuotaShipped = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[4]");
        public static readonly By dynamicValue_ShippedProgressBar = By.XPath("(//div[@class='progress_bar_metric_outbound_dashboard']//div/label)[6]");
        public static readonly By dynamicValue_assetDowntime = By.XPath("(//div[@class='order_metric_section_outbound_dashboard']/label)[6]");
        public static readonly By dynamicValue_CurrentPlan_Time = By.XPath("//*[@class='metric_name_outbound_dashboard current-metrics']/span");
        public static readonly By dynamicValue_ShippedProgressBar_shipping = By.XPath("//div[@class='progress_bar_metric_shipping_dashboard']/div/div[2]/div[2]/label");

        public static readonly By picking_values = By.XPath("//*[@class='current_plan']/div/p");
        public static readonly By picking_text = By.XPath("//*[@class='current_plan']/div/span");
        public static readonly By cartons = By.XPath("//*[text()='Cartons Current Rate/ hr']");
        public static readonly By picking_name = By.XPath("//*[text()='PICKING']");
        public static readonly By optimal_text = By.XPath("//*[text()='Optimal Performance']");
        public static readonly By optimal_desc = By.XPath("//*[text()='You have reached/exceeded the planned rate !']");
        public static readonly By picking_description_error = By.XPath("//*[@class='outbound-dashboard-picking-card']/div[2]/span");
        public static readonly By totalcart = By.XPath("//*[text()='Total Cartons']");
        public static readonly By time = By.XPath("//*[text()='Time(hrs)']");
        public static readonly By throughput = By.XPath("//*[text()='Throughput']");
        public static readonly By cartons_value = By.XPath("//*[@class='cartoon_estimate']/div/p/span");
        public static readonly By cartons_text = By.XPath("//*[@class='cartoon_estimate']/div/p");
        public static readonly By picking_graph_values = By.XPath("//div[@class='outbound-dashboard-picking-card']/div[4]//span");
        public static readonly By dynamicValue_Picking_CurrentPlan = By.XPath("(//*[@class='current_plan']/div/p)[1]");
        public static readonly By dynamicValue_Picking_Expected = By.XPath("(//*[@class='current_plan']/div/p)[2]");
        public static readonly By dynamicValue_Picking_Released = By.XPath("(//*[@class='current_plan']/div/p)[3]");
        public static readonly By dynamicValue_Picking_Efficiency = By.XPath("(//*[@class='current_plan']/div/p)[4]");
        public static readonly By dynamicValue_Picking_OnlyCurrent = By.XPath("(//*[@class='current_plan']/div/p)[1]/span");

        public static readonly By dynamicValue_Picking_badgeTextbtn = By.XPath("//div[@class='badge_picking']/div");
        public static readonly By dynamicValue_notification_textselected = By.XPath("//div[@class='badges-wrapper']/div");
        public static readonly By dynamic_assetcount = By.XPath("//div[@class='notifcations-wrapper']/div");
        public static readonly By dynamic_avgThroughput = By.XPath("(//div[@class='shipping-dashboard-throughput-card-graph']/div/div/span)[1]");
        public static readonly By dynamic_cpm_value = By.XPath("//div[@class='highcharts-axis-labels highcharts-yaxis-labels']/span");

        public static readonly By shipping_values = By.XPath("//*[@class='current_plans']/div/p");
        public static readonly By dynamicValue_Shipping_CurrentPlan = By.XPath("(//*[@class='current_plans']/div/p)[1]");
        public static readonly By dynamicValue_Shipping_Expected = By.XPath("(//*[@class='current_plans']/div/p)[2]");
        public static readonly By dynamicValue_Shipping_Shipped = By.XPath("(//*[@class='current_plans']/div/p)[3]");
        public static readonly By dynamicValue_Shipping_Efficiency = By.XPath("(//*[@class='current_plans']/div/div/p)");
        public static readonly By dynamicValue_Shipping_OnlyCurrent = By.XPath("(//*[@class='current_plans']/div/p)[1]/span");
        public static readonly By shipping_text = By.XPath("//*[@class='current_plans']/div/span");
        public static readonly By shipping_name = By.XPath("//*[text()='SHIPPING']");
        public static readonly By shipping_description_error = By.XPath("//*[@class='outbound-dashboard-shipping-card']/div[2]/div[2]/span");
        public static readonly By asset_text = By.XPath("//*[text()='Picking is Impacted'] | //*[text()='Optimal Performance']");
        public static readonly By optimal_performance = By.XPath("//*[contains(text(),'You have reached/exceeded the planned rate !')]");
        public static readonly By shipping_graph_values = By.XPath("//div[@class='outbound-dashboard-shipping-card']/div[4]//span");
        public static readonly By order_current_asset_shipping = By.XPath("//div[@class='order_metric_section_shipping_dashboard']/label");
        public static readonly By shipped_shipping = By.XPath("//div[@class='progress_bar_metric_shipping_dashboard']//div/label");
        public static readonly By color_pickingImpacted = By.XPath("//*[contains(text(),'Picking is Impacted')]");
        public static readonly By color_optimalperformance = By.XPath("//div[@class='shipping-status-label']/label[contains(text(),'Optimal Performance')]");
        public static readonly By AssetIsImpacted = By.XPath("//*[contains(text(),'Asset is Impacted')]");
        public static readonly By link_viewDetails = By.XPath("//*[@class='button-content' and text()='View Details']");
        public static readonly By link_viewDetails2 = By.XPath("(//*[@class='button-content' and text()='View Details'])[2]");
        public static readonly By link_viewDetails1 = By.XPath("(//*[@class='button-content' and text()='View Details'])[1]");
        public static readonly By click_OnSorter = By.XPath("(//*[@class='ui selection dropdown'])[1]");
        public static readonly By clickOn_UpperSorter = By.XPath("//*[@class='visible menu transition']/div[text()='Upper Sorter 2'] ");
        public static readonly By clickOn_LowerSorter = By.XPath("//*[@class='visible menu transition']/div[text()='Lower Sorter 2'] ");
        public static readonly By dd_list = By.XPath("//*[@class='visible menu transition']/div");
        public static readonly By graph_cartoons = By.XPath("//*[contains(text(),'Cartons per minute')]");
        public static readonly By graph_induction = By.XPath("//*[text()='Induction']");
        public static readonly By graph_capacity = By.XPath("//*[text()='Capacity']");
        public static readonly By graph_batches = By.XPath("//*[text()='Batches/Waves']");
        public static readonly By avgProdLossPanel = By.XPath("//*[contains(text(),'Average Production Loss')]");
        public static readonly By allThreeErrorAlertOnShipPanel = By.XPath("//*[contains(@class,'ui red circular label badge notification-badge') and text()='3']");
        public static readonly By avgLoss_Cartoons = By.XPath("//*[contains(text(),'Cartons Per Minute')]");
        public static readonly By Shipping_Header = By.XPath("//*[@class='shipping-dashboard-header']/div/div/span[text()='Shipping']");
        public static readonly By Picking_Header = By.XPath("//*[@class='picking-dashboard-header']/div/div/span[text()='Picking']");
        public static readonly By LeftArrowOf_OutboundOperation = By.XPath("//*[@class='h-icon global caret-left'] | //*[@class='shipping-dashboard-content shipping-dashoard-common-style']/div/div/a[contains(text(),'Outbound')]");
        public static readonly By LeftArrowOf_OutboundOperation_pickDB = By.XPath("//*[@class='h-icon global caret-left'] | //*[@class='picking-dashboard-content picking-dashoard-common-style']/div/div/a[contains(text(),'Outbound')]");

        //outbound page tooltip details
        public static readonly By tooltip_orderQuota = By.XPath("//*[@class='content' and text()='Total number of orders planned for the day in DC']");
        public static readonly By tooltip_currentplan = By.XPath("//*[@class='content']");
        public static readonly By tooltip_picked = By.XPath("//*[@class='content' and text()='Number of orders picked']");
        public static readonly By tooltip_shipped = By.XPath("//*[@class='content' and text()='Number of orders shipped']");
        public static readonly By tooltip_ship = By.XPath("//*[@class='content' and text()='Number of orders shipped']");
        public static readonly By tooltip_Asset = By.XPath("//*[@class='content' and text()='Average downtime of all the assets in the warehouse']");
        public static readonly By tooltip_AssetDowntime_PickingDashboard = By.XPath("//*[@class='content' and text()='Average downtime of all picking assets in the warehouse']");
        public static readonly By tooltip_efficiency = By.XPath("//*[@class='content' and text()='Performance of picking based on actual throughput rate vs designed rate']");

        //Ops dashboard text details
        public static readonly By text_orderQuota = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'ORDER')]");
        public static readonly By text_currentplan = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'CURRENT')]");
        public static readonly By text_picked = By.XPath("//*[contains(text(),'Picked')]");
        public static readonly By text_shipped = By.XPath("//*[contains(text(),'Shipped')]");
        public static readonly By text_asset = By.XPath("//*[@class='order_metric_section_outbound_dashboard']/label[1][contains(text(),'ASSET')]");
        public static readonly By text_efficiency = By.XPath("(//*[contains(text(),'EFFICIENCY')])[1]");

        #region Picking Dashboard

        //Picking dashboard text details
        public static readonly By text_picking_orderQuota = By.XPath("//*[@class='order_metric_section_picking_dashboard']/label[1][contains(text(),'ORDER')]");
        public static readonly By text_picking_currentplan = By.XPath("//*[@class='order_metric_section_picking_dashboard']/label[1][contains(text(),'CURRENT/')]");
        public static readonly By text_picking_asset = By.XPath("//*[@class='order_metric_section_picking_dashboard']/label[1][contains(text(),'ASSET')]");

        //Picking Dashboard
        public static readonly By dynamicValue_orderQuota_forPicking = By.XPath("(//div[@class='order_metric_section_picking_dashboard']/label)[2]");
        public static readonly By dynamicValue_currentPlan_forPicking = By.XPath("(//div[@class='order_metric_section_picking_dashboard']/label)[4]");
        public static readonly By dynamicValue_picked_forPicking = By.XPath("(//div[@class='progress_bar_metric_picking_dashboard']//div/label)[1]");
        public static readonly By dynamicValue_assetDowntime_forPicking = By.XPath("(//div[@class='order_metric_section_picking_dashboard']/label)[6]");

        //Pick module and Filter
        //public static readonly By clk_filter = By.XPath("//div[@class='ui scuf-dropdown-wrapper dt-select']/div/div[text()='Filter']");
        public static readonly By clk_filter = By.XPath("(//div[@class='ui scuf-dropdown-wrapper dt-select']/div/div)[1]");
        public static readonly By filter_DD = By.XPath("//div[@class='visible menu transition']/div");
        public static readonly By pickModule_picking_row = By.XPath("//table/tbody/tr");
        public static readonly By pickModule_picking_column = By.XPath("//table/thead/tr/th");
        public static readonly By close_openKpi = By.XPath("//div[contains(text(),'Showing')]//parent::div/div[3]/div/i");
        public static readonly By ClickOnFilterDD = By.XPath("//div[@class='ui scuf-dropdown-wrapper dt-select']/div/div[text()='Filter']");

        //tool tip
        public static readonly By tooltip_orderQuota_shift = By.XPath("//*[@class='content' and text()='Total number of orders planned for the shift in DC']");

        public static readonly By assetUtilize_keyKPIName = By.XPath("//div[@class='dt-tooltip-content-wrapper']/div/div[2]");
        public static readonly By assetUtilize_ValueOfKPIName = By.XPath("//div[@class='dt-tooltip-item-value']");
        public static readonly By clickOnPickMod1 = By.XPath("//div[text()='DC3PickMod1']/parent::div/parent::td//following-sibling::td[5]");
        public static readonly By clickOnPickMod2 = By.XPath("//div[text()='DC3PickMod2']/parent::div/parent::td//following-sibling::td[5]");
        public static readonly By clickOnPickMod3 = By.XPath("//div[text()='DC3PickMod3']/parent::div/parent::td//following-sibling::td[5]");

        #endregion

        //shipping dashboard text details
        public static readonly By text_shipping_orderQuota = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'ORDER')]");
        public static readonly By text_shipping_currentplan = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'CURRENT/')]");
        public static readonly By text_shipping_asset = By.XPath("//*[@class='order_metric_section_shipping_dashboard']/label[1][contains(text(),'ASSET')]");
        public static readonly By tooltip_shipping_asset = By.XPath("//*[@class='content' and text()='Total number of orders planned for shipping in DC']");
        public static readonly By tooltip_shipping_currentplan = By.XPath("(//*[@class='content'])[2]");
        public static readonly By tooltip_shipping_shipped = By.XPath("//*[@class='content' and text()='Number of orders shipped']");

        //Shipping Dashboard
        public static readonly By dynamicValue_orderQuota_forShipping = By.XPath("(//div[@class='order_metric_section_shipping_dashboard']/label)[2]");
        public static readonly By dynamicValue_currentPlan_forShipping = By.XPath("(//div[@class='order_metric_section_shipping_dashboard']/label)[4]");
        public static readonly By dynamicValue_Shipped = By.XPath("(//div[@class='progress_bar_metric_shipping_dashboard']//div/label)[1]");
        public static readonly By dynamicValue_Shipped_shippedProgressbar = By.XPath("(//div[@class='progress_bar_metric_shipping_dashboard']//div/label)[3]");
        public static readonly By dynamicValue_Picked_pickedProgressbar = By.XPath("(//div[@class='progress_bar_metric_picking_dashboard']//div/label)[3]");
        public static readonly By dynamicValue_assetDowntime_forShipping = By.XPath("(//div[@class='order_metric_section_shipping_dashboard']/label)[6]");

        //Shipping Dashboard
        public static readonly By dropdown_abortText = By.XPath("//*[@class='shipping-dashboard-throughput-card-info']/ul/li/span[text()='Downtime']");
        public static readonly By dropdown_sorter = By.XPath("(//div[@class='ui scuf-dropdown-wrapper ui__multiselect']/div/div)[1]");
        public static readonly By AverageProductionLoss = By.XPath("(//div[@class='chart-legend'])[1]/div");
        public static readonly By SorterUtilization = By.XPath("(//div[@class='chart-legend'])[2]/div");
        public static readonly By ErrorKPi = By.XPath("//span[@title='No Reads']");
        public static readonly By RecirculationRate = By.XPath("//span[@title='RecirculationPercent']");
        public static readonly By FullLanes = By.XPath("//span[@title='Full Lanes']");
        public static readonly By CApacity = By.XPath("//*[text()='Capacity']");
        public static readonly By All_AvgProductionLoss_Utilization = By.XPath("//ul[@class='all_reasons']/li/span[1]");
        public static readonly By click_AllAvgprodUtilizationDD = By.XPath("(//*[@class='ui selection dropdown' and @role='listbox'])[3]");
        public static readonly By AvgProdUtiAllDD_UI = By.XPath("//li[@class='all_reasons_text']//span");
        public static readonly By Utilize_DD1 = By.XPath("//li[@class='all_reasons_text']/span[2]");
        public static readonly By Utilize_DD2 = By.XPath("//li[@class='all_reasons_text']/div/span");
        public static readonly By Utilize_DD3 = By.XPath("//div[@class='buttons-wrapper']//span");

        //Error Kpi
        public static readonly By Noread = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[1]");
        public static readonly By RecirculationRates = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[2]");
        public static readonly By FullLane = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[3]");
        public static readonly By btn_expand = By.XPath("(//*[@class='maximize-icon'])[1]/div");

        //Error kpi in expansion mode on Shipping Dashboard
        public static readonly By Noread_expansion = By.XPath("(//div[@class='ui small modal transition visible active shipping-dashboard-error-kpi shipping-dashoard-common-style error-kpi-modal has-close-icon']//span[@class='header__title' and @title='No Reads']//following::span)[1]");
        public static readonly By RecirculationRates_expansion = By.XPath("(//div[@class='ui small modal transition visible active shipping-dashboard-error-kpi shipping-dashoard-common-style error-kpi-modal has-close-icon']//span[@class='header__title' and @title='No Reads']//following::span)[5]");
        public static readonly By GappingError_expansion = By.XPath("(//div[@class='ui small modal transition visible active shipping-dashboard-error-kpi shipping-dashoard-common-style error-kpi-modal has-close-icon']//span[@class='header__title' and @title='No Reads']//following::span)[13]");
        public static readonly By TrackingError_expansion = By.XPath("(//div[@class='ui small modal transition visible active shipping-dashboard-error-kpi shipping-dashoard-common-style error-kpi-modal has-close-icon']//span[@class='header__title' and @title='No Reads']//following::span)[17]");
        public static readonly By FullLane_expansion = By.XPath("(//div[@class='ui small modal transition visible active shipping-dashboard-error-kpi shipping-dashoard-common-style error-kpi-modal has-close-icon']//span[@class='header__title' and @title='No Reads']//following::span)[21]");

        public static readonly By click_shippingSelectionDD = By.XPath("(//div[@menuplacement='top']/div[@aria-live='polite'])[2]");


        #endregion

        #region Panda DAshboard

        public static readonly By Mislabeled_errorKpi_expanded = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[2]");
        public static readonly By Tracking_errorKpi_expanded = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[4]");
        public static readonly By Scanner_errorKpi_expanded = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[5]");

        public static readonly By Tracking_errorKpi = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[3]");
        public static readonly By Scanner_errorKpi = By.XPath("(//div[@class='key-value-errorkpi vertical-content vertical-suffix-only align-left'])[1]");
        public static readonly By ErrorKPI_Header = By.XPath("//span[text()='Error KPIs']");
        public static readonly By clk_Expandbtn = By.XPath("//button[@class='ui medium button primary error-kpi-fullscreen-button']/div");
        public static readonly By totalCartons = By.XPath("(//div[@class='ui horizontal list scuf-list-wrapper  productivity-kpi-list-item']/div/div)[2]");
        public static readonly By totalrejects = By.XPath("(//div[@class='ui horizontal list scuf-list-wrapper  productivity-kpi-list-item']/div/div)[4]");
        public static readonly By avgCartonLength = By.XPath("(//div[@class='ui horizontal list scuf-list-wrapper  productivity-kpi-list-item']/div/div)[6]");
        public static readonly By activeLabelers = By.XPath("(//div[@class='ui horizontal list scuf-list-wrapper  productivity-kpi-list-item']/div/div)[8]");
        public static readonly By closeErrorKpiWindow = By.XPath("//span[@class='close-icon-wrap']/i");
        public static readonly By ProductivityKPI_Header = By.XPath("//div[text()='PRODUCTIVITY KPIs ']");

        #endregion

        #region Notification
        public static readonly By clickOnNotification_icon = By.XPath("(//div[@class='bell-icon-red']/a)[1]");
        //public static readonly By closeNotification_icon = By.XPath("//i[@class='h-icon global close scuf-small']");
        public static readonly By closeNotification_icon = By.XPath("(//a[@class='item'])[1]");
        public static readonly By header_notification = By.XPath("//div[text()='Notifications']");
        public static readonly By btn_viewAll = By.XPath("//div[text()='View all']");
        public static readonly By btn_filterSort = By.XPath("//div[@class='notification-content notification-top-container']/div[2]/button[2]/div[text()='Filter & Sort']");
        public static readonly By header_sortFilter = By.XPath("//div[text()='FILTER & SORT']");
        public static readonly By btn_clearAll = By.XPath("//div[text()='Clear all']");
        public static readonly By btn_chooseAsort = By.XPath("//div[@class='default text' and text()='Choose a sort by']");
        public static readonly By btn_DateDescending = By.XPath("//div[@role='option' and text()='Date Descending']");
        public static readonly By sortByOldestToNewest = By.XPath("(//div[@class='visible menu transition']/div)[1]");
        public static readonly By btn_DateAscending = By.XPath("//div[@role='option' and text()='Date Ascending']");
        public static readonly By btn_assetName = By.XPath("//div[@class='notification-filters-section']/div/div/div[text()='Asset Name']/i");
        public static readonly By checkbox_selection = By.XPath("//div[@class='ui checkbox check-box']/label");
        public static readonly By btn_category = By.XPath("//div[@class='title' and text()='Category']");
        public static readonly By checkbox_selectionForCategory = By.XPath("(//div[@class='filter-accordion-options-wrapper' ])[2]/div/label");//it will capture all checkbox of category
        public static readonly By click_OnPriority = By.XPath("//div[@class='title' and text()='Priority']");
        public static readonly By select_PriorityFromDD = By.XPath("//div[@class='content active']/div/div/label");
        public static readonly By btn_showResult = By.XPath("//div[text()='Show Result']");
        public static readonly By verify_allSortAndFilterData = By.XPath("//div[@class='notification-filter-badge-wrapper']/div/div");//display all selected text
        public static readonly By verify_assetName = By.XPath("//div[@class='notifcation-details']/div");
        public static readonly By text_Low = By.XPath("//div[@class='notification-tag-wrapper']/div/span[text()='LOW']");
        public static readonly By text_AssetNotification = By.XPath("//div[@class='notification-tag-wrapper']/div[text()='Asset']");
        public static readonly By text_EventDetails = By.XPath("//div[@class='active title' and text()='Event Details']");
        public static readonly By text_description = By.XPath("//div[text()='Description']");
        public static readonly By text_cause = By.XPath("//div[text()='Cause']");
        public static readonly By text_consequence = By.XPath("//div[text()='Consequence']");
        public static readonly By text_recommenedation = By.XPath("//div[text()='Recommenedations']");
        public static readonly By text_addObservation = By.XPath("//div[text()='Add Observations']");
        public static readonly By text_faultCategory = By.XPath("//div[text()='Fault Category']");

        public static readonly By click_FaultCategory = By.XPath("//div[text()='Choose a category']");
        public static readonly By Select_firstCategory = By.XPath("//div[@class='visible menu transition']/div[1]");
        public static readonly By click_ChooseReason = By.XPath("//div[@class='default text' and text()='Choose a reason']");
        public static readonly By Select_firstReason = By.XPath("//div[@class='visible menu transition']/div[1]");
        public static readonly By click_CloseEvent = By.XPath("//div[text()='Close Event']");

        public static readonly By text_additionalComments = By.XPath("//span[@class='scuf-textarea-wrapper onchange-select']/textarea[contains(@placeholder,'Add additional comments')]");
        public static readonly By checkbox_operatingLimit = By.XPath("(//div[@class='filter-accordion-options-wrapper'])[2]/div[1]");
        public static readonly By text_reason = By.XPath("//div[text()='Reason']");
        public static readonly By text_relatedInfo = By.XPath("//*[@class='title' and text()='Related Information']");
        public static readonly By btn_save = By.XPath("//div[text()='Save']");
        public static readonly By btn_back = By.XPath("//div[@class='notification-details-back']/i");
        public static readonly By btn_closeNotificationWindow = By.XPath("//button[@class='ui medium button primary notification-close-button']/div/i");
        public static readonly By text_notificationtymForAscendingDescending = By.XPath("//div[@class='notification-time']");//all tym
        public static readonly By btn_FilterClear = By.XPath("//div[@class='filter-clear']/i");
        public static readonly By description_AllFault = By.XPath("//div[@class='notifcations-wrapper']/div/div[3]/div[3]");



        #endregion

        #region ForgeLogin

        public static readonly By user_name = By.XPath("//input[@name='username']");
        public static readonly By password_ = By.XPath("//input[@name='password']");
        public static readonly By sign_in = By.XPath("//span[text()='Sign IN']");
        public static readonly By username_header = By.XPath("//span[text()='Email or Username']");
        #endregion ForgeLogin

        #region BulkConfig
        public static readonly By forge_title = By.XPath("//div[text()='HONEYWELL FORGE']");
        public static readonly By config_button = By.XPath("//div[text()='Config']");
        public static readonly By bulk_config_dashboard_title = By.XPath("//span[text()='Bulk model configuration']");
        public static readonly By import_button = By.XPath("//div[@class='button-content' and text()='Import']");
        public static readonly By export_button = By.XPath("//div[@class='button-content' and text()='Export']");
        public static readonly By import_files_header_text = By.XPath("//div[@class='header-text header' and text()=' Import files']");
        public static readonly By browse_files = By.XPath("//div[@class='button-content' and text()='Browse Files']");
        public static readonly By back_button = By.XPath("//div[@class='button-content' and text()='Back']");
        public static readonly By next_button = By.XPath("//div[@class='button-content' and text()='Next']");
        public static readonly By message_text = By.XPath("//div[@class='message-file']//span[text()='Do not have attribute mapping view template file?']");
        public static readonly By download_button = By.XPath("//div[@class='button-content' and text()='Download']");
        public static readonly By reset_file_button = By.XPath("//div[@class='button-content' and text()='Reset File']");
        public static readonly By file_name_text = By.XPath("//div[@class='file-name']");
        public static readonly By success_message = By.XPath("//span[text()='Successfully Proceeded. Do you want to proceed?']");
        public static readonly By proceed_button = By.XPath("//div[@class='button-content' and text()='Proceed']");

        #endregion BulkConfig

    }
}
