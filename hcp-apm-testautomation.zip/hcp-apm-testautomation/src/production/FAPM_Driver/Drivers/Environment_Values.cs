﻿using System.Collections.Generic;

namespace FAPM_Driver.Drivers
{
    public static class Environment_Values
    {
        public static string DBConnection;

        public static string DataAPIServer;

        public static string QueryUrl;

        public static string EventMgmtServer;

        public static string GetAssetFaultCountDataEndPoint;

        public static string GetFailureFaultCountDataEndPoint;

        public static string GetHeatMapMatrixEndPoint;

        public static string GetFaultCategoryDataEndPoint;

        public static string UpdateNotificationDataEndPoint;

        public static string GetReasonCodeDataEndPoint;

        public static string GetEventDataEndPoint;

        public const string dashboardUrl_Stage_Ops = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/outboundoperations";

        public const string dashboardUrl_Stage_Shipping = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/shippingdashboard";

        public const string dashboardUrl_Stage_Picking = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/pickingdashboard";

        public const string dashboardUrl_Stage_Panda = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/pandadashboard";

        public const string dashboardUrl_QA_Ops = "https://apmui-qa.dev.forge.connected.honeywell.com/projects/plutodev2021/#/operations/outboundoperations";

        public const string dashboardUrl_QA_Shipping = "https://apmui-qa.dev.forge.connected.honeywell.com/projects/plutodev2021/#/operations/shippingdashboard";

        public const string dashboardUrl_QA_Picking = "https://apmui-qa.dev.forge.connected.honeywell.com/projects/plutodev2021/#/operations/pickingdashboard";

        public const string dashboardUrl_QA_Panda = "https://apmui-qa.dev.forge.connected.honeywell.com/projects/plutodev2021/#/operations/pandadashboard";

        //public const string dashboardUrl = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/outboundoperations";

        public const string dashboardUrl = "https://apmui-stage.dev.forge.connected.honeywell.com";

        public const string dashboardUrl1 = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/operations/outboundoperations";

        public const string dashboardUrl2 = "https://apmui-stage.dev.forge.connected.honeywell.com/#/operations/outboundoperations?customerId=idd7d9dccd-d29a-44af-bbdf-6a86e584b21c";

        public const string podashboardUrl = "https://dashboardui-qa.dev.forge.connected.honeywell.com/#/outboundoperations";

        public const string assetHealthDasboardUrl = "https://apmui-stage.dev.forge.connected.honeywell.com/projects/sit2/#/dashboard/plant-health-dashboard?rootNode=Alaska&customerType=both&KpiGroupName=PerformanceKPI&Title=Asset%20Health";

        //public const string userName = "H472492";
        //public const string password = "=NC#s1$]qD";

        public const string userName = "H381125";
        public const string password = "Welcome@22";

        //public const string userName = "H463692";
        //public const string password = "123@Augmento";

        public const string bulkImportUrl = "https://dashboardui-qa.dev.forge.connected.honeywell.com/#/assets/importexport";

        public const string token_username = "sit2-bg-svc";
        public const string token_password = "P@ssword123!";
    }

    public class Helper
    {
        public static void FillEnvironment_Values()
        {
            //var settings = new ConfigurationBuilder().AddJsonFile(@"C:\MyProjects\testautomation\FAPM_Automation\appsettings.json", optional: true, reloadOnChange: true).Build();
            //var settings = new ConfigurationBuilder().AddJsonFile(Directory.GetCurrentDirectory().Split("FAPM_Features")[0].Trim() +@"\appsettings.json", optional: true, reloadOnChange: true).Build();
            //Environment_Values.DBConnection = settings["EnvironmentValues:DBConnection"].ToString();
            //Environment_Values.DataAPIServer = settings["EnvironmentValues:dataAPIserver"].ToString();
            //Environment_Values.QueryUrl = settings["EnvironmentValues:queryUrl"].ToString();
            //Environment_Values.EventMgmtServer = settings["EnvironmentValues:eventMgmtServer"].ToString();
            //Environment_Values.GetAssetFaultCountDataEndPoint = settings["EnvironmentValues:getAssetFaultCountDataEndPoint"].ToString();
            //Environment_Values.GetFailureFaultCountDataEndPoint = settings["EnvironmentValues:getFailureFaultCountDataEndPoint"].ToString();
            //Environment_Values.GetHeatMapMatrixEndPoint = settings["EnvironmentValues:getHeatMapMatrixEndPoint"].ToString();
            //Environment_Values.GetFaultCategoryDataEndPoint = settings["EnvironmentValues:getFaultCategoryDataEndPoint"].ToString();
            //Environment_Values.UpdateNotificationDataEndPoint = settings["EnvironmentValues:updateNotificationDataEndPoint"].ToString();
            //Environment_Values.GetReasonCodeDataEndPoint = settings["EnvironmentValues:getReasonCodeDataEndPoint"].ToString();
            //Environment_Values.GetEventDataEndPoint = settings["EnvironmentValues:getEventDataEndPoint"].ToString();

            Environment_Values.DBConnection = "server=csp-fapm-elastic-qa-shared-sql.database.windows.net;database=csp-fapm-apmdb-sit2;user=fapmadmin;password=WZ0Nkzs78Mu9xCB2";
            Environment_Values.DataAPIServer = "https://apmui-stage.dev.forge.connected.honeywell.com/dataapi";
            Environment_Values.QueryUrl = "/api/query-templates/query?query=";
            Environment_Values.EventMgmtServer = "https://apmui-stage.dev.forge.connected.honeywell.com/eventapi";
            Environment_Values.GetAssetFaultCountDataEndPoint = "api/event/kpi/getAssetFaultCountData";
            Environment_Values.GetFailureFaultCountDataEndPoint = "/api/event/kpi/getFailureFaultCountData";
            Environment_Values.GetHeatMapMatrixEndPoint = "/api/event/kpi/getHeatmapMatrixData";
            Environment_Values.GetFaultCategoryDataEndPoint = "/api/Event/GetFaultCategoryData";
            Environment_Values.UpdateNotificationDataEndPoint = "/api/Event/UpdateNotification";
            Environment_Values.GetReasonCodeDataEndPoint = "/api/Event/GetReasonCodeData";
            Environment_Values.GetEventDataEndPoint = "/api/event";
        }
    }
}