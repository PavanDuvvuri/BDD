﻿using System;
using Newtonsoft.Json;
using AutomationFramework;
using System.Diagnostics;
using ILogger = Logging.ILogger;
using Logger = Logging.Logger;
using System.IO;
using FAPM_Driver.Share;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Net;
using System.Reflection;
using FAPM_Driver.Helpers;
using FAPM_Driver.Drivers;

namespace FAPM_Driver

{
    public class Driver
    {

        private static readonly ILogger _logger;
        private static IConfigurationRoot _appSettings;
        private readonly Uri _baseUri;
        private string _forgeIdentityBearerToken;
        private DateTime _tokenExpiresOn;
        private static readonly IConfigurationRoot appSettings;
        private readonly int _expireTime;

        static Driver()
        {
            _logger = new Logger(typeof(Driver));
            // Stream myFile = File.Create(@"C:\temps\APMMonitor" + DateTime.Now.ToString("yyyyMMdd") + ".log");
            //  Trace.Listeners.Add(new TextWriterTraceListener(myFile));

            _appSettings = appSettings;
        }

        public const int _success = 9;
        public const int _failure = 7;
        public const int _process_err = 3;
        public const int _exception = -1;
        public static string token = null;
        public static int column_length = 0;

        public static string GetAssetIds(string assetName)
        {
            if (assetName == "DC3LowerSortLane8")
            {
                return "6c2506f3-a802-4269-b714-7b15cc63acdd";
            }

            else if (assetName == "DC3RoutingSorter")
            {
                return "dcdb6942-005e-4393-a886-2bd834f50331";
            }

            else
            {
                return "068a43d4-447d-4ea0-8e4f-2c6d4d928236";
            }
        }

        public static string GetBearerToken()
        {
            var token = TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", "sit2-bg-svc", "P@ssword123!").Result.AccessToken;
            var bearerToken = Out_Values.tokenCategory + token;
            return bearerToken;
        }

        public static int DataAPI_ByAssets(string url, string query, string timeframe, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || Metrics_ByAsset || Call to Metrics_ByAsset");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + query + " " + timeframe;

                var token = GetBearerToken();
                var (responsecode, res) = Rest.Get_Restclient(url.Replace(" ", "%20").Replace(",", "%2C"), token, "Authorization", id);

                if (res == null) { return _failure; }

                var json_output = JsonConvert.DeserializeObject<dynamic>(res);
                var column_data = json_output["ResultSet"]["Schema"]["Columns"];

                for (int j = 0; j < column_data.Count; j++)
                {
                    Out_Values.DataAPI_json.Add((column_data[j]["Name"]).ToString());
                }

                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Metrics_ByAsset : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Metrics_ByAsset::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }

        }

        public static int EventsDataAPIResponse(string url, string query, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || EventsDataAPIResponse || Call to EventsDataAPIResponse");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                url = url + query;
                var token = GetBearerToken();
                var (responsecode, res) = Rest.Get_Restclient(url.Replace(" ", "%20").Replace(",", "%2C"), token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null)
                {
                    return _failure;
                }
                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("ResultSet") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["ResultSet"]["Data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }
                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || EventsDataAPIResponse : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("EventsDataAPIResponse::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getFaultCategoryData(string url, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || GetFaultCategoryData || Call to GetFaultCategoryData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var token = GetBearerToken();
                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("faultCategoriesResponse") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["faultCategoriesResponse"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }
                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetFaultCategoryData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetFaultCategoryData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getReasonCodeData(string url, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || GetReasonCodeData || Call to GetReasonCodeData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var token = GetBearerToken();
                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("reasonCodeResponse") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["reasonCodeResponse"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }
                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetReasonCodeData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetReasonCodeData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int KPIData_API(string url, string query, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || KPIData_API || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + query;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res)["ResultSet"]["Data"];
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || KPIData_API : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("KPIData_API::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int KPI_Target_Import_Service(string url, string filepath, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || KPIData_API || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                //string token = Environment_Values.token;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;
                var (responsecode, res) = Rest.Post_Restclient_UploadFile(url, filepath, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();

                if (res == null || responsecode != HttpStatusCode.Created) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || KPIData_API : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("KPIData_API::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }

        }
        public static int KPITarget_Export_Service(string url, string query, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || KPIData_API || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + query;
                //string token = Environment_Values.token;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;
                var (responsecode, res) = Rest.Get_Restclient(url.Replace(" ", "%20").Replace(",", "%2C"), token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || KPIData_API : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("KPIData_API::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }
        public static int KPI_Target_Service(string url, Dictionary<string, string> id, Dictionary<string, string> Queryparams)
        {
            _logger.Debug("Driver || KPI_Target_Service || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                //string token = Environment_Values.token;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;
                var (responsecode, res) = Rest.Get_Restclient_With_Params(url, token, "Authorization", id, Queryparams);
                Out_Values.ResponseCode = responsecode.ToString();

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res)["kpiTargetData"];

                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || KPI_Target_Service : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("KPI_Target_Service::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }

        }

        public static int KPI_Metric_Service(string url, Dictionary<string, string> id, Dictionary<string, string> Queryparams)
        {
            _logger.Debug("Driver || KPI_Metric_Service || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;
                var (responsecode, res) = Rest.Get_Restclient_With_Params(url, token, "Authorization", id, Queryparams);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || KPI_Metric_Service : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("KPI_Metric_Service::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }

        }

        public static int ReportConfiguration(string url, string query, Dictionary<string, string> id, Dictionary<string, string> data)
        {
            _logger.Debug("Driver || ReportConfiguration || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + query;
                //string token = Environment_Values.token;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;
                var temp = new JsonHelper();
                var raw_data = temp.ReportConfigurationResponsebody(data);
                var data_ = JsonConvert.SerializeObject(raw_data);

                var (responsecode, res) = Rest.Post_Restclient(url.Replace(" ", "%20").Replace(",", "%2C"), data_, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || ReportConfiguration : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("ReportConfiguration::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }
        public static string Authorization(string url, string client_id, string client_secret)
        {
            _logger.Debug("Driver || Authorization || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                Dictionary<string, string> headers = new Dictionary<string, string>();
                Dictionary<string, string> param = new Dictionary<string, string>();
                headers.Add("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
                param.Add("grant_type", "client_credentials");
                param.Add("resource", "http://cbpt01atqaweb.azurewebsites.net/");
                param.Add("client_id", client_id);
                param.Add("client_secret", client_secret);

                var (responsecode, res) = Rest.Post_Restclient_With_Params(url, "", "", headers, param, "");
                Out_Values.ResponseCode = responsecode.ToString();
                string access_token = JsonConvert.DeserializeObject<dynamic>(res)["access_token"];

                return access_token;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Authorization : Exception {0} ", ex.Message);
                return ex.Message;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Authorization::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int Tag_Value(string url, string token, string tagurl, string guid, List<string> tag_names)
        {
            _logger.Debug("Driver || Tag_Value || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                token = "Bearer " + token;
                url = url + guid + tagurl;

                string comma_string = string.Join("\",\"", tag_names);
                string data = "[\"" + comma_string + "\"]";

                var (responsecode, res) = Rest.Post_Restclient_With_Params(url, token, "Authorization", new Dictionary<string, string>(), new Dictionary<string, string>(), data);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Tag_Value : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Tag_Value::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }
        public static int Tag_List(string url, string token, string tagurl, string guid)
        {
            _logger.Debug("Driver || Tag_List || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + guid + tagurl;
                token = "Bearer " + token;

                Dictionary<string, string> id = new Dictionary<string, string>();

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();


                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Tag_List : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Tag_List::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int Points_history(string url, string token, string pointhistory_url, string guid, string startdate, string enddate, List<string> tag_names)
        {
            _logger.Debug("Driver || Points_history || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + guid + pointhistory_url;
                token = "Bearer " + token;

                var raw_data = new Reader().GetHtml("FAPM_Driver.JsonInput.points_history.json");

                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(raw_data);
                data["SystemGuid"] = guid;
                data["StartTime"] = startdate;
                data["EndTime"] = enddate;
                data["PointIds"] = tag_names;

                var (responsecode, res) = Rest.Post_Restclient(url, JsonConvert.SerializeObject(data), token, "Authorization", new Dictionary<string, string>());
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Points_history : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Points_history::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }
        public class Reader
        {
            public string GetHtml(string file)
            {
                using (var resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(file))
                {
                    if (resourceStream == null)
                        return null;

                    using (StreamReader reader = new StreamReader(resourceStream))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }

        }
        public static int DatasourceAPI(string url, string dsURL, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int DataSourcePost(string url, string dsURL, string dsname, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL;

                var raw_data = new Reader().GetHtml("FAPM_Driver.JsonInput.datasource.json");
                var data = JsonConvert.DeserializeObject<Dictionary<string, string>>(raw_data);
                data["name"] = dsname;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Post_Restclient(url, JsonConvert.SerializeObject(data), token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int DataSourceByName(string url, string dsURL, Dictionary<string, string> id, string dsname)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL + dsname;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int DataSourceDelete(string url, string dsURL, Dictionary<string, string> id, string dsname)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL + dsname;
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Delete_Restclient(url, token, "Authorization", id);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;
            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int DataSourceUpdate(string url, string dsURL, Dictionary<string, string> id, Dictionary<string, string> values)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL + values["name"];

                var raw_data = new Reader().GetHtml("FAPM_Driver.JsonInput.datasource.json");
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(raw_data);
                data["name"] = values["name"];
                data["description"] = values["description"];
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Put_Restclient(url, JsonConvert.SerializeObject(data), token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int GetEventsData(string url, Dictionary<string, string> id, int criticality, string assetName = null, string startDate = null, string endDate = null, string faultStatus = null, string assetId = null, string rootNode = null)
        {
            _logger.Debug("Driver || GetEventsData || Call to GetEventsData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var token = GetBearerToken();
                var temp = new JsonHelper();
                var postData = temp.EventsRequestBody(startDate, endDate, faultStatus, assetName, assetId, criticality, rootNode);
                var serializedData = JsonConvert.SerializeObject(postData);
                var (responsecode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);

                if (result.ContainsKey("assetFailureNotificationData") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["assetFailureNotificationData"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetEventsData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetEventsData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int healthtags_iot(string url, string dsURL, Dictionary<string, string> id, string dsname)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL + dsname + "/healthtags/iot";
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int healthtags_engine(string url, string dsURL, Dictionary<string, string> id, string dsname)
        {
            _logger.Debug("Driver || DatasourceAPI || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + dsURL + dsname + "/healthtags/engine";
                string token = "Bearer " + TokenHelper.GenerateToken("https://forge-identity-qa.dev.spec.honeywell.com", Environment_Values.token_username, Environment_Values.token_password).Result.AccessToken;

                var (responsecode, res) = Rest.Get_Restclient(url, token, "Authorization", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || DatasourceAPI : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("DatasourceAPI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int Read_Tag_Data(string url, string tagDataURL, List<string> tag_names, string startdate, string enddate, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || Read_Tag_Data || Call to KPIData_API");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                url = url + tagDataURL;

                var raw_data = new Reader().GetHtml("FAPM_Driver.JsonInput.read_tagdata.json");
                var data = JsonConvert.DeserializeObject<Dictionary<string, object>>(raw_data);
                data["tags"] = tag_names;
                data["startTime"] = startdate;
                data["endTime"] = enddate;

                var (responsecode, res) = Rest.Post_Restclient(url, JsonConvert.SerializeObject(data), "", "", id);
                Out_Values.ResponseCode = responsecode.ToString();
                Out_Values.KPIApi_json = JsonConvert.DeserializeObject<dynamic>(res);

                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }
                return _success;

            }
            catch (Exception ex)
            {
                _logger.Error("Driver || Read_Tag_Data : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Read_Tag_Data::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getFaultCountData(string url, string assetName, string startDate, string endDate, string category, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || GetFaultCountData || Call to GetFaultCountData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var token = GetBearerToken();
                var assetId = GetAssetIds(assetName);

                var temp = new JsonHelper();
                var postData = temp.FaultCountDataRequestBody(startDate, endDate, category, assetName, assetId);
                var serializedData = JsonConvert.SerializeObject(postData);

                var (responsecode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();

                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetFaultCountData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetFaultCountData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int updateNotificationRequest(string url, string assetId, string faultDisplayName, string timeStamp, string comments, string eventCategoryId, string reasonCode, string firstName, string lastName, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || UpdateNotificationRequest || Call to UpdateNotificationRequest");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var token = GetBearerToken();
                var temp = new JsonHelper();
                var postData = temp.updateNotificationRequest(timeStamp, assetId, faultDisplayName, eventCategoryId, comments, reasonCode, firstName, lastName);
                var serializedData = JsonConvert.SerializeObject(postData);

                var (responsecode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                Out_Values.ApiJsonOutput.Add(result);

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || UpdateNotificationRequest : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("UpdateNotificationRequest::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getHeatMapMatrixData(string url, string startTime, string endTime, string hierarchyName, string rootNode, string heatMapFor, Dictionary<string, string> id)
        {
            _logger.Debug("Driver || GetHeatMapMatrixData || Call to GetHeatMapMatrixData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var temp = new JsonHelper();
                var postData = temp.HeatmapMatrixDataRequest(startTime, endTime, hierarchyName, rootNode, heatMapFor);
                var serializedData = JsonConvert.SerializeObject(postData);
                var token = GetBearerToken();
                var (responsecode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                Out_Values.ResponseCode = responsecode.ToString();
                if (res == null || responsecode != HttpStatusCode.OK) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("datas") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["datas"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetHeatMapMatrixData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetHeatMapMatrixData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssets(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssets || Call to GetAssetsData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);
                var token = Out_Values.tokenCategory + response;
                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("assets") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["assets"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetsData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetsData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttributesEvents(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributesEventsData || Call to GetAssetAttributesEventsData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributesEventsData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributesEventsData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttributesTagMappingsAttributes(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributesTagMappingsAttributesData || Call to GetAssetAttributesTagMappingsAttributesData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributesTagMappingsAttributesData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributesTagMappingsAttributesData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttributesTagMappingsProperties(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributesTagMappingsPropertiesData || Call to GetAssetAttributesTagMappingsPropertiesData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributesTagMappingsPropertiesData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributesTagMappingsPropertiesData:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttributeProperties(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributeProperties || Call to GetAssetAttributeProperties");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]["assetAttributePropertiesDetails"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributeProperties : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributeProperties:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttributePropertiesEvents(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributePropertiesEvents || Call to GetAssetAttributePropertiesEvents");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributePropertiesEvents : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributePropertiesEvents:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetAttribute(string url, int pageNumber, int pageSize, string assetName, string assetType, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetAttributes || Call to GetAssetAttributes");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;
                var temp = new JsonHelper();
                var postData = temp.AssetAttributeBody(assetName, assetType, pageNumber, pageSize);
                var serializedData = JsonConvert.SerializeObject(postData);

                var (HttpStatusCode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("attributeList") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["attributeList"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetAttributes : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetAttributes:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetModels(string url, Dictionary<string, object> filterOptions, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetModelsData || Call to GetAssetModelsData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var urlParams = "";
                foreach (var (key, value) in filterOptions)
                {
                    if (filterOptions[key] != null)
                    {
                        urlParams += key + "=" + value + " ";
                    };
                };

                var mainUrl = url + urlParams.TrimEnd().Replace(" ", "&");



                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;

                var (HttpStatusCode, res) = Rest.Get_Restclient(mainUrl, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("data") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["data"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetModelsData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetModelsData::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetTypeAttributes(string url, int pageNumber, int pageSize, string assetName, string assetType, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetTypeAttributesData || Call to GetAssetTypeAttributesData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;
                var temp = new JsonHelper();
                var postData = temp.AssetAttributeBody(assetName, assetType, pageNumber, pageSize);
                var serializedData = JsonConvert.SerializeObject(postData);

                var (HttpStatusCode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("attributeList") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["attributeList"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetTypeAttributesData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetTypeAttributesData:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static int getAssetTypeAttributeTypeProperties(string url, int pageNumber, int pageSize, string assetName, string assetType, Dictionary<string, string> id)

        {
            _logger.Debug("Driver || GetAssetTypeAttributeTypePropertiesData || Call to GetAssetTypeAttributeTypePropertiesData");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var response = tokenGenerator(Out_Values.tokenGeneratorApiUrl);

                var token = Out_Values.tokenCategory + response;
                var temp = new JsonHelper();
                var postData = temp.AssetAttributeBody(assetName, assetType, pageNumber, pageSize);
                var serializedData = JsonConvert.SerializeObject(postData);

                var (HttpStatusCode, res) = Rest.Post_Restclient(url, serializedData, token, "Authorization", id);

                if (res == null) { return _failure; }

                Out_Values.ApiJsonOutput.Clear();
                var result = JsonConvert.DeserializeObject<dynamic>(res);
                if (result.ContainsKey("attributeList") == true)
                {
                    Out_Values.ApiJsonOutput.Add(result["attributeList"]);
                }
                else
                {
                    Out_Values.ApiJsonOutput.Add(result);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || GetAssetTypeAttributeTypePropertiesData : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("GetAssetTypeAttributeTypePropertiesData:" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }

        public static string tokenGenerator(string url)

        {
            _logger.Debug("Driver || TokenGenerator || Call to TokenGenerator");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                var (HttpStatusCode, res) = Rest.Post_Restclient_TokenGenerator(url);
                string access_token = JsonConvert.DeserializeObject<dynamic>(res)["access_token"];

                return access_token;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver || TokenGenerator : Exception {0} ", ex.Message);
                return ex.Message;
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("TokenGenerator::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.TotalMilliseconds);
                Trace.Flush();
            }
        }
    }
}
