using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Threading;
using AutomationFramework;
using NPOI.XSSF.UserModel;
using NUnit.Framework;
using OpenQA.Selenium;
using FAPM_Driver.AutomationModel;
using FAPM_Driver.Drivers;
using ILogger = Logging.ILogger;
using Logger = Logging.Logger;
//using AutoItX3Lib;
using OpenQA.Selenium.Chrome;
using FAPM_Features.Utilities;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;

namespace FAPM_Driver
{
    public class Driver_UI : UI_Driver
    {
        private static readonly ILogger _logger;
        //public static string screenshotpath;


        static Driver_UI()
        {
            _logger = new Logger(typeof(Driver_UI));
            string logFilePath = Directory.GetCurrentDirectory().Split("FAPM_Features")[0] + "UI_Performance_Log";
            if (!Directory.Exists(logFilePath))
            {
                Directory.CreateDirectory(logFilePath);
            }
            Stream myFile = File.Create(logFilePath + "//" + DateTime.Now.ToString("yyyyMMdd") + ".log");
            Trace.Listeners.Add(new TextWriterTraceListener(myFile));
        }
        public const int _success = 9;
        public const int _failure = 7;
        public const int _process_err = 3;
        public const int _exception = -1;
        //public static NgWebDriver ng_driver;
        public static int _shorttimeout = 45000;


        public static string GetScreenshot(string fileName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)UI_Driver.driver;
            Screenshot screenshot = ts.GetScreenshot();
            string pth = System.Reflection.Assembly.GetCallingAssembly().CodeBase;
            string finalpth = Directory.GetCurrentDirectory().Split("UAS_Features")[0] + "ScreenShots\\" + fileName + "_" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss") + ".png";
            screenshot.SaveAsFile(finalpth, ScreenshotImageFormat.Png);
            return finalpth;
        }

        public static IWebDriver Setup()
        {
            
                ChromeOptions options = new ChromeOptions();
                options.AddArguments("incognito");
                options.AddArguments("ignore-certificate-errors");
                options.AddAdditionalCapability("useAutomationExtension", false);
                string fileDownloadPath = Directory.GetCurrentDirectory().Split("FAPM_Features")[0] + "File_Downloads";
                if (!Directory.Exists(fileDownloadPath))
                {
                    Directory.CreateDirectory(fileDownloadPath);
                }
                options.AddUserProfilePreference("download.default_directory", fileDownloadPath + "//");
                driver = new ChromeDriver(@"../../../../AutomationFramework/Driver/Chrome", options, TimeSpan.FromMinutes(3));
                driver.Manage().Window.Maximize();
                return driver;
            

        }

        #region Login

        public static void Login_Chrome()
        {
            _logger.Debug("Driver_UI || Login_Chrome || Call to Login_Chrome");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                object p = UI_Driver.Close();
                UI_Driver.LaunchBrowser("Chrome");
                UI_Driver.EnterURL(Environment_Values.dashboardUrl_Stage_Ops);
                Thread.Sleep(5000);
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Login_Chrome : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                Assert.Fail("Failed: Driver_UI || Login_Chrome");
            }
            finally
            {
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "HeatMap_Dashboard.png", ScreenshotImageFormat.Png);
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(Directory.GetCurrentDirectory().Split("DOS_Features")[0] + "ScreenShots\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Login_Chrome.png", ScreenshotImageFormat.Png);
                stopWatch.Stop();
                Trace.TraceInformation("Login_Chrome::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        #endregion Login

        #region Common
        //This region is used for Common logic across the Product

        public static void kpiSelectionFromDD(string Componentname)
        {
            try
            {
                WaitForPageLoad(driver, 120);
                driver.FindElement(By.XPath("//*[@class='visible menu transition']/div[text()='" + Componentname + "']")).Click();
            }
            catch (Exception e)
            {
                screenshotpath = UI_Driver.GetScreenshot("kpiSelectionFromDD " + DateTime.Now.ToString("yyyyMMddHHmmss"));

                Console.WriteLine(e.Message);
            }
        }
        #endregion Common

        #region PODashboard Outbound Operations

        public static void Launch_DashboardUI(string url)
        {
            _logger.Debug("Driver_UI || Launch_DashboardUI || Call to Login_Chrome");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                object p = UI_Driver.Close();
                UI_Driver.LaunchBrowser("Chrome");
                UI_Driver.EnterURL(url);
                UI_Driver.WaitUntilElementExists(PODashboard.user_name1, 30);
                Console.WriteLine("Entered URL");
                UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name1);
                UI_Driver.Click(PODashboard.click_NextBtn);
                //ProcessStartInfo psi = new ProcessStartInfo(@"../../../../AutomationFramework/Autoit_Script/Login.exe");
                //Process proc = Process.Start(psi);
                //proc.WaitForExit();

                //Older Authentication
                /*UI_Driver.WaitUntilElementExisting(PODashboard.signinbtn1, 30);
                UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name2);
                UI_Driver.EnterText(Environment_Values.password, PODashboard.password);
                UI_Driver.Click(PODashboard.signin_btn);*/


                //new Authentication
                UI_Driver.WaitUntilElementExisting(PODashboard.signinbtn, 30);
                UI_Driver.EnterText(Environment_Values.password, PODashboard.password);
                Console.WriteLine("Password Entered");
                Thread.Sleep(1000);
                UI_Driver.Click(PODashboard.signinbtn);
                Console.WriteLine("Sign in clicked");
                UI_Driver.WaitUntilElementExisting(PODashboard.click_ApprovBtn, 60);
                UI_Driver.Click(PODashboard.click_ApprovBtn);
                Console.WriteLine("Approved clicked");
                Thread.Sleep(10000);

            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Launch_DashboardUI : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                Console.WriteLine("before screenshot");
                screenshotpath = UI_Driver.GetScreenshot("Login_Chrome" + DateTime.Now.ToString("yyyyMMddHHmmss"));
                Assert.Fail("Failed: Driver_UI || Launch_DashboardUI");
            }
            finally
            {
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "HeatMap_Dashboard.png", ScreenshotImageFormat.Png);
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(Directory.GetCurrentDirectory().Split("DOS_Features")[0] + "ScreenShots\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Login_Chrome.png", ScreenshotImageFormat.Png);


                var time1 = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                //UI_Driver.WaitUntilElementExists(PODashboard.CApacity, 120);
                //UI_Driver.WaitUntilElementExists(PODashboard.clickOnViewDetails, 60);
                var time2 = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
                var time = time2 - time1;
                Console.WriteLine(time2 - time1);

                //var waitTime = DateTime.Now.AddMinutes(5);
                stopWatch.Stop();
                Trace.TraceInformation("Launch_DashboardUI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }
        public static void isWidgetPresent(string widgetName)
        {
            _logger.Debug("Driver_UI || isWidgetPresent || Call to VerifyCurrentValue");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                UI_Driver.ElementIsDisplayed(PODashboard.outbound_header);
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || isWidgetPresent : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                screenshotpath = GetScreenshot("isWidgetPresent");
                Assert.Fail("Failed: Driver_UI || isWidgetPresent");
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("isWidgetPresent::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        public static void shipping_dashboard(By locatorElement)
        {
            _logger.Debug("Driver_UI || isElementPresent || Call to VerifyCurrentValue");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                UI_Driver.Click(locatorElement);
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || shipping_dashboard : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                screenshotpath = GetScreenshot("isWidgetPresent"+ DateTime.Now.ToString("yyyyMMddHHmmss"));
                Assert.Fail("Failed: Driver_UI || isElementPresent");
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("shipping_dashboard::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        public static void Notification_Window(By locatorElement)
        {
            _logger.Debug("Driver_UI || isElementPresent || Call to VerifyCurrentValue");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();

                UI_Driver.Click(locatorElement);
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Notification_Window : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                screenshotpath = GetScreenshot("isWidgetPresent"+DateTime.Now.ToString("yyyyMMddHHmmss"));
                Assert.Fail("Failed: Driver_UI || isElementPresent");
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Notification_Window::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        public static void click_shippingDD(string shipping_name)
        {
            try {
                driver.FindElement(By.XPath("//div[@class='visible menu transition']/div[text()='" + shipping_name + "']")).Click();
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || ClickForMultipleElement: Exception {0} ", ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("ClickShippingDD " + DateTime.Now.ToString("yyyyMMddHHmmss"));
            }
        }


        #endregion PODashboard Outbound Operations

        #region Risk Matrix

        public static int RiskMatrixLoadTime()
        {
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var matrix = driver.FindElement(By.XPath("(//*[@class='highcharts-series-group'])[1]"));
                var matrixvalues = driver.FindElements(By.TagName("tspan"));
                var cells = matrix.FindElements(By.TagName("rect"));
                while (cells.Count == 0)
                {
                    Thread.Sleep(100);
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver_UI || RiskMatrixLoadTime : Exception {0} ", ex.Message);
                screenshotpath = GetScreenshot("RiskMatrixLoadTime");
                return _exception;
            }
            finally
            {
                // ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Heat_map_Selection.png", ScreenshotImageFormat.Png);

                stopWatch.Stop();
                Trace.TraceInformation("RiskMatrixLoadTime::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tMilliSeconds:" + stopWatch.Elapsed.Milliseconds);
                Trace.Flush();
            }
        }

        public static int Risk_Matrix_Read()
        {
            //_logger.Debug("Driver_UI || Risk_Matrix_Read || Call to Risk_Matrix_Read");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                var matrix = driver.FindElement(By.XPath("(//*[@class='highcharts-series-group'])[1]"));
                var matrixvalues = driver.FindElements(By.TagName("tspan"));
                var cells = matrix.FindElements(By.TagName("rect"));
                Share.Out_Values.matrix_values.Clear();
                Share.Out_Values.Risk_Matrix_Values.Clear();
                for (int x = 0; x < cells.Count; x++)
                {

                    if (cells[x].GetAttribute("class").ToString().Contains("heatmap-rect-null"))
                    {
                        Share.Out_Values.Risk_Matrix_Values.Add("cell_" + x, null);
                    }
                    else
                    {
                        Share.Out_Values.matrix_values.Add("cell_" + x);
                    }
                }
                for (int s = 0; s < Share.Out_Values.matrix_values.Count; s++)
                {

                    Share.Out_Values.Risk_Matrix_Values.Add(Share.Out_Values.matrix_values[s], matrixvalues[s].Text.ToString());
                }

                return _success;
            }

            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Risk_Matrix_Read : Exception {0} ", ex.Message);
                return _exception;
            }
            finally
            {
                // ((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Heat_map_Selection.png", ScreenshotImageFormat.Png);

                stopWatch.Stop();
                Trace.TraceInformation("Risk_Matrix_Read::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        #endregion

        #region Top Faulted Assets

        public static List<string> topFaulted(By locatorElement, string name = null)
        {
            var element = driver.FindElements(locatorElement);
            List<string> listOfDisplayName = new List<string>();
            //Dictionary<string, string> topfaultedDisplayName = new Dictionary<string, string>();
            for (int i = 0; i < element.Count; i++)
            {
                //topfaultedDisplayName.Add(name + "DisplayName" + i, element[i].Text.ToString());
                listOfDisplayName.Add(element[i].Text.ToString());
            }
            return listOfDisplayName;
        }

        #endregion

        #region Bulk Config Operations

        public static void Launch_ForgeAPMPage()
        {
            _logger.Debug("Driver_UI || Launch_ForgeAPMPage || Call to Login_Chrome");
            Stopwatch stopWatch = null;
            try
            {

                stopWatch = new Stopwatch();
                stopWatch.Start();
                object p = UI_Driver.Close();
                UI_Driver.LaunchBrowser("Chrome");
                UI_Driver.EnterURL(Environment_Values.dashboardUrl_Stage_Ops);
                Thread.Sleep(5000);
                UI_Driver.WaitUntilElementExists(PODashboard.username_header, 30);
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Launch_ForgeAPMPage : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                Assert.Fail("Failed: Driver_UI || Launch_ForgeAPMPage");
            }
            finally
            {
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "HeatMap_Dashboard.png", ScreenshotImageFormat.Png);
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(Directory.GetCurrentDirectory().Split("DOS_Features")[0] + "ScreenShots\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Login_Chrome.png", ScreenshotImageFormat.Png);
                stopWatch.Stop();
                Trace.TraceInformation("Launch_DashboardUI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        public static void Upload_file(string filePath, string fileName, string action)
        {
            _logger.Debug("Driver_UI || Upload_file || Call to Upload_file");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                UI_Driver.Click(PODashboard.browse_files);
                ProcessStartInfo psi = new ProcessStartInfo(@"D:\MyProjects\FAPM_Automation\Autoit_Script\FileUpload.exe", filePath);
                Process proc = Process.Start(psi);
                proc.WaitForExit();
                Thread.Sleep(2000);
                ProcessStartInfo psi1 = new ProcessStartInfo(@"D:\MyProjects\FAPM_Automation\Autoit_Script\FileUpload.exe", filePath);
                Process proc1 = Process.Start(psi1);
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Upload_file : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);

                Assert.Fail("Failed: Driver_UI || Upload_file");
            }
            finally
            {
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(@"C:\BatchMES_Screenshots\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "HeatMap_Dashboard.png", ScreenshotImageFormat.Png);
                //((ITakesScreenshot)driver).GetScreenshot().SaveAsFile(Directory.GetCurrentDirectory().Split("DOS_Features")[0] + "ScreenShots\\" + DateTime.Now.ToString("yyyyMMddHHmmss") + "Login_Chrome.png", ScreenshotImageFormat.Png);
                stopWatch.Stop();
                Trace.TraceInformation("Upload_file::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        #endregion Bulk Config Operations

        #region Pick Module(Picking Dashboard)

        public static void selectKPIFromDD_pickingDashboard(string kpiName)
        {
            try
            {
                WaitForPageLoad(driver, 120);
                driver.FindElement(By.XPath("//div[@class='visible menu transition']/div[text()='" + kpiName + "']")).Click();
                //driver.FindElement(By.XPath("//div[@class='ui scuf-dropdown-wrapper dt-select']/div/div[text()='" + kpiName + "']")).Click();
            }
            catch (Exception ex)
            {
                screenshotpath = UI_Driver.GetScreenshot("selectKPIFromDD_pickingDashboard" + DateTime.Now.ToString("yyyyMMddHHmmss"));
               Console.WriteLine(ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        public static List<string> performPickModuleFromFilterForAll3_PickMod1(string pick_Mod, By locatorElement_row, By locatorElement_coulmn)
        {
            try
            {
                List<string> pickMod = new List<string>();
                Dictionary<string, string> value = TableRowAndColumnForCommonType(locatorElement_row, locatorElement_coulmn);

                if (value["1PICK MODULE"] == pick_Mod)
                {
                    string status_UI = value["1STATUS"];
                    string efficiency_UI = value["1EFFICIENCY"];
                    string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[1]")).Text;
                    string[] throughput_UIs = throughput_UI.Split("\r");
                    string throughput_UI_firstpart = throughput_UIs[0];
                    string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[1]")).Text;
                    pickMod.Add(status_UI);
                    pickMod.Add(efficiency_UI);
                    pickMod.Add(throughput_UI_firstpart);
                    pickMod.Add(rate_hr_UI);
                }
                else if (value["2PICK MODULE"] == pick_Mod)
                {
                    string status_UI = value["2STATUS"];
                    string efficiency_UI = value["2EFFICIENCY"];
                    string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[2]")).Text;
                    string[] throughput_UIs = throughput_UI.Split("\r");
                    string throughput_UI_firstpart = throughput_UIs[0];
                    string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[2]")).Text;
                    pickMod.Add(status_UI);
                    pickMod.Add(efficiency_UI);
                    pickMod.Add(throughput_UI_firstpart);
                    pickMod.Add(rate_hr_UI);
                }
                else if (value["3PICK MODULE"] == pick_Mod)
                {
                    string status_UI = value["3STATUS"];
                    string efficiency_UI = value["3EFFICIENCY"];
                    string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[3]")).Text;
                    string[] throughput_UIs = throughput_UI.Split("\r");
                    string throughput_UI_firstpart = throughput_UIs[0];
                    string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[3]")).Text;
                    pickMod.Add(status_UI);
                    pickMod.Add(efficiency_UI);
                    pickMod.Add(throughput_UI_firstpart);
                    pickMod.Add(rate_hr_UI);
                }
                return pickMod;
            }
            catch (Exception ex)
            {
                //_logger.Error("Driver_UI || ClickForMultipleElement: Exception {0} ", ex.Message);
                screenshotpath = UI_Driver.GetScreenshot("ClickForMultipleElement " + DateTime.Now.ToString("yyyyMMddHHmmss"));
                return null;
            }
        }

        public static List<string> performPickModuleFromFilterForAll3_PickMod2(string pick_Mod, By locatorElement_row, By locatorElement_coulmn)
        {
            List<string> pickMod = new List<string>();
            Dictionary<string, string> value = TableRowAndColumnForCommonType(locatorElement_row, locatorElement_coulmn);

            if (value["1PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["1STATUS"];
                string efficiency_UI = value["1EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[1]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[1]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }
            else if (value["2PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["2STATUS"];
                string efficiency_UI = value["2EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[2]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[2]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }
            else if (value["3PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["3STATUS"];
                string efficiency_UI = value["3EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[3]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[3]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }

            return pickMod;
        }

        public static List<string> performPickModuleFromFilterForAll3_PickMod3(string pick_Mod, By locatorElement_row, By locatorElement_coulmn)
        {
            List<string> pickMod = new List<string>();
            Dictionary<string, string> value = TableRowAndColumnForCommonType(locatorElement_row, locatorElement_coulmn);

            if (value["1PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["1STATUS"];
                string efficiency_UI = value["1EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[1]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[1]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }
            else if (value["2PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["2STATUS"];
                string efficiency_UI = value["2EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[2]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[2]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }
            else if (value["3PICK MODULE"] == pick_Mod)
            {
                string status_UI = value["3STATUS"];
                string efficiency_UI = value["3EFFICIENCY"];
                string throughput_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[4])[3]")).Text;
                string[] throughput_UIs = throughput_UI.Split("\r");
                string throughput_UI_firstpart = throughput_UIs[0];
                string rate_hr_UI = driver.FindElement(By.XPath("(//table/tbody[@class='p-datatable-tbody']/tr/td[5])[3]")).Text;
                pickMod.Add(status_UI);
                pickMod.Add(efficiency_UI);
                pickMod.Add(throughput_UI_firstpart);
                pickMod.Add(rate_hr_UI);
            }

            return pickMod;
        }

        public static List<string> VerifyPandaLanesValuesFromFilterDD(string assetCollection, By locatorElement_row, By locatorElement_coulmn, string kpiName_UI)
        {
            List<string> pandaLane = new List<string>();
            Dictionary<string, string> value = TableRowAndColumnForCommonType(locatorElement_row, locatorElement_coulmn);

            if (value["1LANE"] == kpiName_UI)
            {
                string throughput_UI = value["1THROUGHPUT"];
                string rejects_UI = value["1REJECTS"];
                string scannerError_UI = value["1SCANNER ERRORS"];
                string trackingError_UI = value["1TRACKING ERRORS"];
                string labelsPrinted_UI = value["1LABELS PRINTED"];

                pandaLane.Add(throughput_UI);
                pandaLane.Add(rejects_UI);
                pandaLane.Add(scannerError_UI);
                pandaLane.Add(trackingError_UI);
                pandaLane.Add(labelsPrinted_UI);
            }
            else if (value["2LANE"] == kpiName_UI)
            {
                string throughput_UI = value["2THROUGHPUT"];
                string rejects_UI = value["2REJECTS"];
                string scannerError_UI = value["2SCANNER ERRORS"];
                string trackingError_UI = value["2TRACKING ERRORS"];
                string labelsPrinted_UI = value["2LABELS PRINTED"];

                pandaLane.Add(throughput_UI);
                pandaLane.Add(rejects_UI);
                pandaLane.Add(scannerError_UI);
                pandaLane.Add(trackingError_UI);
                pandaLane.Add(labelsPrinted_UI);
            }
            return pandaLane;
        }

        public static Dictionary<string, string> VerifyShippingLanesValues(By locatorElement_row, By locatorElement_coulmn, string assetCollection)
        {
            Dictionary<string, string> sortlaneObject = new Dictionary<string, string>();
            Dictionary<string, string> value = TableRowAndColumnForCommonType(locatorElement_row, locatorElement_coulmn);
            UI_Driver.Wait(2000);

            if (assetCollection.Contains(","))
            {
                var sorterassets = assetCollection.Split(",");
                for (int i = 0; i < sorterassets.Length; i++)
                {
                    string status_UI = null;
                    string volume_UI = null;
                    string abort_UI = null;
                    string throughput_UI = null;
                    string destination_UI = null;

                    if (value["1LANE"] == sorterassets[i])
                    {
                        status_UI = value["1STATUS"];
                        volume_UI = value["1VOLUME"];
                        abort_UI = value["1ABORTS"];
                        throughput_UI = value["1THROUGHPUT"];
                        //destination_UI = value["1DESTINATION"];
                    }
                    else if (value["2LANE"] == sorterassets[i])
                    {
                        status_UI = value["2STATUS"];
                        volume_UI = value["2VOLUME"];
                        abort_UI = value["2ABORTS"];
                        throughput_UI = value["2THROUGHPUT"];
                        //destination_UI = value["2DESTINATION"];
                    }
                    else if (value["3LANE"] == sorterassets[i])
                    {
                        status_UI = value["3STATUS"];
                        volume_UI = value["3VOLUME"];
                        abort_UI = value["3ABORTS"];
                        throughput_UI = value["3THROUGHPUT"];
                        //destination_UI = value["3DESTINATION"];
                    }
                    else if (value["4LANE"] == sorterassets[i])
                    {
                        status_UI = value["4STATUS"];
                        volume_UI = value["4VOLUME"];
                        abort_UI = value["4ABORTS"];
                        throughput_UI = value["4THROUGHPUT"];
                        //destination_UI = value["4DESTINATION"];
                    }
                    else if (value["5LANE"] == sorterassets[i])
                    {
                        status_UI = value["5STATUS"];
                        volume_UI = value["5VOLUME"];
                        abort_UI = value["5ABORTS"];
                        throughput_UI = value["5THROUGHPUT"];
                        //destination_UI = value["5DESTINATION"];
                    }
                    else if (value["6LANE"] == sorterassets[i])
                    {
                        status_UI = value["6STATUS"];
                        volume_UI = value["6VOLUME"];
                        abort_UI = value["6ABORTS"];
                        throughput_UI = value["6THROUGHPUT"];
                        //destination_UI = value["6DESTINATION"];
                    }
                    else if (value["7LANE"] == sorterassets[i])
                    {
                        status_UI = value["7STATUS"];
                        volume_UI = value["7VOLUME"];
                        abort_UI = value["7ABORTS"];
                        throughput_UI = value["7THROUGHPUT"];
                        //destination_UI = value["7DESTINATION"];
                    }
                    else if (value["8LANE"] == sorterassets[i])
                    {
                        status_UI = value["8STATUS"];
                        volume_UI = value["8VOLUME"];
                        abort_UI = value["8ABORTS"];
                        throughput_UI = value["8THROUGHPUT"];
                        //destination_UI = value["8DESTINATION"];
                    }
                    else if (value["9LANE"] == sorterassets[i])
                    {
                        status_UI = value["9STATUS"];
                        volume_UI = value["9VOLUME"];
                        abort_UI = value["9ABORTS"];
                        throughput_UI = value["9THROUGHPUT"];
                        //destination_UI = value["9DESTINATION"];
                    }
                    else if (value["10LANE"] == sorterassets[i])
                    {
                        status_UI = value["10STATUS"];
                        volume_UI = value["10VOLUME"];
                        abort_UI = value["10ABORTS"];
                        throughput_UI = value["10THROUGHPUT"];
                        //destination_UI = value["10DESTINATION"];
                    }

                    sortlaneObject.Add(++i + "STATUS", status_UI);
                    sortlaneObject.Add(i + "VOLUME", volume_UI);
                    sortlaneObject.Add(i + "ABORTS", abort_UI);
                    sortlaneObject.Add(i-- + "THROUGHPUT", throughput_UI);
                    //sortlaneObject.Add(i-- + "DESTINATION", destination_UI);
                }

            }

            return sortlaneObject;
        }
        public static Dictionary<string, string> TableRowAndColumnForCommonType(By locatorElement_row, By locatorElement_coulmn)
        {
            Dictionary<string, string> keyValueDictionary = new Dictionary<string, string>();
            int row_count = driver.FindElements(locatorElement_row).Count;
            int col_count = driver.FindElements(locatorElement_coulmn).Count;
            for (int i = 1; i <= row_count; i++)
            {
                for (int j = 1; j <= col_count; j++)
                {
                    string column_headers = driver.FindElement(By.XPath("//table/thead/tr/th[" + j + "]")).Text;
                    column_headers = i.ToString() + column_headers;
                    string table_data = driver.FindElement(By.XPath("//table/tbody/tr[" + i + "]/td[" + j + "]")).Text;
                    keyValueDictionary.Add(column_headers, table_data);

                }
                Console.WriteLine();
            }
            return keyValueDictionary;
        }

        public static Dictionary<string, string> captureAssetUtlizationData(string pickMod, By locatorElement, By locatorElement_kpiname, By locatorElement_kpivalue)
        {
            string kpiname;
            string kpivalue;
            IList<string> list_keyKPI = new List<string>();
            IList<string> list_valueKPI = new List<string>();
            Dictionary<string, string> assetData = new Dictionary<string, string>();
            assetData.Clear();

            //click and hold on Asset Utilization to capture data by below function
            IWebElement element = driver.FindElement(By.XPath("//div[text()='" + pickMod + "']/parent::div/parent::td//following-sibling::td[5]"));
            Actions action = new Actions(driver);
            action.ClickAndHold(element).Build().Perform();
            Thread.Sleep(1000);

            //Verifying header of Each Asset pop up window
            //string header = driver.FindElement(By.XPath("//div[@class='dt-column-type-stacked-tooltip']/div[text()='" + pickMod + "']")).Text;
            //Assert.IsTrue(pickMod.Equals(header), $"The expected string: '{pickMod}' is not matched with actual string: '{header}'");

            //capture all KPI name
            IReadOnlyCollection<IWebElement> elements_key = driver.FindElements(locatorElement_kpiname);
            foreach (IWebElement element_key in elements_key)
            {
                kpiname = element_key.GetAttribute("innerHTML");
                list_keyKPI.Add(kpiname);
            }

            //capture all KPI value
            IReadOnlyCollection<IWebElement> elements_value = driver.FindElements(locatorElement_kpivalue);
            foreach (IWebElement element_value in elements_value)
            {
                kpivalue = element_value.GetAttribute("innerHTML");
                list_valueKPI.Add(kpivalue);
            }

            for (int i = 0; i < list_keyKPI.Count; i++)
            {
                assetData.Add(list_keyKPI[i], list_valueKPI[i]);
            }
            return assetData;
        }

        #endregion

        #region Shipping Dashboard

        public static List<string> FetchLastDynamicElement(By locatorElement)
        {
            List<string> totalNumber = new List<string>();
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(locatorElement);
            foreach (IWebElement element in elements)
            {
                string number = element.Text;
                totalNumber.Add(number);
            }
            return totalNumber;
        }
        #endregion

        #region Asset Analytics

        public static void Launch_AssetAnalyticsDashboardUI(string url)
        {
            _logger.Debug("Driver_UI || Launch_AssetAnalyticsDashboardUI || Call to Login_Chrome");
            Stopwatch stopWatch = null;
            try
            {
                stopWatch = new Stopwatch();
                stopWatch.Start();
                object p = UI_Driver.Close();
                UI_Driver.LaunchBrowser("Chrome");
                UI_Driver.EnterURL(url);
                UI_Driver.WaitUntilElementExists(PODashboard.user_name1, 30);
                UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name1);
                UI_Driver.Click(PODashboard.click_NextBtn);
                //ProcessStartInfo psi = new ProcessStartInfo(@"../../../../AutomationFramework/Autoit_Script/Login.exe");
                //Process proc = Process.Start(psi);
                //proc.WaitForExit();

                //Older Authentication
                /*UI_Driver.WaitUntilElementExisting(PODashboard.signinbtn1, 30);
                UI_Driver.EnterText(Environment_Values.userName, PODashboard.user_name2);
                UI_Driver.EnterText(Environment_Values.password, PODashboard.password);
                UI_Driver.Click(PODashboard.signin_btn);*/


                //new Authentication
                UI_Driver.WaitUntilElementExisting(PODashboard.signinbtn, 30);
                UI_Driver.EnterText(Environment_Values.password, PODashboard.password);
                UI_Driver.Click(PODashboard.signinbtn);
                UI_Driver.WaitUntilElementExisting(PODashboard.click_ApprovBtn, 30);
                UI_Driver.Click(PODashboard.click_ApprovBtn);

                stopWatch.Start();
            }
            catch (Exception ex)
            {
                _logger.Error("Driver_UI || Launch_DashboardUI : Exception {0} ", ex.Message);
                Console.WriteLine(ex.Message);
                Assert.Fail("Failed: Driver_UI || Launch_DashboardUI");
            }
            finally
            {
                stopWatch.Stop();
                Trace.TraceInformation("Launch_DashboardUI::" + "SysTime:" + DateTime.Now.ToString("yyyyMMddHHmmss") + "\tSeconds:" + stopWatch.Elapsed.Seconds);
                Trace.Flush();
            }
        }

        public static void clickOnConfiguration(string name)
        {
            driver.FindElement(By.XPath("//span[text()='" + name + "']")).Click();
        }

        public static void selectModelCategory_Template(string name)
        {
            UI_Driver.Wait(1000);
            driver.FindElement(By.XPath("//div[@class='visible menu transition']/div[text()='" + name + "']")).Click();
        }

        public static void typeText(By locatorElement)
        {
            IWebElement element = driver.FindElement(locatorElement);
            IJavaScriptExecutor jse = (IJavaScriptExecutor)driver;
            jse.ExecuteScript("document.getElementById('search-input-id').click()");
            //UI_Driver.Click(AssetAnalytics.click_projectDD);
            //jse.ExecuteScript("document.getElementById('search-input-id').click()");
            UI_Driver.Wait(5000);
            //jse.ExecuteScript("arguments[0].value = 'Automation 1';", element);
        }







        #endregion
    }
}


